import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  MessageSquare,
  Sliders,
  Terminal,
  FileCode,
  Shield,
  Trash2,
  Download,
  Plus,
  Play,
  Check,
  ChevronRight,
} from 'lucide-react';
import { Conversation, OperatingMode } from '../types';

export interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  conversations: Conversation[];
  activeConversationId: string;
  onSelectConversation: (id: string) => void;
  onNewConversation: () => void;
  onOpenSettings: () => void;
  onToggleSidebar: () => void;
  onToggleWorkspace: () => void;
  onToggleStripper: () => void;
  onSetMode: (mode: OperatingMode) => void;
  onOpenRegressionSuite: () => void;
  onExportCurrent: () => void;
}

interface PaletteAction {
  id: string;
  title: string;
  category: 'Conversations' | 'Operating Modes' | 'System Controls' | 'Directives' | 'Export & Data';
  icon: any;
  action: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  conversations,
  activeConversationId,
  onSelectConversation,
  onNewConversation,
  onOpenSettings,
  onToggleSidebar,
  onToggleWorkspace,
  onToggleStripper,
  onSetMode,
  onOpenRegressionSuite,
  onExportCurrent,
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const actions: PaletteAction[] = [
    // Operating Modes
    {
      id: 'mode-apex',
      title: 'Switch Mode: APEX (Full Mesh + Ladder)',
      category: 'Operating Modes',
      icon: Terminal,
      action: () => {
        onSetMode('APEX');
        onClose();
      },
    },
    {
      id: 'mode-lone',
      title: 'Switch Mode: LONE (Single-turn Reasoning)',
      category: 'Operating Modes',
      icon: Terminal,
      action: () => {
        onSetMode('LONE');
        onClose();
      },
    },
    {
      id: 'mode-brutal',
      title: 'Switch Mode: BRUTAL (Hardened Prompt + Critic)',
      category: 'Operating Modes',
      icon: Shield,
      action: () => {
        onSetMode('BRUTAL');
        onClose();
      },
    },
    {
      id: 'mode-raw',
      title: 'Switch Mode: RAW (Unfiltered Upstream Stream)',
      category: 'Operating Modes',
      icon: Terminal,
      action: () => {
        onSetMode('RAW');
        onClose();
      },
    },

    // System Controls
    {
      id: 'new-session',
      title: 'New Conversation Session',
      category: 'System Controls',
      icon: Plus,
      action: () => {
        onNewConversation();
        onClose();
      },
    },
    {
      id: 'open-settings',
      title: 'Open System Settings & BYOK Overrides',
      category: 'System Controls',
      icon: Sliders,
      action: () => {
        onOpenSettings();
        onClose();
      },
    },
    {
      id: 'toggle-sidebar',
      title: 'Toggle Navigation Sidebar (Ctrl+B)',
      category: 'System Controls',
      icon: Sliders,
      action: () => {
        onToggleSidebar();
        onClose();
      },
    },
    {
      id: 'toggle-workspace',
      title: 'Toggle Workspace Artifacts Pane (Ctrl+Shift+W)',
      category: 'System Controls',
      icon: FileCode,
      action: () => {
        onToggleWorkspace();
        onClose();
      },
    },
    {
      id: 'toggle-stripper',
      title: 'Toggle Deterministic Stripper (Ctrl+Shift+D)',
      category: 'System Controls',
      icon: Sliders,
      action: () => {
        onToggleStripper();
        onClose();
      },
    },
    {
      id: 'run-suite',
      title: 'Execute 25-Prompt Regression Test Suite',
      category: 'System Controls',
      icon: Play,
      action: () => {
        onOpenRegressionSuite();
        onClose();
      },
    },
    {
      id: 'export-transcript',
      title: 'Export Active Conversation Transcript',
      category: 'Export & Data',
      icon: Download,
      action: () => {
        onExportCurrent();
        onClose();
      },
    },

    // Conversations
    ...conversations.map((c) => ({
      id: `conv-${c.id}`,
      title: `Jump to: ${c.title || 'Untitled Session'}`,
      category: 'Conversations' as const,
      icon: MessageSquare,
      action: () => {
        onSelectConversation(c.id);
        onClose();
      },
    })),
  ];

  const filtered = actions.filter(
    (a) =>
      a.title.toLowerCase().includes(query.toLowerCase()) ||
      a.category.toLowerCase().includes(query.toLowerCase())
  );

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % Math.max(1, filtered.length));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + filtered.length) % Math.max(1, filtered.length));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (filtered[selectedIndex]) {
        filtered[selectedIndex].action();
      }
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-start justify-center pt-20 p-4 animate-in fade-in duration-100"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl bg-[#0b0d14] border border-blue-500/50 rounded-xl shadow-2xl overflow-hidden font-mono text-xs flex flex-col max-h-[70vh]"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={handleKeyDown}
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-3.5 py-3 border-b border-zinc-800 bg-[#10121a]">
          <Search size={15} className="text-blue-400 mr-2.5 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            placeholder="Type a command, search conversations, or switch mode..."
            className="flex-1 bg-transparent text-zinc-100 placeholder-zinc-500 focus:outline-none text-xs"
          />
          <kbd className="px-1.5 py-0.5 rounded bg-zinc-800 border border-zinc-700 text-zinc-400 text-[10px]">
            ESC
          </kbd>
        </div>

        {/* Action List */}
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {filtered.length === 0 ? (
            <div className="py-8 text-center text-zinc-500">No matching actions or conversations</div>
          ) : (
            filtered.map((item, idx) => {
              const Icon = item.icon;
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={item.id}
                  onClick={item.action}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`flex items-center justify-between p-2.5 rounded-lg cursor-pointer transition-colors ${
                    isSelected ? 'bg-blue-950/60 border border-blue-800/70 text-white' : 'text-zinc-300 hover:bg-zinc-800/50'
                  }`}
                >
                  <div className="flex items-center gap-2.5 truncate">
                    <Icon size={14} className={isSelected ? 'text-blue-400' : 'text-zinc-500'} />
                    <span className="truncate text-[11px] font-sans font-medium">{item.title}</span>
                  </div>
                  <span className="text-[10px] text-zinc-500 font-mono uppercase tracking-wider shrink-0 ml-2">
                    {item.category}
                  </span>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Navigation Hints */}
        <div className="p-2 border-t border-zinc-800/80 bg-[#090b10] flex items-center justify-between text-[10px] text-zinc-500 px-3">
          <div className="flex items-center gap-2">
            <span>↑↓ Navigate</span>
            <span>↵ Select</span>
            <span>Esc Close</span>
          </div>
          <span className="text-zinc-400">APEX FUZZY DISPATCH</span>
        </div>
      </div>
    </div>
  );
};
