import React, { useState, useEffect } from 'react';
import { RotateCcw, X } from 'lucide-react';

export interface UndoableAction {
  id: string;
  description: string;
  onUndo: () => void;
  timestamp: number;
}

interface ToastUndoProps {
  action: UndoableAction | null;
  onDismiss: () => void;
}

export const ToastUndo: React.FC<ToastUndoProps> = ({ action, onDismiss }) => {
  const [progress, setProgress] = useState(100);

  const onDismissRef = React.useRef(onDismiss);
  onDismissRef.current = onDismiss;

  useEffect(() => {
    if (!action) return;

    setProgress(100);
    const duration = 10000; // 10 seconds
    const startTime = Date.now();

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const remainingPct = Math.max(0, 100 - (elapsed / duration) * 100);
      setProgress(remainingPct);

      if (elapsed >= duration) {
        clearInterval(interval);
        onDismissRef.current();
      }
    }, 100);

    return () => clearInterval(interval);
  }, [action]);

  if (!action) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 flex flex-col overflow-hidden rounded-xl bg-[#0e111a] border border-blue-500/70 shadow-2xl text-xs font-mono text-zinc-200 animate-in fade-in slide-in-from-bottom-3 duration-150 min-w-[280px] max-w-md"
    >
      <div className="flex items-center justify-between p-3 gap-3">
        <span className="truncate text-zinc-300 font-sans">{action.description}</span>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => {
              action.onUndo();
              onDismiss();
            }}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white font-bold tracking-wider transition-colors"
          >
            <RotateCcw size={12} />
            <span>UNDO</span>
          </button>
          <button
            onClick={onDismiss}
            className="p-1 hover:text-white rounded hover:bg-zinc-800 text-zinc-500"
            title="Dismiss"
          >
            <X size={13} />
          </button>
        </div>
      </div>
      {/* 10s Countdown Bar */}
      <div className="w-full h-1 bg-zinc-800">
        <div
          className="h-full bg-blue-500 transition-all duration-100 ease-linear"
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
};
