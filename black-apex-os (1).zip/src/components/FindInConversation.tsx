import React, { useState, useEffect, useRef } from 'react';
import { Search, ChevronDown, ChevronUp, X } from 'lucide-react';

interface FindInConversationProps {
  isOpen: boolean;
  onClose: () => void;
  containerRef: React.RefObject<HTMLDivElement | null>;
}

export const FindInConversation: React.FC<FindInConversationProps> = ({
  isOpen,
  onClose,
  containerRef,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [matchCount, setMatchCount] = useState(0);
  const [currentIndex, setCurrentIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      clearHighlights();
      setSearchTerm('');
      setMatchCount(0);
      setCurrentIndex(0);
    }
  }, [isOpen]);

  useEffect(() => {
    performSearch(searchTerm);
  }, [searchTerm]);

  const clearHighlights = () => {
    if (!containerRef.current) return;
    const marks = containerRef.current.querySelectorAll('mark.find-match');
    marks.forEach((m) => {
      const parent = m.parentNode;
      if (parent) {
        parent.replaceChild(document.createTextNode(m.textContent || ''), m);
        parent.normalize();
      }
    });
  };

  const performSearch = (term: string) => {
    clearHighlights();
    if (!term.trim() || !containerRef.current) {
      setMatchCount(0);
      setCurrentIndex(0);
      return;
    }

    const root = containerRef.current;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    const nodesToReplace: { node: Text; parent: Node; text: string }[] = [];

    let node: Text | null;
    const lowerTerm = term.toLowerCase();

    while ((node = walker.nextNode() as Text | null)) {
      if (node && node.nodeValue && node.nodeValue.toLowerCase().includes(lowerTerm)) {
        if (node.parentElement?.closest('textarea, input, button, script, style')) continue;
        nodesToReplace.push({
          node,
          parent: node.parentNode!,
          text: node.nodeValue,
        });
      }
    }

    let count = 0;
    for (const { node, parent, text } of nodesToReplace) {
      const fragment = document.createDocumentFragment();
      let lastIdx = 0;
      const regex = new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
      let match;

      while ((match = regex.exec(text)) !== null) {
        if (match.index > lastIdx) {
          fragment.appendChild(document.createTextNode(text.slice(lastIdx, match.index)));
        }
        const mark = document.createElement('mark');
        mark.className = 'find-match bg-amber-500/40 text-white rounded px-0.5 border border-amber-400/60';
        mark.textContent = match[0];
        fragment.appendChild(mark);
        lastIdx = match.index + match[0].length;
        count++;
      }

      if (lastIdx < text.length) {
        fragment.appendChild(document.createTextNode(text.slice(lastIdx)));
      }

      parent.replaceChild(fragment, node);
    }

    setMatchCount(count);
    setCurrentIndex(count > 0 ? 1 : 0);
    if (count > 0) {
      scrollToMatch(0);
    }
  };

  const scrollToMatch = (idx: number) => {
    if (!containerRef.current) return;
    const marks = containerRef.current.querySelectorAll('mark.find-match');
    if (marks.length === 0) return;

    marks.forEach((m, i) => {
      if (i === idx) {
        m.classList.add('bg-amber-400', 'text-black', 'ring-2', 'ring-amber-300');
        m.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else {
        m.classList.remove('bg-amber-400', 'text-black', 'ring-2', 'ring-amber-300');
      }
    });
  };

  const handleNext = () => {
    if (matchCount === 0) return;
    const next = currentIndex >= matchCount ? 1 : currentIndex + 1;
    setCurrentIndex(next);
    scrollToMatch(next - 1);
  };

  const handlePrev = () => {
    if (matchCount === 0) return;
    const prev = currentIndex <= 1 ? matchCount : currentIndex - 1;
    setCurrentIndex(prev);
    scrollToMatch(prev - 1);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (e.shiftKey) handlePrev();
      else handleNext();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div
      role="search"
      aria-label="Find in conversation"
      className="absolute top-3 right-6 z-40 flex items-center gap-1.5 p-1.5 bg-[#10131d] border border-zinc-700 rounded-lg shadow-xl text-xs font-mono select-none animate-in fade-in slide-in-from-top-2 duration-150"
    >
      <Search size={13} className="text-zinc-400 ml-1 shrink-0" />
      <input
        ref={inputRef}
        type="text"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Find in conversation..."
        className="w-48 bg-transparent text-zinc-100 placeholder-zinc-500 focus:outline-none text-xs px-1"
      />

      <span className="text-[10px] text-zinc-400 px-1 border-l border-zinc-700 shrink-0">
        {matchCount > 0 ? `${currentIndex} of ${matchCount}` : 'No matches'}
      </span>

      <div className="flex items-center gap-0.5 border-l border-zinc-700 pl-1 shrink-0">
        <button
          onClick={handlePrev}
          disabled={matchCount === 0}
          className="p-1 text-zinc-400 hover:text-white disabled:opacity-30 rounded hover:bg-zinc-800"
          title="Previous match (Shift+Enter)"
          aria-label="Previous match"
        >
          <ChevronUp size={13} />
        </button>
        <button
          onClick={handleNext}
          disabled={matchCount === 0}
          className="p-1 text-zinc-400 hover:text-white disabled:opacity-30 rounded hover:bg-zinc-800"
          title="Next match (Enter)"
          aria-label="Next match"
        >
          <ChevronDown size={13} />
        </button>
        <button
          onClick={onClose}
          className="p-1 text-zinc-400 hover:text-white rounded hover:bg-zinc-800 ml-0.5"
          title="Close find (Esc)"
          aria-label="Close find"
        >
          <X size={13} />
        </button>
      </div>
    </div>
  );
};
