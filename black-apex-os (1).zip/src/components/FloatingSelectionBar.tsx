import React, { useEffect, useState } from 'react';
import { Sparkles, HelpCircle, Maximize2, Minimize2, Languages, FileCode, Search } from 'lucide-react';

interface FloatingSelectionBarProps {
  onAction: (action: string, selectedText: string) => void;
}

export const FloatingSelectionBar: React.FC<FloatingSelectionBarProps> = ({ onAction }) => {
  const [selectedText, setSelectedText] = useState('');
  const [position, setPosition] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    const handleMouseUp = () => {
      const selection = window.getSelection();
      if (!selection || selection.isCollapsed) {
        setPosition(null);
        setSelectedText('');
        return;
      }
      const text = selection.toString().trim();
      if (text.length > 2) {
        const range = selection.getRangeAt(0);
        const rect = range.getBoundingClientRect();
        setSelectedText(text);
        setPosition({
          x: Math.max(10, Math.min(window.innerWidth - 320, rect.left + rect.width / 2 - 160)),
          y: Math.max(10, rect.top - 46),
        });
      } else {
        setPosition(null);
        setSelectedText('');
      }
    };

    document.addEventListener('mouseup', handleMouseUp);
    return () => document.removeEventListener('mouseup', handleMouseUp);
  }, []);

  if (!position || !selectedText) return null;

  return (
    <div
      style={{ left: `${position.x}px`, top: `${position.y}px` }}
      className="fixed z-50 flex items-center gap-1 bg-[#12141c] border border-zinc-700/80 rounded-lg p-1 shadow-2xl backdrop-blur font-mono text-[11px] text-zinc-300 select-none animate-in fade-in zoom-in-95 duration-100"
    >
      <button
        onClick={() => {
          onAction('explain', selectedText);
          setPosition(null);
        }}
        className="flex items-center gap-1 px-2 py-1 rounded hover:bg-zinc-800 text-zinc-300 hover:text-white"
        title="Explain this selection"
      >
        <HelpCircle size={12} />
        <span>Explain</span>
      </button>

      <button
        onClick={() => {
          onAction('expand', selectedText);
          setPosition(null);
        }}
        className="flex items-center gap-1 px-2 py-1 rounded hover:bg-zinc-800 text-zinc-300 hover:text-white"
        title="Expand on this"
      >
        <Maximize2 size={12} />
        <span>Expand</span>
      </button>

      <button
        onClick={() => {
          onAction('shorten', selectedText);
          setPosition(null);
        }}
        className="flex items-center gap-1 px-2 py-1 rounded hover:bg-zinc-800 text-zinc-300 hover:text-white"
        title="Shorten"
      >
        <Minimize2 size={12} />
        <span>Shorten</span>
      </button>

      <button
        onClick={() => {
          onAction('artifact', selectedText);
          setPosition(null);
        }}
        className="flex items-center gap-1 px-2 py-1 rounded hover:bg-zinc-800 text-blue-300 hover:text-blue-200"
        title="Convert selection into an artifact"
      >
        <FileCode size={12} />
        <span>Artifact</span>
      </button>

      <button
        onClick={() => {
          onAction('search', selectedText);
          setPosition(null);
        }}
        className="flex items-center gap-1 px-2 py-1 rounded hover:bg-zinc-800 text-zinc-300 hover:text-white"
        title="Search this"
      >
        <Search size={12} />
        <span>Search</span>
      </button>
    </div>
  );
};
