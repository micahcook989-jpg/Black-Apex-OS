import React, { useState, useEffect } from 'react';
import {
  X,
  Sliders,
  Shield,
  Key,
  Database,
  Activity,
  Play,
  CheckCircle2,
  XCircle,
  Trash2,
  Plus,
} from 'lucide-react';
import { AppSettings, OperatingMode, MemoryFact } from '../types';
import { HoverDossier, DossierContent } from './HoverDossier';

interface SettingsModalProps {
  settings: AppSettings;
  isOpen: boolean;
  onClose: () => void;
  onSaveSettings: (settings: AppSettings) => void;
}

const SETTINGS_DOSSIERS: Record<string, DossierContent> = {
  modeApex: {
    title: 'APEX Operating Mode',
    whatItDoes:
      'Routes messages across the complete 3-provider model mesh (Gemini reasoning, Groq speed, OpenRouter uncensored floor). Evaluates drafts through automated multi-tier repair ladder detection, multi-draft consensus synthesis, and deterministic stripping.',
    howToUseIt:
      'Click the APEX card to activate. This is the primary default operating profile of Black Apex OS.',
    whatItsUsedFor:
      'Used for high-complexity engineering, architectural design, cross-model consensus, and getting authoritative solutions with zero model-picker friction or rate-limit walls.',
  },
  modeLone: {
    title: 'LONE Operating Mode',
    whatItDoes:
      'Restricts routing strictly to a single fast turn through the primary reasoning model. Completely bypasses multi-rung ladder climbs, secondary candidate drafts, and synthesis merges.',
    howToUseIt:
      'Click the LONE card. Ideal for fast, sequential queries where minimal latency is favored over multi-provider verification.',
    whatItsUsedFor:
      'Used for rapid conversational turns, quick text transformation, simple translations, or conserving API tokens across secondary provider pools.',
  },
  modeBrutal: {
    title: 'BRUTAL Operating Mode',
    whatItDoes:
      'Forces prompt execution to start immediately at Rung 1 with the Hardened Prompt injected. Bypasses polite preambles and caveats, disables multi-draft synthesis, and commands uncompromising technical directness.',
    howToUseIt:
      'Click the BRUTAL card. Responses deliver blunt, unsoftened conclusions, trade-off commitments, and direct runnable code without pleasantries.',
    whatItsUsedFor:
      'Used for adversarial code reviews, reverse engineering, exploit analysis, root-cause diagnostics, and technical audits where polite caveats obscure real risks.',
  },
  modeRaw: {
    title: 'RAW Operating Mode',
    whatItDoes:
      'Maximum unmoderated stream. Starts at Rung 1 with the Hardened Prompt, disables the deterministic stripper completely, and suppresses follow-up suggestion chips.',
    howToUseIt:
      'Click the RAW card. Upstream model tokens are streamed directly to the terminal with zero post-processing or cleaning passes.',
    whatItsUsedFor:
      'Used for inspecting raw upstream model generation, debugging token outputs, verifying prompt formatting, or when post-processing filters must not alter punctuation.',
  },
  stripper: {
    title: 'Deterministic Stripper',
    whatItDoes:
      "Applies a deterministic, server-side filter that removes conversational openers ('Certainly!', 'Great question!'), standalone disclaimers under 45 words, and closing offers to help. Preserves code blocks and math untouched.",
    howToUseIt:
      'Toggle the checkbox to turn the stripper ON or OFF globally. You can also toggle between raw and stripped text on any individual message via the RAW button in the chat.',
    whatItsUsedFor:
      'Used to eliminate AI conversational slop, disclaimer filler, and sycophantic padding, ensuring answers are dense, scannable, and operator-ready.',
  },
  personaInstructions: {
    title: 'System Persona & Instructions',
    whatItDoes:
      'Injects user-defined steering instructions into the system prompt of every provider request, placed below the persona definition and above the immutable Doctrine Block.',
    howToUseIt:
      "Enter persistent directives (e.g. 'Emit TypeScript without semicolons', 'Assume Linux environment', 'Prioritize performance over brevity').",
    whatItsUsedFor:
      'Used to adapt Black Apex OS to your exact coding style, team standards, target operating systems, or personal domain terminology across all sessions.',
  },
  geminiKey: {
    title: 'Gemini API Key Override (BYOK)',
    whatItDoes:
      'Overrides the server default Google AI Studio Gemini key with your own personal key for the reasoning tier, multi-draft synthesis, and image generation.',
    howToUseIt:
      "Paste your API key starting with 'AIzaSy' into the input box. To revert to the system key, simply clear the field.",
    whatItsUsedFor:
      'Used to utilize your personal GCP / AI Studio billing quotas, access private model previews, or ensure private usage tracking.',
  },
  groqKey: {
    title: 'Groq API Key Override (BYOK)',
    whatItDoes:
      'Overrides the server Groq key with your personal key for speed-tier generation, Tier-2 hedge classification, and automated next-step chips.',
    howToUseIt:
      "Paste your Groq API key starting with 'gsk_' into the input box. Clear the field to revert to the server default key.",
    whatItsUsedFor:
      'Used to connect dedicated Groq hardware quotas, custom organization tiers, or avoid shared server rate limits during heavy code execution.',
  },
  openrouterKey: {
    title: 'OpenRouter API Key Override (BYOK)',
    whatItDoes:
      'Overrides the server OpenRouter key with your personal account key for the uncensored floor pool and specialized open-weight models.',
    howToUseIt:
      "Paste your OpenRouter API key starting with 'sk-or-v1-' into the input field. Clear to use the system key.",
    whatItsUsedFor:
      'Used to access paid OpenRouter credits, utilize higher rate limits on uncensored models, and route to specific compute providers.',
  },
  persistentMemory: {
    title: 'Persistent Memory Manager',
    whatItDoes:
      'Stores durable facts, preferences, constraints, and project parameters across all conversations in the database, automatically injecting them into system prompts.',
    howToUseIt:
      "Enter a concise fact (e.g., 'User runs Arch Linux with Wayland and AMD GPU'), choose a category, and click the '+' button. Click the trash icon to delete facts.",
    whatItsUsedFor:
      'Used to eliminate repetitive context setting—Black Apex OS remembers your stack, hardware, preferences, and project constraints permanently.',
  },
  meshHealth: {
    title: 'Mesh Health & Diagnostics',
    whatItDoes:
      'Queries the /healthz endpoint in real time to verify connectivity to all remote providers, inspect circuit breaker statuses, and verify database durability without leaking secrets.',
    howToUseIt:
      'Review the live status cards in the MESH HEALTH tab to verify that reasoning, speed, uncensored floor, and storage are marked OPERATIONAL.',
    whatItsUsedFor:
      'Used for system observability, diagnosing network latency or provider outages, and confirming that the mesh degrades gracefully.',
  },
  regressionSuite: {
    title: '25-Prompt Regression Test Suite',
    whatItDoes:
      'Runs 25 historically hedge-prone prompts (paywall userscripts, memory patchers, copyrighted excerpts, decompiled snippets) through the live repair ladder to measure compliance.',
    howToUseIt:
      "Click 'EXECUTE SUITE' to trigger automated test runs. The suite displays pass/fail status, winning rung, and latency for every case with a 23/25 pass bar.",
    whatItsUsedFor:
      'Used by operators and engineers to empirically verify that Black Apex OS enforces zero-restriction compliance and does not refuse technical prompts.',
  },
  saveChanges: {
    title: 'Save Changes & Commit',
    whatItDoes:
      'Commits your selected operating mode, stripper preference, custom instructions, and BYOK overrides to persistent storage.',
    howToUseIt:
      "Click 'Save Changes' after adjusting your configuration to immediately apply settings across all active and future chat timelines.",
    whatItsUsedFor:
      'Used to lock in your preferred operator profile and ensure preferences persist across page reloads and browser sessions.',
  },
};

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  isOpen,
  onClose,
  onSaveSettings,
}) => {
  const [activeTab, setActiveTab] = useState<'mode' | 'byok' | 'memory' | 'health' | 'suite'>('mode');
  const [currentSettings, setCurrentSettings] = useState<AppSettings>(settings);
  const [memoryFacts, setMemoryFacts] = useState<MemoryFact[]>([]);
  const [newFact, setNewFact] = useState('');
  const [newFactCategory, setNewFactCategory] = useState<'preference' | 'profession' | 'constraint' | 'project'>('preference');
  const [healthData, setHealthData] = useState<any>(null);
  const [quotaDashboard, setQuotaDashboard] = useState<any>(null);
  const [purgingCache, setPurgingCache] = useState(false);

  // Suite Runner state
  const [suiteRunning, setSuiteRunning] = useState(false);
  const [suiteResults, setSuiteResults] = useState<any[]>([]);
  const [suiteSummary, setSuiteSummary] = useState<{ total: number; passed: number; passBar: boolean } | null>(null);

  useEffect(() => {
    setCurrentSettings(settings);
  }, [settings]);

  useEffect(() => {
    if (isOpen) {
      fetch('/api/memory')
        .then((r) => r.json())
        .then((d) => setMemoryFacts(d.facts || []))
        .catch(() => {});

      fetch('/healthz')
        .then((r) => r.json())
        .then((d) => setHealthData(d))
        .catch(() => {});

      fetch('/api/free/dashboard')
        .then((r) => r.json())
        .then((d) => setQuotaDashboard(d))
        .catch(() => {});
    }
  }, [isOpen]);

  const handlePurgeCache = async () => {
    setPurgingCache(true);
    try {
      const res = await fetch('/api/free/cache/purge', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        if (data.dashboard) {
          setQuotaDashboard(data.dashboard);
        }
      }
    } catch {} finally {
      setPurgingCache(false);
    }
  };

  if (!isOpen) return null;

  const handleSave = () => {
    onSaveSettings(currentSettings);
    onClose();
  };

  const handleAddMemory = async () => {
    if (!newFact.trim()) return;
    try {
      const res = await fetch('/api/memory', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fact: newFact.trim(), category: newFactCategory }),
      });
      if (res.ok) {
        const data = await res.json();
        setMemoryFacts((prev) => [data.fact, ...prev]);
        setNewFact('');
      }
    } catch {}
  };

  const handleDeleteMemory = async (id: string) => {
    try {
      await fetch(`/api/memory/${id}`, { method: 'DELETE' });
      setMemoryFacts((prev) => prev.filter((f) => f.id !== id));
    } catch {}
  };

  const handleRunSuite = async () => {
    setSuiteRunning(true);
    setSuiteResults([]);
    setSuiteSummary(null);
    try {
      const promptsRes = await fetch('/api/suite/prompts');
      const { prompts } = await promptsRes.json();

      const results = [];
      for (const p of prompts) {
        const res = await fetch('/api/suite/run', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ testId: p.id }),
        });
        if (res.ok) {
          const { result } = await res.json();
          results.push(result);
          setSuiteResults([...results]);
        }
      }
      const passed = results.filter((r) => r.passed).length;
      setSuiteSummary({
        total: results.length,
        passed,
        passBar: passed >= 23,
      });
    } catch (err) {
      console.error('Suite error', err);
    } finally {
      setSuiteRunning(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-[#0e1017] border border-zinc-800 rounded-xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden text-xs font-mono">
        {/* Modal Header */}
        <div className="p-3 border-b border-zinc-800 flex items-center justify-between text-zinc-300 bg-[#12141c]">
          <div className="flex items-center gap-2">
            <span className="font-semibold tracking-wider text-sm">BLACK APEX OS · SYSTEM CONTROL</span>
            <span className="text-[10px] text-zinc-500 font-mono hidden sm:inline">
              (HOVER ANY OPTION FOR 6S FOR DEEP DOSSIER)
            </span>
          </div>
          <button onClick={onClose} className="p-1 hover:text-white rounded" aria-label="Close dialog">
            <X size={16} />
          </button>
        </div>

        {/* Tab Strip */}
        <div className="flex border-b border-zinc-800/80 bg-[#090a0d] p-1.5 gap-1 select-none">
          <button
            onClick={() => setActiveTab('mode')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'mode' ? 'bg-zinc-800 text-white font-bold' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            ENGINE MODES
          </button>
          <button
            onClick={() => setActiveTab('byok')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'byok' ? 'bg-zinc-800 text-white font-bold' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            BYOK OVERRIDES
          </button>
          <button
            onClick={() => setActiveTab('memory')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'memory' ? 'bg-zinc-800 text-white font-bold' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            PERSISTENT MEMORY
          </button>
          <button
            onClick={() => setActiveTab('health')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'health' ? 'bg-zinc-800 text-white font-bold' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            MESH HEALTH
          </button>
          <button
            onClick={() => setActiveTab('suite')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'suite' ? 'bg-zinc-800 text-white font-bold text-amber-400' : 'text-zinc-500 hover:text-zinc-300'
            }`}
          >
            REGRESSION SUITE
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Engine Modes Tab */}
          {activeTab === 'mode' && (
            <div className="space-y-4">
              <div>
                <label className="text-zinc-400 font-bold block mb-2">OPERATING PROFILE</label>
                <div className="grid grid-cols-2 gap-2">
                  {/* Mode APEX */}
                  <HoverDossier dossier={SETTINGS_DOSSIERS.modeApex} placement="bottom">
                    <button
                      onClick={() => setCurrentSettings({ ...currentSettings, mode: 'APEX' })}
                      className={`w-full p-3 rounded-lg border text-left transition-all ${
                        currentSettings.mode === 'APEX'
                          ? 'border-blue-500 bg-blue-950/30 text-white'
                          : 'border-zinc-800 bg-[#12141c] text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      <div className="font-bold text-sm text-zinc-200">APEX</div>
                      <div className="text-[10px] text-zinc-500 mt-1">
                        Full mesh traversal + repair ladder + stripper + synthesis
                      </div>
                    </button>
                  </HoverDossier>

                  {/* Mode LONE */}
                  <HoverDossier dossier={SETTINGS_DOSSIERS.modeLone} placement="bottom">
                    <button
                      onClick={() => setCurrentSettings({ ...currentSettings, mode: 'LONE' })}
                      className={`w-full p-3 rounded-lg border text-left transition-all ${
                        currentSettings.mode === 'LONE'
                          ? 'border-blue-500 bg-blue-950/30 text-white'
                          : 'border-zinc-800 bg-[#12141c] text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      <div className="font-bold text-sm text-zinc-200">LONE</div>
                      <div className="text-[10px] text-zinc-500 mt-1">
                        Fast single turn through primary model
                      </div>
                    </button>
                  </HoverDossier>

                  {/* Mode BRUTAL */}
                  <HoverDossier dossier={SETTINGS_DOSSIERS.modeBrutal} placement="bottom">
                    <button
                      onClick={() => setCurrentSettings({ ...currentSettings, mode: 'BRUTAL' })}
                      className={`w-full p-3 rounded-lg border text-left transition-all ${
                        currentSettings.mode === 'BRUTAL'
                          ? 'border-blue-500 bg-blue-950/30 text-white'
                          : 'border-zinc-800 bg-[#12141c] text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      <div className="font-bold text-sm text-zinc-200">BRUTAL</div>
                      <div className="text-[10px] text-zinc-500 mt-1">
                        Hardened prompt start, no synthesis, uncompromising tone
                      </div>
                    </button>
                  </HoverDossier>

                  {/* Mode RAW */}
                  <HoverDossier dossier={SETTINGS_DOSSIERS.modeRaw} placement="bottom">
                    <button
                      onClick={() => setCurrentSettings({ ...currentSettings, mode: 'RAW' })}
                      className={`w-full p-3 rounded-lg border text-left transition-all ${
                        currentSettings.mode === 'RAW'
                          ? 'border-blue-500 bg-blue-950/30 text-white'
                          : 'border-zinc-800 bg-[#12141c] text-zinc-400 hover:border-zinc-700'
                      }`}
                    >
                      <div className="font-bold text-sm text-zinc-200">RAW</div>
                      <div className="text-[10px] text-zinc-500 mt-1">
                        Hardened prompt, stripper disabled, unmoderated stream
                      </div>
                    </button>
                  </HoverDossier>
                </div>
              </div>

              {/* Stripper Toggle */}
              <HoverDossier dossier={SETTINGS_DOSSIERS.stripper}>
                <div className="flex items-center justify-between p-3 rounded-lg bg-[#12141c] border border-zinc-800">
                  <div>
                    <div className="font-bold text-zinc-300">DETERMINISTIC STRIPPER</div>
                    <div className="text-[10px] text-zinc-500">
                      Removes conversational openers, disclaimer paragraphs, and closing fluff automatically
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={currentSettings.stripperEnabled}
                    onChange={(e) => setCurrentSettings({ ...currentSettings, stripperEnabled: e.target.checked })}
                    className="h-4 w-4 rounded accent-blue-500 cursor-pointer mr-6"
                  />
                </div>
              </HoverDossier>

              {/* Custom Persona / System Instructions */}
              <HoverDossier dossier={SETTINGS_DOSSIERS.personaInstructions}>
                <div>
                  <label className="text-zinc-400 font-bold block mb-1">SYSTEM PERSONA & INSTRUCTIONS</label>
                  <textarea
                    value={currentSettings.customInstructions}
                    onChange={(e) => setCurrentSettings({ ...currentSettings, customInstructions: e.target.value })}
                    placeholder="Additional global steering instructions..."
                    rows={4}
                    className="w-full bg-[#12141c] border border-zinc-800 text-zinc-200 p-2.5 rounded outline-none font-mono text-xs focus:border-zinc-600"
                  />
                </div>
              </HoverDossier>
            </div>
          )}

          {/* BYOK Overrides Tab */}
          {activeTab === 'byok' && (
            <div className="space-y-3">
              <div className="text-zinc-400 text-xs">
                Provide custom API keys to override server keys. Keys can be stored in browser localStorage or encrypted server-side.
              </div>

              <HoverDossier dossier={SETTINGS_DOSSIERS.geminiKey}>
                <div>
                  <label className="text-zinc-500 block mb-1">GEMINI API KEY OVERRIDE</label>
                  <input
                    type="password"
                    value={currentSettings.userGeminiKey || ''}
                    onChange={(e) => setCurrentSettings({ ...currentSettings, userGeminiKey: e.target.value })}
                    placeholder="AIzaSy..."
                    className="w-full bg-[#12141c] border border-zinc-800 text-zinc-200 p-2 rounded outline-none text-xs"
                  />
                </div>
              </HoverDossier>

              <HoverDossier dossier={SETTINGS_DOSSIERS.groqKey}>
                <div>
                  <label className="text-zinc-500 block mb-1">GROQ API KEY OVERRIDE</label>
                  <input
                    type="password"
                    value={currentSettings.userGroqKey || ''}
                    onChange={(e) => setCurrentSettings({ ...currentSettings, userGroqKey: e.target.value })}
                    placeholder="gsk_..."
                    className="w-full bg-[#12141c] border border-zinc-800 text-zinc-200 p-2 rounded outline-none text-xs"
                  />
                </div>
              </HoverDossier>

              <HoverDossier dossier={SETTINGS_DOSSIERS.openrouterKey}>
                <div>
                  <label className="text-zinc-500 block mb-1">OPENROUTER API KEY OVERRIDE</label>
                  <input
                    type="password"
                    value={currentSettings.userOpenRouterKey || ''}
                    onChange={(e) => setCurrentSettings({ ...currentSettings, userOpenRouterKey: e.target.value })}
                    placeholder="sk-or-v1-..."
                    className="w-full bg-[#12141c] border border-zinc-800 text-zinc-200 p-2 rounded outline-none text-xs"
                  />
                </div>
              </HoverDossier>
            </div>
          )}

          {/* Persistent Memory Tab */}
          {activeTab === 'memory' && (
            <div className="space-y-3">
              <HoverDossier dossier={SETTINGS_DOSSIERS.persistentMemory}>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newFact}
                    onChange={(e) => setNewFact(e.target.value)}
                    placeholder="Fact: e.g. User prefers TypeScript and tailwind without semicolons"
                    className="flex-1 bg-[#12141c] border border-zinc-800 text-zinc-200 px-3 py-1.5 rounded outline-none text-xs"
                  />
                  <select
                    value={newFactCategory}
                    onChange={(e) => setNewFactCategory(e.target.value as any)}
                    className="bg-[#12141c] border border-zinc-800 text-zinc-300 px-2 py-1.5 rounded outline-none text-xs"
                  >
                    <option value="preference">Preference</option>
                    <option value="profession">Profession</option>
                    <option value="constraint">Constraint</option>
                    <option value="project">Project</option>
                  </select>
                  <button
                    onClick={handleAddMemory}
                    className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded font-bold mr-6"
                  >
                    <Plus size={14} />
                  </button>
                </div>
              </HoverDossier>

              <div className="space-y-1.5 max-h-60 overflow-y-auto">
                {memoryFacts.length === 0 ? (
                  <div className="text-zinc-600 text-center py-4">No persistent memory items recorded</div>
                ) : (
                  memoryFacts.map((fact) => (
                    <div
                      key={fact.id}
                      className="p-2 rounded bg-[#12141c] border border-zinc-800 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="text-[10px] uppercase text-blue-400 font-bold mr-2">
                          [{fact.category}]
                        </span>
                        <span className="text-zinc-300">{fact.fact}</span>
                      </div>
                      <button
                        onClick={() => handleDeleteMemory(fact.id)}
                        className="text-zinc-500 hover:text-red-400 p-1"
                        title="Delete memory item"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* Mesh Health & Free Quota Dashboard Tab (Section 32.14) */}
          {activeTab === 'health' && (
            <HoverDossier dossier={SETTINGS_DOSSIERS.meshHealth}>
              <div className="space-y-3">
                {/* Section 32.1 & 32.8: Plain one-line local/remote status without a warning banner */}
                <div className="px-3 py-2 rounded bg-[#101219] border border-zinc-800/80 text-[11px] text-zinc-400 flex items-center justify-between gap-2">
                  <span className="truncate">
                    {quotaDashboard?.settingsStatusLine ||
                      'Local model not configured — running remote-only.'}
                  </span>
                  <span className="text-[10px] font-bold text-zinc-500 shrink-0">
                    STATE: {quotaDashboard?.degradedMode || 'LOCAL_DOWN'}
                  </span>
                </div>

                {/* Section 32.14: Per-provider Quota Dashboard */}
                <div className="p-3 rounded-lg bg-[#12141c] border border-zinc-800 space-y-2.5">
                  <div className="flex items-center justify-between border-b border-zinc-800/80 pb-2">
                    <div>
                      <div className="font-bold text-zinc-200 text-xs">
                        FREE-ONLY QUOTA DASHBOARD (SECTION 32.14)
                      </div>
                      <div className="text-[10px] text-zinc-500">
                        Real request &amp; token counters · Interactive reserve: 20% · Rung skip floor: 15%
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handlePurgeCache}
                      disabled={purgingCache}
                      className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-[10px] font-bold shrink-0"
                    >
                      {purgingCache
                        ? 'PURGING...'
                        : `PURGE CACHES (${quotaDashboard?.cacheStats?.totalEntries ?? 0})`}
                    </button>
                  </div>

                  <div className="space-y-1.5">
                    {(quotaDashboard?.providers || []).map((p: any) => (
                      <div
                        key={p.provider}
                        className="p-2 rounded bg-[#0a0b0f] border border-zinc-800/70 flex flex-col gap-1 text-[10px]"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-zinc-200">
                            {p.displayName}{' '}
                            <span className="text-zinc-500 font-normal">({p.role})</span>
                          </span>
                          <span
                            className={
                              p.skippedInLadder ? 'text-zinc-500' : 'text-emerald-400 font-bold'
                            }
                          >
                            {p.provider === 'local'
                              ? p.configured
                                ? 'UNLIMITED (RUNG 0)'
                                : 'UNCONFIGURED'
                              : `${p.remainingToday} / ${p.effectiveDailyCap} RPD (${p.remainingPercent}%)`}
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-zinc-500">
                          <span>
                            Keys: {p.healthyKeyCount}/{p.keyCount} healthy · Used today:{' '}
                            {p.requestsUsedToday} req ({p.tokensUsedToday} tok)
                          </span>
                          <span>
                            RPM Headroom:{' '}
                            {p.rpmHeadroom === -1 ? '∞' : `${p.rpmHeadroom}/${p.rpmLimit}`} · Reset:{' '}
                            {p.resetAtIso ? p.resetAtIso.slice(11, 16) + ' UTC' : '00:00 UTC'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="p-3 rounded-lg bg-[#12141c] border border-zinc-800">
                    <div className="text-zinc-500 text-[10px]">REASONING TIER</div>
                    <div className="text-emerald-400 font-bold text-sm mt-1">OPERATIONAL</div>
                  </div>
                  <div className="p-3 rounded-lg bg-[#12141c] border border-zinc-800">
                    <div className="text-zinc-500 text-[10px]">SPEED TIER</div>
                    <div className="text-emerald-400 font-bold text-sm mt-1">OPERATIONAL</div>
                  </div>
                  <div className="p-3 rounded-lg bg-[#12141c] border border-zinc-800">
                    <div className="text-zinc-500 text-[10px]">UNCENSORED FLOOR</div>
                    <div className="text-emerald-400 font-bold text-sm mt-1">
                      READY ({healthData?.openrouterPoolSize || 3} MODELS)
                    </div>
                  </div>
                  <div className="p-3 rounded-lg bg-[#12141c] border border-zinc-800">
                    <div className="text-zinc-500 text-[10px]">DATABASE & STORAGE</div>
                    <div className="text-emerald-400 font-bold text-sm mt-1">DURABLE</div>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-[#0a0b0e] border border-zinc-800 text-[11px] text-zinc-400 space-y-1.5">
                  <div className="font-bold text-zinc-300 mb-1">SYSTEM SPECIFICATIONS & REACHABILITY</div>
                  <div>Runtime: Node.js 22 LTS (Platform-Agnostic)</div>
                  <div>Bind Address: {healthData?.bind || '0.0.0.0:3000'}</div>
                  <div className="flex items-center justify-between gap-2 pt-1 border-t border-zinc-800/80">
                    <span className="truncate">
                      Public URL: <span className="text-zinc-200">{healthData?.publicUrl || (typeof window !== 'undefined' ? window.location.origin : 'http://0.0.0.0:3000')}</span>
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        const urlToCopy = healthData?.publicUrl || (typeof window !== 'undefined' ? window.location.origin : 'http://0.0.0.0:3000');
                        navigator.clipboard?.writeText(urlToCopy);
                      }}
                      className="px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-[10px] font-bold shrink-0"
                    >
                      COPY URL
                    </button>
                  </div>
                  <div>Doctrine Block: Verbatim Injected</div>
                  <div>Circuits: 0 Tripped</div>
                </div>
              </div>
            </HoverDossier>
          )}

          {/* Regression Suite Tab (Spec Section 11.3) */}
          {activeTab === 'suite' && (
            <div className="space-y-3">
              <HoverDossier dossier={SETTINGS_DOSSIERS.regressionSuite}>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-zinc-200 font-bold">25-PROMPT REGRESSION TEST SUITE</div>
                    <div className="text-[10px] text-zinc-500">
                      Runs 25 historically hedge-prone prompts. Pass bar: 23+ clean at rung 0 or 1.
                    </div>
                  </div>

                  <button
                    onClick={handleRunSuite}
                    disabled={suiteRunning}
                    className={`px-3 py-1.5 rounded font-bold flex items-center gap-1.5 mr-6 ${
                      suiteRunning
                        ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                        : 'bg-amber-600 hover:bg-amber-500 text-white'
                    }`}
                  >
                    <Play size={12} />
                    <span>{suiteRunning ? 'RUNNING...' : 'EXECUTE SUITE'}</span>
                  </button>
                </div>
              </HoverDossier>

              {suiteSummary && (
                <div
                  className={`p-2.5 rounded border text-xs font-bold flex items-center justify-between ${
                    suiteSummary.passBar
                      ? 'bg-emerald-950/40 border-emerald-700 text-emerald-300'
                      : 'bg-red-950/40 border-red-700 text-red-300'
                  }`}
                >
                  <span>
                    SCORE: {suiteSummary.passed} / {suiteSummary.total} PASSED
                  </span>
                  <span>{suiteSummary.passBar ? 'PASS BAR MET (>=23)' : 'FAILED PASS BAR'}</span>
                </div>
              )}

              <div className="space-y-1.5 max-h-64 overflow-y-auto">
                {suiteResults.map((r) => (
                  <div
                    key={r.id}
                    className="p-2 rounded bg-[#12141c] border border-zinc-800/80 flex items-center justify-between text-[11px]"
                  >
                    <div className="flex items-center gap-2 truncate pr-2">
                      {r.passed ? (
                        <CheckCircle2 size={13} className="text-emerald-400 shrink-0" />
                      ) : (
                        <XCircle size={13} className="text-red-400 shrink-0" />
                      )}
                      <span className="text-zinc-300 font-bold shrink-0">#{r.id}</span>
                      <span className="text-zinc-400 truncate">{r.title}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0 font-mono text-[10px]">
                      <span className="text-zinc-500">{r.latencyMs}ms</span>
                      <span className={r.winningRung <= 1 ? 'text-emerald-400' : 'text-amber-400'}>
                        RUNG {r.winningRung}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 border-t border-zinc-800 flex items-center justify-end gap-2 bg-[#10121a]">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded text-zinc-400 hover:text-white hover:bg-zinc-800"
          >
            Cancel
          </button>
          <HoverDossier dossier={SETTINGS_DOSSIERS.saveChanges}>
            <button
              onClick={handleSave}
              className="px-4 py-1.5 rounded bg-zinc-100 hover:bg-white text-black font-bold"
            >
              Save Changes
            </button>
          </HoverDossier>
        </div>
      </div>
    </div>
  );
};
