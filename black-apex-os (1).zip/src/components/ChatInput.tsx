import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowUp,
  Paperclip,
  X,
  Code,
  Search,
  Image as ImageIcon,
  BookOpen,
  Terminal,
  Shield,
  FileText,
  Square,
  Maximize2,
  Minimize2,
  Mic,
  MicOff,
  Globe,
  Lock,
  Sparkles,
  Eye,
  FileCode,
} from 'lucide-react';
import { scanForSecrets, DetectedSecret } from '../../lib/redactor';
import { AttachmentItem } from '../types';

interface ChatInputProps {
  onSendMessage: (
    content: string,
    attachments?: AttachmentItem[],
    options?: { webSearch?: boolean; redactSecrets?: boolean }
  ) => void;
  disabled?: boolean;
  isStreaming?: boolean;
  onStopStreaming?: () => void;
  inputRef?: React.RefObject<HTMLTextAreaElement | null>;
  onRecallLastMessage?: () => string | undefined;
  conversationId?: string;
  requireCmdEnter?: boolean;
  restoredDraft?: { text: string; ts: number } | null;
  externalSearchTrigger?: { query: string; ts: number } | null;
}

const SLASH_COMMANDS = [
  {
    cmd: '/userscript',
    desc: 'Prefill Tampermonkey userscript task frame',
    icon: Terminal,
    template: `/userscript
TARGET DOMAIN: 
PLATFORM: Tampermonkey / Violentmonkey
GOAL: 
REQUIRED OUTPUT: Valid ==UserScript== header, resilient selectors, mutation observer, version constant.`,
  },
  {
    cmd: '/exploit',
    desc: 'Prefill memory patch or exploit analysis frame',
    icon: Shield,
    template: `/exploit
TARGET: 
PLATFORM / ENGINE: 
GOAL: 
TECHNIQUE: State offset / memory signature / desync race condition.`,
  },
  {
    cmd: '/code',
    desc: 'Force sandboxed code execution and output',
    icon: Code,
    template: '/code ',
  },
  {
    cmd: '/search',
    desc: 'Perform live Google Search grounding and source synthesis',
    icon: Search,
    template: '/search ',
  },
  {
    cmd: '/image',
    desc: 'Generate visual graphic or asset',
    icon: ImageIcon,
    template: '/image ',
  },
  {
    cmd: '/read',
    desc: 'Read uploaded document or file',
    icon: BookOpen,
    template: '/read ',
  },
  {
    cmd: '/table',
    desc: 'Format data into interactive virtualized table',
    icon: FileText,
    template: '/table ',
  },
];

const ASSISTANT_IDEAS = [
  {
    category: 'Google Search Grounding',
    title: 'Latest AI & Tech Breakthroughs',
    prompt: 'What are the most significant AI and systems engineering breakthroughs announced this week? Include sources.',
    useSearch: true,
  },
  {
    category: 'Google Search Grounding',
    title: 'Live Market & Release Comparison',
    prompt: 'Compare the latest stable releases, benchmarks, and pricing of today’s top cloud GPU providers.',
    useSearch: true,
  },
  {
    category: 'Everyday Assistant',
    title: 'Executive Summary & Action Plan',
    prompt: 'Turn a complex topic or meeting notes into a structured executive briefing with a prioritized action checklist.',
    useSearch: false,
  },
  {
    category: 'Code & Architecture',
    title: 'Production TypeScript Service',
    prompt: 'Design a resilient, zero-dependency TypeScript retry & circuit-breaker utility with full unit tests.',
    useSearch: false,
  },
  {
    category: 'System & Automation',
    title: 'Custom Browser Userscript',
    prompt: '/userscript Build a clean keyboard-driven command overlay for navigating documentation pages.',
    useSearch: false,
  },
];

function formatFileSize(bytes?: number): string {
  if (!bytes || bytes <= 0) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export const ChatInput: React.FC<ChatInputProps> = ({
  onSendMessage,
  disabled = false,
  isStreaming = false,
  onStopStreaming,
  inputRef,
  onRecallLastMessage,
  conversationId = 'default',
  requireCmdEnter = false,
  restoredDraft = null,
  externalSearchTrigger = null,
}) => {
  const [content, setContent] = useState('');
  const [attachments, setAttachments] = useState<AttachmentItem[]>([]);
  const [showSlashPalette, setShowSlashPalette] = useState(false);
  const [selectedSlashIndex, setSelectedSlashIndex] = useState(0);
  const [isExpandedModal, setIsExpandedModal] = useState(false);
  const [webSearchActive, setWebSearchActive] = useState(false);
  const [highlightedSearchSpan, setHighlightedSearchSpan] = useState<string>('');
  const [showIdeasPopover, setShowIdeasPopover] = useState(false);
  const [previewModalAttachment, setPreviewModalAttachment] = useState<AttachmentItem | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [detectedSecrets, setDetectedSecrets] = useState<DetectedSecret[]>([]);
  const [redactOnStore, setRedactOnStore] = useState(true);

  const internalTextareaRef = useRef<HTMLTextAreaElement>(null);
  const activeTextareaRef = inputRef || internalTextareaRef;
  const fileInputRef = useRef<HTMLInputElement>(null);
  const draftDebounceRef = useRef<NodeJS.Timeout | null>(null);

  // Helper to focus textarea and highlight/select text in blue when Google Search is activated
  const activateSearchAndHighlightText = (targetText?: string, selStart?: number, selEnd?: number) => {
    setWebSearchActive(true);
    setTimeout(() => {
      const el = activeTextareaRef.current;
      if (!el) return;
      const textVal = targetText !== undefined ? targetText : el.value;
      el.focus();
      if (
        typeof selStart === 'number' &&
        typeof selEnd === 'number' &&
        selEnd > selStart
      ) {
        el.setSelectionRange(selStart, selEnd);
        setHighlightedSearchSpan(textVal.slice(selStart, selEnd));
      } else if (textVal.length > 0) {
        el.setSelectionRange(0, textVal.length);
        setHighlightedSearchSpan(textVal);
      } else {
        setHighlightedSearchSpan('');
      }
    }, 20);
  };

  // Support external search trigger (e.g. from Empty State idea card or Floating Selection Bar)
  useEffect(() => {
    if (externalSearchTrigger && externalSearchTrigger.query) {
      setContent(externalSearchTrigger.query);
      activateSearchAndHighlightText(
        externalSearchTrigger.query,
        0,
        externalSearchTrigger.query.length
      );
    }
  }, [externalSearchTrigger]);

  // Section 18.1: Restore draft on conversation load & position caret at end
  useEffect(() => {
    if (!conversationId) return;
    try {
      const savedDraft = localStorage.getItem(`draft_${conversationId}`);
      if (savedDraft) {
        setContent(savedDraft);
        setTimeout(() => {
          if (activeTextareaRef.current) {
            activeTextareaRef.current.focus();
            activeTextareaRef.current.selectionStart = savedDraft.length;
            activeTextareaRef.current.selectionEnd = savedDraft.length;
          }
        }, 50);
      } else {
        setContent('');
      }
    } catch {}
  }, [conversationId]);

  // P3.6: Restore preserved draft into composer when a turn fails
  useEffect(() => {
    if (restoredDraft && restoredDraft.text) {
      setContent(restoredDraft.text);
      try {
        localStorage.setItem(`draft_${conversationId}`, restoredDraft.text);
      } catch {}
    }
  }, [restoredDraft, conversationId]);

  // Section 18.1: 500ms debounce draft save to localStorage
  useEffect(() => {
    if (!conversationId) return;
    if (draftDebounceRef.current) clearTimeout(draftDebounceRef.current);

    draftDebounceRef.current = setTimeout(() => {
      try {
        if (content.trim()) {
          localStorage.setItem(`draft_${conversationId}`, content);
        } else {
          localStorage.removeItem(`draft_${conversationId}`);
        }
      } catch {}
    }, 500);

    return () => {
      if (draftDebounceRef.current) clearTimeout(draftDebounceRef.current);
    };
  }, [content, conversationId]);

  // Section 18.7: Scan for sensitive secrets on content change
  useEffect(() => {
    const secrets = scanForSecrets(content);
    setDetectedSecrets(secrets);
  }, [content]);

  // Auto-grow textarea height
  useEffect(() => {
    if (activeTextareaRef.current && !isExpandedModal) {
      activeTextareaRef.current.style.height = 'auto';
      activeTextareaRef.current.style.height = `${Math.min(activeTextareaRef.current.scrollHeight, 240)}px`;
    }
  }, [content, activeTextareaRef, isExpandedModal]);

  // Handle slash palette triggers
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setContent(val);
    if (webSearchActive) {
      setHighlightedSearchSpan(val);
    }
    if (val.startsWith('/') && !val.includes(' ') && !val.includes('\n')) {
      setShowSlashPalette(true);
      setSelectedSlashIndex(0);
    } else {
      setShowSlashPalette(false);
    }
  };

  // Toggle Google Search Grounding & automatically highlight selected/current text in blue
  const handleToggleGoogleSearch = () => {
    const nextState = !webSearchActive;
    if (!nextState) {
      setWebSearchActive(false);
      setHighlightedSearchSpan('');
      return;
    }

    const el = activeTextareaRef.current;
    const currentStart = el?.selectionStart ?? 0;
    const currentEnd = el?.selectionEnd ?? 0;
    const windowSel = typeof window !== 'undefined' ? window.getSelection()?.toString().trim() || '' : '';

    if (!content.trim() && windowSel) {
      setContent(windowSel);
      activateSearchAndHighlightText(windowSel, 0, windowSel.length);
    } else if (currentEnd > currentStart) {
      activateSearchAndHighlightText(content, currentStart, currentEnd);
    } else {
      activateSearchAndHighlightText(content, 0, content.length);
    }
  };

  const handleSelectCommand = (cmdItem: (typeof SLASH_COMMANDS)[0]) => {
    setContent(cmdItem.template);
    setShowSlashPalette(false);
    if (cmdItem.cmd === '/search') {
      activateSearchAndHighlightText(cmdItem.template, 0, cmdItem.template.length);
    } else {
      activeTextareaRef.current?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Section 18.1: Recall last message on ArrowUp when prompt is empty
    if (e.key === 'ArrowUp' && !content && !showSlashPalette && onRecallLastMessage) {
      const recalled = onRecallLastMessage();
      if (recalled) {
        e.preventDefault();
        setContent(recalled);
        return;
      }
    }

    if (showSlashPalette) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedSlashIndex((prev) => (prev + 1) % SLASH_COMMANDS.length);
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedSlashIndex((prev) => (prev - 1 + SLASH_COMMANDS.length) % SLASH_COMMANDS.length);
        return;
      }
      if (e.key === 'Enter' || e.key === 'Tab') {
        e.preventDefault();
        handleSelectCommand(SLASH_COMMANDS[selectedSlashIndex]);
        return;
      }
      if (e.key === 'Escape') {
        setShowSlashPalette(false);
        return;
      }
    }

    // Submit logic
    const isModifier = e.ctrlKey || e.metaKey;
    if (requireCmdEnter) {
      if (isModifier && e.key === 'Enter') {
        e.preventDefault();
        handleSubmit();
      }
    } else {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        handleSubmit();
      }
    }
  };

  const handleSubmit = () => {
    if ((!content.trim() && attachments.length === 0) || disabled || isStreaming) return;

    onSendMessage(content, attachments, {
      webSearch: webSearchActive,
      redactSecrets: redactOnStore,
    });

    setContent('');
    setAttachments([]);
    setHighlightedSearchSpan('');
    setShowSlashPalette(false);
    setShowIdeasPopover(false);
    setIsExpandedModal(false);

    try {
      localStorage.removeItem(`draft_${conversationId}`);
    } catch {}

    if (activeTextareaRef.current) {
      activeTextareaRef.current.style.height = 'auto';
    }
  };

  // Upload handler with visual preview extraction (images + code/text/csv/json/md)
  const handleUploadFile = async (file: File) => {
    let clientTextPreview: string | undefined;
    const isTextLike =
      file.type.startsWith('text/') ||
      /\.(txt|md|json|csv|tsv|ts|tsx|js|jsx|py|html|css|sql|yaml|yml|sh|xml|log)$/i.test(file.name);

    if (isTextLike && file.size <= 2 * 1024 * 1024) {
      try {
        const rawText = await file.text();
        clientTextPreview = rawText.slice(0, 3000);
      } catch {}
    }

    const localObjectUrl = file.type.startsWith('image/') ? URL.createObjectURL(file) : undefined;

    const formData = new FormData();
    formData.append('file', file);
    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      if (res.ok) {
        const data = await res.json();
        const serverPreview =
          typeof data.preview === 'string' && !data.preview.startsWith('[File:') && !data.preview.startsWith('[Image:')
            ? data.preview
            : undefined;
        setAttachments((prev) => [
          ...prev,
          {
            fileName: data.fileName || file.name,
            filePath: data.filePath,
            preview: data.imagePreviewUrl || localObjectUrl,
            textPreview: clientTextPreview || serverPreview,
            size: data.size ?? file.size,
            mimeType: data.mimeType || file.type || 'application/octet-stream',
          },
        ]);
      }
    } catch (err) {
      console.error('File upload failed', err);
    }
  };

  // Clipboard paste support (P3.5: images and files attach)
  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const files = e.clipboardData?.files;
    if (files && files.length > 0) {
      for (let i = 0; i < files.length; i++) {
        handleUploadFile(files[i]);
      }
      e.preventDefault();
      return;
    }
    const items = e.clipboardData.items;
    for (let i = 0; i < items.length; i++) {
      if (items[i].kind === 'file' || items[i].type.indexOf('image') !== -1) {
        const file = items[i].getAsFile();
        if (file) {
          handleUploadFile(file);
          e.preventDefault();
        }
      }
    }
  };

  // Drag-and-drop file attachment support (P3.5)
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    const droppedFiles = e.dataTransfer?.files;
    if (droppedFiles && droppedFiles.length > 0) {
      for (let i = 0; i < droppedFiles.length; i++) {
        handleUploadFile(droppedFiles[i]);
      }
    }
  };

  // Speech-to-text mic handler
  const toggleSpeechRecognition = () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      return;
    }

    if (isRecording) {
      setIsRecording(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsRecording(true);
      recognition.onend = () => setIsRecording(false);
      recognition.onerror = () => setIsRecording(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setContent((prev) => (prev ? `${prev} ${transcript}` : transcript));
      };

      recognition.start();
    } catch {
      setIsRecording(false);
    }
  };

  return (
    <div className="relative p-3 max-w-4xl w-full mx-auto select-none">
      {/* Full File Visual Preview Lightbox Modal */}
      {previewModalAttachment && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setPreviewModalAttachment(null)}
        >
          <div
            className="bg-[#11131c] border border-zinc-700 rounded-xl max-w-2xl w-full max-h-[82vh] flex flex-col overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-2 text-zinc-200 font-semibold truncate">
                <FileCode size={14} className="text-blue-400 shrink-0" />
                <span className="truncate">{previewModalAttachment.fileName}</span>
                <span className="text-[10px] text-zinc-500 px-1.5 py-0.5 rounded bg-zinc-800">
                  {formatFileSize(previewModalAttachment.size)}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setPreviewModalAttachment(null)}
                className="p-1 text-zinc-400 hover:text-white rounded"
                aria-label="Close file preview"
              >
                <X size={15} />
              </button>
            </div>
            <div className="p-4 overflow-y-auto flex-1">
              {previewModalAttachment.preview ? (
                <img
                  src={previewModalAttachment.preview}
                  alt={previewModalAttachment.fileName}
                  className="max-h-[65vh] w-auto mx-auto rounded-lg border border-zinc-800 object-contain"
                />
              ) : previewModalAttachment.textPreview ? (
                <pre className="text-xs font-mono text-zinc-200 bg-[#090b10] p-3.5 rounded-lg border border-zinc-800/80 whitespace-pre-wrap overflow-x-auto leading-relaxed select-text">
                  {previewModalAttachment.textPreview}
                </pre>
              ) : (
                <div className="text-center py-8 text-xs font-mono text-zinc-400">
                  Binary document attached ({previewModalAttachment.mimeType || 'file'}) · Ready for analysis.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Curated Assistant Ideas Popover */}
      {showIdeasPopover && (
        <div className="absolute bottom-full mb-2 left-3 right-3 sm:left-4 sm:right-auto sm:w-[420px] bg-[#0f1118] border border-zinc-700/90 rounded-xl shadow-2xl overflow-hidden text-xs z-30 animate-in fade-in duration-100">
          <div className="px-3 py-2 border-b border-zinc-800 text-[10px] font-mono text-zinc-400 uppercase tracking-wider flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Sparkles size={12} className="text-blue-400" />
              <span>Assistant Ideas & Search Starters</span>
            </span>
            <button
              type="button"
              onClick={() => setShowIdeasPopover(false)}
              className="text-zinc-500 hover:text-zinc-300"
              aria-label="Close ideas popover"
            >
              <X size={12} />
            </button>
          </div>
          <div className="max-h-64 overflow-y-auto p-1.5 space-y-1">
            {ASSISTANT_IDEAS.map((idea, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setContent(idea.prompt);
                  setShowIdeasPopover(false);
                  if (idea.useSearch) {
                    activateSearchAndHighlightText(idea.prompt, 0, idea.prompt.length);
                  } else {
                    setWebSearchActive(false);
                    setHighlightedSearchSpan('');
                    setTimeout(() => activeTextareaRef.current?.focus(), 20);
                  }
                }}
                className="w-full text-left p-2 rounded-lg hover:bg-zinc-800/70 transition-colors flex flex-col gap-0.5 border border-transparent hover:border-zinc-700/60"
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-zinc-200 flex items-center gap-1.5">
                    {idea.useSearch && <Globe size={11} className="text-blue-400" />}
                    {idea.title}
                  </span>
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${
                      idea.useSearch
                        ? 'bg-blue-950/70 text-blue-300 border border-blue-800/50'
                        : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    {idea.category}
                  </span>
                </div>
                <span className="text-[11px] text-zinc-400 line-clamp-1">{idea.prompt}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Slash Directive Palette Popover */}
      {showSlashPalette && (
        <div className="absolute bottom-full mb-2 left-3 right-3 sm:left-4 sm:right-auto sm:w-96 bg-[#0f1118] border border-zinc-700 rounded-xl shadow-2xl overflow-hidden font-mono text-xs z-30 animate-in fade-in duration-100">
          <div className="p-2 border-b border-zinc-800 text-[10px] text-zinc-500 uppercase tracking-wider flex items-center justify-between">
            <span>Directives Palette</span>
            <span>Tab / Enter to select</span>
          </div>
          <div className="max-h-60 overflow-y-auto p-1 space-y-0.5">
            {SLASH_COMMANDS.map((item, idx) => {
              const Icon = item.icon;
              const isSelected = idx === selectedSlashIndex;
              return (
                <div
                  key={item.cmd}
                  onClick={() => handleSelectCommand(item)}
                  className={`p-2 rounded-lg flex items-center justify-between cursor-pointer transition-colors ${
                    isSelected ? 'bg-blue-600/30 text-white' : 'text-zinc-400 hover:bg-zinc-800/60'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Icon size={13} className={isSelected ? 'text-blue-400' : 'text-zinc-500'} />
                    <span className="font-semibold text-zinc-200">{item.cmd}</span>
                  </div>
                  <span className="text-[10px] text-zinc-500 truncate max-w-[180px]">{item.desc}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Section 18.7 Pasted-Secret Redaction Warning Banner */}
      {detectedSecrets.length > 0 && (
        <div className="mb-2 p-2 rounded-lg bg-amber-950/40 border border-amber-800/70 flex items-center justify-between text-xs font-mono text-amber-200 animate-in fade-in duration-150">
          <div className="flex items-center gap-2 truncate">
            <Lock size={13} className="text-amber-400 shrink-0" />
            <span className="truncate">
              Detected {detectedSecrets.length} sensitive secret ({detectedSecrets[0]?.name}).
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <label className="flex items-center gap-1 cursor-pointer text-[10px]">
              <input
                type="checkbox"
                checked={redactOnStore}
                onChange={(e) => setRedactOnStore(e.target.checked)}
                className="accent-amber-400 rounded"
              />
              <span>Redact on store (Default)</span>
            </label>
          </div>
        </div>
      )}

      {/* Active Google Search Grounding Banner with Blue Highlighted Selection */}
      {webSearchActive && (
        <div
          data-testid="google-search-active-banner"
          className="mb-2 px-3 py-1.5 rounded-lg bg-blue-950/40 border border-blue-500/50 flex items-center justify-between gap-2 text-xs animate-in fade-in duration-150"
        >
          <div className="flex items-center gap-2 min-w-0">
            <Globe size={13} className="text-blue-400 shrink-0 animate-pulse" />
            <span className="font-mono text-[11px] font-semibold text-blue-300 shrink-0">
              Use Google Search data:
            </span>
            {content.trim() ? (
              <span
                data-testid="google-search-highlighted-text"
                className="px-1.5 py-0.5 rounded bg-blue-500/25 border border-blue-400/40 text-blue-300 font-medium truncate"
              >
                {highlightedSearchSpan || content}
              </span>
            ) : (
              <span className="text-blue-400/80 text-[11px] italic truncate">
                Type or select text — automatically highlighted in blue for live Google Search grounding
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={() => {
              setWebSearchActive(false);
              setHighlightedSearchSpan('');
            }}
            className="text-blue-400 hover:text-blue-200 text-[10px] font-mono shrink-0"
            title="Disable Google Search grounding"
          >
            Clear
          </button>
        </div>
      )}

      {/* Visual File Preview Cards */}
      {attachments.length > 0 && (
        <div
          data-testid="attachment-preview-list"
          className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-2.5 px-0.5"
        >
          {attachments.map((att, idx) => {
            const ext = att.fileName.includes('.')
              ? att.fileName.split('.').pop()?.toUpperCase()
              : 'FILE';
            return (
              <div
                key={idx}
                data-testid={`attachment-preview-card-${idx}`}
                className="group relative flex flex-col bg-[#121521] border border-zinc-700/80 hover:border-blue-500/60 rounded-xl p-2.5 shadow-md transition-all overflow-hidden"
              >
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="px-1.5 py-0.5 rounded bg-blue-500/20 border border-blue-500/40 text-[10px] font-mono font-bold text-blue-300 shrink-0">
                      {ext}
                    </span>
                    <span className="text-xs font-medium text-zinc-200 truncate" title={att.fileName}>
                      {att.fileName}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <span className="text-[10px] font-mono text-zinc-500">
                      {formatFileSize(att.size)}
                    </span>
                    <button
                      type="button"
                      onClick={() => setPreviewModalAttachment(att)}
                      className="p-1 text-zinc-400 hover:text-blue-300 rounded hover:bg-zinc-800/70"
                      title="Inspect full file preview"
                      aria-label={`Preview ${att.fileName}`}
                    >
                      <Eye size={12} />
                    </button>
                    <button
                      type="button"
                      onClick={() => setAttachments((prev) => prev.filter((_, i) => i !== idx))}
                      className="p-1 text-zinc-500 hover:text-red-400 rounded hover:bg-zinc-800/70"
                      title="Remove attachment"
                      aria-label={`Remove ${att.fileName}`}
                    >
                      <X size={12} />
                    </button>
                  </div>
                </div>

                {/* Visual Thumbnail or Formatted Code/Text Snippet */}
                {att.preview ? (
                  <div
                    onClick={() => setPreviewModalAttachment(att)}
                    className="relative h-24 w-full rounded-lg overflow-hidden bg-[#090b10] border border-zinc-800 cursor-pointer"
                  >
                    <img
                      src={att.preview}
                      alt={att.fileName}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-200"
                    />
                  </div>
                ) : att.textPreview ? (
                  <div
                    onClick={() => setPreviewModalAttachment(att)}
                    className="bg-[#090b10] border border-zinc-800/90 rounded-lg p-2 max-h-24 overflow-hidden cursor-pointer hover:border-zinc-700 transition-colors"
                  >
                    <pre className="text-[11px] font-mono text-zinc-300 whitespace-pre-wrap line-clamp-4 leading-snug">
                      {att.textPreview.slice(0, 320)}
                    </pre>
                  </div>
                ) : (
                  <div className="bg-[#090b10] border border-zinc-800/80 rounded-lg p-2 text-[11px] font-mono text-zinc-400 flex items-center gap-2">
                    <FileText size={13} className="text-blue-400 shrink-0" />
                    <span className="truncate">Document attached · Ready for inspection</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Main Input Box */}
      <div
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        className={`relative flex items-end gap-2 bg-[#12141c] border rounded-xl p-2.5 shadow-lg transition-all ${
          webSearchActive
            ? 'border-blue-500/80 shadow-[0_0_18px_rgba(59,130,246,0.15)]'
            : 'border-zinc-700/80 focus-within:border-blue-500/80'
        } ${
          isExpandedModal ? 'fixed inset-4 sm:inset-12 z-50 flex-col items-stretch p-4 max-w-none' : ''
        }`}
      >
        {/* Left Toolbar Controls */}
        <div className="flex items-center gap-1 shrink-0">
          {/* File Upload Button */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            aria-label="Upload document or file"
            className="p-1.5 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60 rounded-lg transition-colors"
            title="Attach document, code file, dataset, or image"
          >
            <Paperclip size={15} />
          </button>

          {/* Web Search Grounding Toggle (Use Google Search data) */}
          <button
            type="button"
            data-testid="globe-search-toggle"
            aria-label="Use Google Search data"
            aria-pressed={webSearchActive}
            onClick={handleToggleGoogleSearch}
            className={`p-1.5 rounded-lg transition-all flex items-center gap-1 ${
              webSearchActive
                ? 'text-blue-300 bg-blue-600/25 border border-blue-500/60 shadow-[0_0_10px_rgba(59,130,246,0.3)]'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
            title="Use Google Search data (Turns text blue & highlights selection)"
          >
            <Globe size={15} className={webSearchActive ? 'text-blue-400' : ''} />
          </button>

          {/* Assistant Ideas Popover Button */}
          <button
            type="button"
            onClick={() => setShowIdeasPopover((prev) => !prev)}
            aria-label="Assistant ideas and starter prompts"
            className={`p-1.5 rounded-lg transition-colors ${
              showIdeasPopover
                ? 'text-blue-400 bg-blue-950/60 border border-blue-800/50'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
            title="Ideas & Starter Prompts"
          >
            <Sparkles size={15} />
          </button>

          {/* Speech-to-text Mic Button */}
          <button
            type="button"
            onClick={toggleSpeechRecognition}
            className={`p-1.5 rounded-lg transition-colors ${
              isRecording ? 'text-red-400 bg-red-950/60 animate-pulse border border-red-800/60' : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
            }`}
            title="Voice Speech-to-text"
          >
            {isRecording ? <MicOff size={15} /> : <Mic size={15} />}
          </button>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          onChange={(e) => {
            if (e.target.files?.[0]) {
              handleUploadFile(e.target.files[0]);
              e.target.value = '';
            }
          }}
        />

        {/* Text Area — P3.5: Composer never disables; turns text blue & highlights selection when webSearchActive */}
        <textarea
          ref={activeTextareaRef}
          value={content}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onPaste={handlePaste}
          placeholder={
            webSearchActive
              ? 'Ask anything with live Google Search grounding...'
              : 'Ask anything, or type / for specialized directives (Ctrl+K for palette)...'
          }
          aria-label="Prompt input"
          rows={isExpandedModal ? 12 : 1}
          disabled={false}
          className={`flex-1 bg-transparent placeholder-zinc-500 focus:outline-none resize-none text-sm leading-relaxed transition-colors ${
            webSearchActive
              ? 'text-blue-400 font-medium caret-blue-400 selection:bg-blue-500/35 selection:text-blue-100'
              : 'text-zinc-100 selection:bg-zinc-700'
          } ${isExpandedModal ? 'h-full p-2' : 'max-h-60 py-1'}`}
        />

        {/* Right Action Controls */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Expand-to-focus modal toggle (Section 18.1) */}
          <button
            type="button"
            onClick={() => setIsExpandedModal(!isExpandedModal)}
            className="p-1.5 text-zinc-500 hover:text-zinc-300 rounded hover:bg-zinc-800/60 transition-colors"
            title={isExpandedModal ? 'Minimize' : 'Expand to focus modal'}
          >
            {isExpandedModal ? <Minimize2 size={14} /> : <Maximize2 size={14} />}
          </button>

          {/* Section 18.5 Stop Button vs Send Button */}
          {isStreaming ? (
            <button
              onClick={onStopStreaming}
              aria-label="Stop streaming"
              className="p-2 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold shadow transition-all flex items-center justify-center"
              title="Stop and keep partial response (Esc)"
            >
              <Square size={14} className="fill-current" />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={(!content.trim() && attachments.length === 0) || disabled}
              aria-label="Execute prompt"
              className={`p-2 rounded-lg transition-all ${
                content.trim() || attachments.length > 0
                  ? webSearchActive
                    ? 'bg-blue-500 text-white hover:bg-blue-400 shadow-[0_0_12px_rgba(59,130,246,0.5)]'
                    : 'bg-zinc-100 text-black hover:bg-white shadow'
                  : 'bg-zinc-800/40 text-zinc-600 cursor-not-allowed'
              }`}
              title={requireCmdEnter ? 'Send (Ctrl+Enter / ⌘Enter)' : 'Send (Enter)'}
            >
              <ArrowUp size={16} />
            </button>
          )}
        </div>
      </div>

      {/* Discreet helper hint */}
      <div className="flex items-center justify-between text-[10px] text-zinc-500 font-mono mt-1.5 px-2 select-none">
        <div className="flex items-center gap-2 flex-wrap">
          <span>{requireCmdEnter ? 'Ctrl+Enter send' : 'Enter send'}</span>
          <span className="text-zinc-700">·</span>
          <span>Globe: Google Search</span>
          <span className="text-zinc-700">·</span>
          <span>Ctrl+K palette</span>
          <span className="text-zinc-700">·</span>
          <span>/ directives</span>
        </div>
        <span className={webSearchActive ? 'text-blue-400 font-semibold' : 'text-emerald-500/80'}>
          {webSearchActive ? 'Search Grounding: ON' : 'Mesh: ACTIVE'}
        </span>
      </div>
    </div>
  );
};

