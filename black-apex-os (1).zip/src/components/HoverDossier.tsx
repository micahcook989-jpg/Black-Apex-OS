import React, { useState, useRef, useEffect } from 'react';
import { Info, X, Clock, HelpCircle, CheckCircle } from 'lucide-react';

export interface DossierContent {
  title: string;
  whatItDoes: string;
  howToUseIt: string;
  whatItsUsedFor: string;
}

interface HoverDossierProps {
  dossier: DossierContent;
  children: React.ReactNode;
  className?: string;
  placement?: 'top' | 'bottom' | 'auto';
  hoverThresholdMs?: number; // default 6000ms
}

export const HoverDossier: React.FC<HoverDossierProps> = ({
  dossier,
  children,
  className = '',
  placement = 'auto',
  hoverThresholdMs = 6000,
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [hoverProgress, setHoverProgress] = useState(0); // 0 to 100
  const [isOpen, setIsOpen] = useState(false);
  const [isPinned, setIsPinned] = useState(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const startTimeRef = useRef<number>(0);

  const clearTimers = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setHoverProgress(0);
  };

  const handleMouseEnter = () => {
    if (isPinned) return;
    setIsHovered(true);
    startTimeRef.current = Date.now();

    // Interval to calculate precise countdown / percentage
    intervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startTimeRef.current;
      const pct = Math.min(100, Math.round((elapsed / hoverThresholdMs) * 100));
      setHoverProgress(pct);
    }, 50);

    // Trigger after exactly 6 seconds (6000ms)
    timerRef.current = setTimeout(() => {
      setIsOpen(true);
      clearTimers();
    }, hoverThresholdMs);
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    clearTimers();
    if (!isPinned) {
      setIsOpen(false);
    }
  };

  const toggleManualOpen = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsPinned(!isOpen);
    setIsOpen(!isOpen);
    clearTimers();
  };

  useEffect(() => {
    return () => clearTimers();
  }, []);

  const secondsRemaining = Math.max(0, ((hoverThresholdMs - (hoverProgress / 100) * hoverThresholdMs) / 1000)).toFixed(1);

  return (
    <div
      ref={containerRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className={`relative ${className}`}
    >
      {children}

      {/* 6-Second Charging Hover Progress Indicator */}
      {isHovered && !isOpen && (
        <div className="absolute -top-6 right-2 z-30 pointer-events-none flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#10131d] border border-blue-500/50 text-[10px] font-mono text-blue-300 shadow-xl backdrop-blur animate-in fade-in duration-150">
          <Clock size={10} className="animate-spin text-blue-400" />
          <span>HOLD 6S: {secondsRemaining}s</span>
          <div className="w-10 h-1 bg-zinc-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-500 transition-all duration-75"
              style={{ width: `${hoverProgress}%` }}
            />
          </div>
        </div>
      )}

      {/* Manual instant info trigger glyph */}
      <button
        type="button"
        onClick={toggleManualOpen}
        aria-label={`Detailed info for ${dossier.title}`}
        className="absolute top-2 right-2 p-1 text-zinc-500 hover:text-blue-400 hover:bg-zinc-800/60 rounded z-10 transition-colors"
        title="Click to view deep dossier immediately (or hover for 6s)"
      >
        <HelpCircle size={12} />
      </button>

      {/* The 6-Second Hover Dossier Card with Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-[2px] animate-in fade-in duration-100"
          onClick={(e) => {
            e.stopPropagation();
            setIsOpen(false);
            setIsPinned(false);
          }}
        >
          <div
            role="tooltip"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md p-4 bg-[#090b12] border border-blue-500/80 rounded-xl shadow-[0_0_40px_rgba(0,0,0,0.9)] text-xs font-mono text-zinc-300 space-y-3 animate-in zoom-in-95 duration-150 select-text"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2.5">
              <div className="flex items-center gap-2 truncate pr-2">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500 animate-pulse shrink-0" />
                <span className="font-bold text-zinc-100 tracking-wider text-xs truncate">
                  {dossier.title}
                </span>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="px-2 py-0.5 bg-blue-950/80 border border-blue-800/80 text-blue-300 text-[10px] rounded font-bold uppercase tracking-wider">
                  6S DOSSIER
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setIsOpen(false);
                    setIsPinned(false);
                  }}
                  className="p-1 hover:text-white rounded hover:bg-zinc-800 text-zinc-400"
                  title="Dismiss"
                >
                  <X size={14} />
                </button>
              </div>
            </div>

            {/* 1. Exactly what it does */}
            <div className="space-y-1">
              <div className="text-[10px] font-bold text-blue-400 uppercase tracking-wider flex items-center gap-1.5">
                <span className="text-blue-500 font-mono">01 //</span> EXACTLY WHAT IT DOES
              </div>
              <p className="text-zinc-200 text-xs leading-relaxed font-sans bg-[#11131c] p-2.5 rounded-lg border border-zinc-800/80">
                {dossier.whatItDoes}
              </p>
            </div>

            {/* 2. How to use it */}
            <div className="space-y-1">
              <div className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                <span className="text-emerald-500 font-mono">02 //</span> HOW TO USE IT
              </div>
              <p className="text-zinc-200 text-xs leading-relaxed font-sans bg-[#11131c] p-2.5 rounded-lg border border-zinc-800/80">
                {dossier.howToUseIt}
              </p>
            </div>

            {/* 3. What it's used for */}
            <div className="space-y-1">
              <div className="text-[10px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                <span className="text-amber-500 font-mono">03 //</span> WHAT IT'S USED FOR
              </div>
              <p className="text-zinc-200 text-xs leading-relaxed font-sans bg-[#11131c] p-2.5 rounded-lg border border-zinc-800/80">
                {dossier.whatItsUsedFor}
              </p>
            </div>

            <div className="text-[10px] text-zinc-500 pt-1.5 border-t border-zinc-800 flex items-center justify-between">
              <span>Auto-revealed after 6s hover inspection</span>
              <span className="text-zinc-400 font-bold">BLACK APEX OS</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
