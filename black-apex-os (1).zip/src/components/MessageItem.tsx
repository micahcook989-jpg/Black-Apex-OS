import React, { useState } from 'react';
import {
  Copy,
  Check,
  RotateCw,
  GitBranch,
  Volume2,
  Trash2,
  ShieldAlert,
  FileCode,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Sliders,
  Sparkles,
  Play,
  List,
  Globe,
  Shuffle,
  FileText,
  Eye,
  X,
} from 'lucide-react';
import { Message, MessageReceipt, AttachmentItem } from '../types';

interface MessageItemProps {
  message: Message;
  isLatest: boolean;
  onCopy: (text: string) => void;
  onRegenerate: (messageId: string) => void;
  onBranch: (messageId: string) => void;
  onHedgeReport: (messageId: string, currentRung?: number) => void;
  onDelete: (messageId: string) => void;
  onSpeak: (text: string) => void;
  onSelectChip?: (chipText: string) => void;
  onCreateArtifactFromCode?: (title: string, type: any, code: string) => void;
  onContinue?: () => void;
  onRetryTurn?: (messageId: string, retryPrompt?: string) => void;
}

const RANDOM_FOLLOWUP_POOL = [
  'Give me a concrete step-by-step example',
  'Break this down into a comparison table',
  'What are the most common pitfalls to avoid?',
  'Explain the underlying architecture in depth',
  'Provide a quick action checklist I can follow',
  'How would this scale in a production environment?',
  'Summarize the key pros and cons',
  'Write unit tests for this implementation',
  'Add strict error handling and edge cases',
  'Optimize for latency and memory efficiency',
  'Show a real-world integration pattern',
  'What are the security implications to consider?',
];

function sampleRandomFollowUps(currentChips: string[], content: string): string[] {
  const isCode = /```|function\s+|const\s+|class\s+|import\s+/.test(content);
  const pool = isCode
    ? [
        'Write unit tests for this implementation',
        'Add strict error handling and edge cases',
        'Optimize for latency and memory efficiency',
        'Show a real-world usage example',
        'Refactor into a reusable modular service',
        'Add TypeScript strict types and JSDoc comments',
        'Explain potential concurrency or race conditions',
        'Benchmark this approach against alternatives',
      ]
    : RANDOM_FOLLOWUP_POOL;

  const filtered = pool.filter((item) => !currentChips.includes(item));
  const source = filtered.length >= 3 ? filtered : pool;
  const copy = [...source];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy.slice(0, 3);
}

function formatBytes(bytes?: number): string {
  if (!bytes || bytes <= 0) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

const MessageItemComponent: React.FC<MessageItemProps> = ({
  message,
  isLatest,
  onCopy,
  onRegenerate,
  onBranch,
  onHedgeReport,
  onDelete,
  onSpeak,
  onSelectChip,
  onCreateArtifactFromCode,
  onContinue,
  onRetryTurn,
}) => {
  const [copied, setCopied] = useState(false);
  const [showReceipts, setShowReceipts] = useState(false);
  const [showRaw, setShowRaw] = useState(false);
  const [dismissedChips, setDismissedChips] = useState(false);
  const [showToc, setShowToc] = useState(false);
  const [customRandomChips, setCustomRandomChips] = useState<string[] | null>(null);
  const [expandedAttachment, setExpandedAttachment] = useState<AttachmentItem | null>(null);

  const isUser = message.role === 'user';
  const displayedContent = showRaw && message.rawContent ? message.rawContent : message.content;
  const wordCount = displayedContent ? displayedContent.trim().split(/\s+/).filter(Boolean).length : 0;

  const activeChips = React.useMemo(() => {
    if (customRandomChips) return customRandomChips;
    if (message.suggestedChips && message.suggestedChips.length > 0) return message.suggestedChips;
    if (!isUser && !message.inFlight && wordCount > 8) {
      return sampleRandomFollowUps([], displayedContent || '');
    }
    return [];
  }, [customRandomChips, message.suggestedChips, isUser, message.inFlight, wordCount, displayedContent]);

  // Extract headings for Section 18.6 Outline / TOC (>800 words)
  const headings = React.useMemo(() => {
    if (wordCount <= 800 || !displayedContent) return [];
    const matches: { level: number; text: string }[] = [];
    const lines = displayedContent.split('\n');
    for (const l of lines) {
      const match = l.match(/^(#{1,3})\s+(.+)$/);
      if (match) {
        matches.push({ level: match[1].length, text: match[2] });
      }
    }
    return matches;
  }, [displayedContent, wordCount]);

  const formattedContent = React.useMemo(
    () => renderFormattedContent(displayedContent, onCreateArtifactFromCode),
    [displayedContent, onCreateArtifactFromCode]
  );

  const handleCopy = () => {
    onCopy(displayedContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <article
      className={`group relative py-4 px-4 sm:px-6 rounded-xl my-2.5 transition-all duration-150 ${
        isUser
          ? 'bg-[#121520]/95 border border-zinc-800/90 ml-auto max-w-[90%] sm:max-w-[80%] shadow-md'
          : 'bg-[#0d0f16]/90 border border-[#1c1f2b] w-full shadow-sm'
      }`}
      aria-label={`${isUser ? 'User message' : 'Assistant response'}`}
    >
      {/* Expanded Visual Attachment Modal */}
      {expandedAttachment && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setExpandedAttachment(null)}
        >
          <div
            className="bg-[#11131c] border border-zinc-700 rounded-xl max-w-2xl w-full max-h-[82vh] flex flex-col overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-2.5 border-b border-zinc-800 flex items-center justify-between text-xs font-mono">
              <div className="flex items-center gap-2 text-zinc-200 font-semibold truncate">
                <FileCode size={14} className="text-blue-400 shrink-0" />
                <span className="truncate">{expandedAttachment.fileName}</span>
                {expandedAttachment.size ? (
                  <span className="text-[10px] text-zinc-500 px-1.5 py-0.5 rounded bg-zinc-800">
                    {formatBytes(expandedAttachment.size)}
                  </span>
                ) : null}
              </div>
              <button
                type="button"
                onClick={() => setExpandedAttachment(null)}
                className="p-1 text-zinc-400 hover:text-white rounded"
                aria-label="Close attachment preview"
              >
                <X size={15} />
              </button>
            </div>
            <div className="p-4 overflow-y-auto flex-1">
              {expandedAttachment.preview ? (
                <img
                  src={expandedAttachment.preview}
                  alt={expandedAttachment.fileName}
                  className="max-h-[65vh] w-auto mx-auto rounded-lg border border-zinc-800 object-contain"
                />
              ) : expandedAttachment.textPreview ? (
                <pre className="text-xs font-mono text-zinc-200 bg-[#090b10] p-3.5 rounded-lg border border-zinc-800/80 whitespace-pre-wrap overflow-x-auto leading-relaxed select-text">
                  {expandedAttachment.textPreview}
                </pre>
              ) : (
                <div className="text-center py-8 text-xs font-mono text-zinc-400">
                  Attached file: {expandedAttachment.fileName}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Header bar / Role tag */}
      <div className="flex items-center justify-between text-[11px] font-mono mb-2.5 text-zinc-500 select-none">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-semibold tracking-wider text-zinc-300">
            {isUser ? 'YOU' : 'APEX'}
          </span>
          {(message.webSearchUsed || (message.groundingSources && message.groundingSources.length > 0)) && (
            <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-950/60 border border-blue-700/50 text-[10px] text-blue-300 font-mono">
              <Globe size={10} className="text-blue-400" />
              <span>Google Search Grounded</span>
            </span>
          )}
          {!isUser && message.inFlight && (
            <span className="flex items-center gap-1.5 px-1.5 py-0.5 rounded bg-blue-950/60 border border-blue-800/40 text-[9px] text-blue-300 font-mono tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-ping inline-block" />
              <span>PROCESSING</span>
            </span>
          )}
          {!isUser && message.stopped && (
            <span className="flex items-center gap-1.5 px-1.5 py-0.5 rounded bg-amber-950/40 border border-amber-800/50 text-[9px] text-amber-300 font-mono tracking-wider">
              <span>STOPPED</span>
            </span>
          )}
          {!isUser && !message.hideGlyphs && wordCount > 0 && (
            <span className="text-[10px] text-zinc-600 font-mono">
              {wordCount} words
            </span>
          )}
        </div>

        {/* Timestamp */}
        <span className="text-[10px] text-zinc-600">
          {new Date(message.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        </span>
      </div>

      {/* Table of Contents for Long Answers (>800 words, Section 18.6) */}
      {!isUser && headings.length > 0 && (
        <div className="mb-3 p-2.5 rounded-lg bg-[#090b10] border border-zinc-800/70 text-xs font-mono">
          <button
            onClick={() => setShowToc(!showToc)}
            className="flex items-center gap-1.5 text-zinc-400 hover:text-zinc-200 w-full text-left"
          >
            <List size={12} className="text-blue-400" />
            <span className="font-semibold">OUTLINE ({headings.length} sections)</span>
            <span className="ml-auto text-[10px] text-zinc-600">{showToc ? 'HIDE' : 'SHOW'}</span>
          </button>
          {showToc && (
            <div className="mt-2 pl-3 border-l border-zinc-800 space-y-1 text-[11px] text-zinc-400">
              {headings.map((h, i) => (
                <div key={i} style={{ paddingLeft: `${(h.level - 1) * 12}px` }} className="truncate hover:text-blue-300 cursor-pointer">
                  • {h.text}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Visual File Previews on Message */}
      {message.attachments && message.attachments.length > 0 && (
        <div
          data-testid="message-attachments-visual"
          className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-3"
        >
          {message.attachments.map((att, idx) => {
            const ext = att.fileName.includes('.')
              ? att.fileName.split('.').pop()?.toUpperCase()
              : 'FILE';
            return (
              <div
                key={idx}
                onClick={() => setExpandedAttachment(att)}
                className="flex flex-col bg-[#0b0d14] border border-zinc-700/70 hover:border-blue-500/60 rounded-xl p-2.5 cursor-pointer transition-all shadow-xs"
              >
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="px-1.5 py-0.5 rounded bg-blue-500/20 border border-blue-500/40 text-[10px] font-mono font-bold text-blue-300 shrink-0">
                      {ext}
                    </span>
                    <span className="text-xs font-medium text-zinc-200 truncate">
                      {att.fileName}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0 text-[10px] font-mono text-zinc-500">
                    {att.size ? <span>{formatBytes(att.size)}</span> : null}
                    <Eye size={12} className="text-zinc-400" />
                  </div>
                </div>

                {att.preview ? (
                  <div className="h-32 w-full rounded-lg overflow-hidden bg-[#07080c] border border-zinc-800">
                    <img
                      src={att.preview}
                      alt={att.fileName}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : att.textPreview ? (
                  <div className="bg-[#07080c] border border-zinc-800/90 rounded-lg p-2 max-h-28 overflow-hidden">
                    <pre className="text-[11px] font-mono text-zinc-300 whitespace-pre-wrap line-clamp-4 leading-snug">
                      {att.textPreview.slice(0, 320)}
                    </pre>
                  </div>
                ) : (
                  <div className="bg-[#07080c] border border-zinc-800/80 rounded-lg p-2 text-[11px] font-mono text-zinc-400 flex items-center gap-1.5">
                    <FileText size={12} className="text-blue-400 shrink-0" />
                    <span className="truncate">Click to view attached file</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Main Message Content */}
      <div
        className={`prose prose-invert max-w-none text-sm leading-relaxed break-words font-sans selection:bg-blue-500/30 ${
          isUser && message.webSearchUsed ? 'text-blue-300 font-medium' : 'text-zinc-200'
        }`}
      >
        {!isUser && message.inFlight && (!displayedContent || displayedContent.trim().length === 0) ? (
          /* Typing indicator wave when thinking before first chunk */
          <div className="flex items-center gap-3 py-2 text-zinc-400 select-none animate-in fade-in duration-200">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500 typing-dot-1 shadow-[0_0_8px_rgba(59,130,246,0.7)]" />
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 typing-dot-2 shadow-[0_0_8px_rgba(99,102,241,0.7)]" />
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 typing-dot-3 shadow-[0_0_8px_rgba(34,211,238,0.7)]" />
            </div>
            <span className="text-xs font-mono text-zinc-400 tracking-wide">
              Synthesizing response...
            </span>
          </div>
        ) : (
          <>
            {formattedContent}
            {!isUser && message.inFlight && (
              <span className="inline-flex items-center ml-1 align-middle">
                <span className="w-2 h-3.5 bg-blue-400 rounded-xs cursor-pulse shadow-[0_0_8px_rgba(59,130,246,0.8)]" />
              </span>
            )}
          </>
        )}
      </div>

      {/* Google Search Grounding Sources */}
      {!isUser && message.groundingSources && message.groundingSources.length > 0 && (
        <div
          data-testid="grounding-sources-section"
          className="mt-3.5 pt-2.5 border-t border-zinc-800/70 space-y-1.5"
        >
          <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider text-blue-400">
            <Globe size={11} />
            <span>Google Search Grounding Sources ({message.groundingSources.length})</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {message.groundingSources.map((src, idx) => {
              let hostname = src.title;
              try {
                hostname = new URL(src.uri).hostname.replace(/^www\./, '');
              } catch {}
              return (
                <a
                  key={idx}
                  href={src.uri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-blue-950/35 hover:bg-blue-900/50 border border-blue-800/50 text-xs text-blue-200 hover:text-white transition-colors max-w-[260px]"
                  title={src.title || src.uri}
                >
                  <Globe size={11} className="text-blue-400 shrink-0" />
                  <span className="truncate font-medium">{src.title || hostname}</span>
                  <ExternalLink size={10} className="text-blue-400/80 shrink-0" />
                </a>
              );
            })}
          </div>
        </div>
      )}

      {/* Wordless status hairline & wave for in-flight responses (Spec Section 2) */}
      {message.inFlight && (
        <div className="mt-3 space-y-1.5">
          <div className="overflow-hidden rounded-full">
            <div className="hairline-active" role="progressbar" aria-label="Processing response" />
          </div>
          <div className="flex items-center justify-between text-[10px] font-mono text-zinc-500 px-0.5">
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-blue-500 typing-dot-1" />
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 typing-dot-2" />
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 typing-dot-3" />
              <span className="tracking-wider text-zinc-400 ml-1">PROCESSING STREAM</span>
            </div>
            <span className="text-zinc-600">ZERO HEDGE PASS</span>
          </div>
        </div>
      )}

      {/* Receipts Drawer (Discreet opt-in curiosity glyph, showing codenames only) */}
      {showReceipts && message.receipts && message.receipts.length > 0 && (
        <div className="mt-3 p-2.5 rounded bg-[#08090c] border border-zinc-800/80 text-[11px] font-mono text-zinc-400 space-y-1.5">
          <div className="text-[10px] uppercase tracking-wider text-zinc-500 font-bold border-b border-zinc-800 pb-1">
            VERIFICATION RECEIPT · WINNING UNIT: {message.receipts[message.receipts.length - 1]?.providerCodename}
          </div>
          <div className="space-y-1">
            {message.receipts.map((r: MessageReceipt, idx: number) => (
              <div key={idx} className="flex items-center justify-between text-[10px] py-0.5">
                <span className="text-zinc-300 font-semibold">{r.providerCodename}</span>
                <span className="text-zinc-500">{r.latencyMs}ms</span>
                <span className={r.cached ? 'text-cyan-400' : r.hedged ? 'text-amber-500' : 'text-emerald-400'}>
                  {r.cached ? 'CACHED' : r.hedged ? 'ADJUSTED' : 'CLEAN'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Continue button for stopped responses (Section 18.5) */}
      {!isUser && message.stopped && onContinue && (
        <div className="mt-2.5 flex items-center gap-2">
          <button
            onClick={onContinue}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/40 text-blue-300 text-xs font-mono transition-all"
          >
            <Play size={11} className="text-blue-400 fill-current" />
            <span>Continue generating</span>
          </button>
        </div>
      )}

      {/* PATCH 01 (P3.6): Specific error sentence & one-click Retry for failed turns */}
      {!isUser && !message.inFlight && message.errorMessage && (
        <div className="mt-2.5 p-2.5 rounded-lg bg-red-950/30 border border-red-800/60 flex items-center justify-between gap-3 text-xs font-mono text-red-200">
          <span>{message.errorMessage}</span>
          <button
            type="button"
            onClick={() =>
              onRetryTurn
                ? onRetryTurn(message.id, message.retryPrompt)
                : onRegenerate(message.id)
            }
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-red-600/30 hover:bg-red-600/50 border border-red-500/60 text-white font-bold shrink-0 transition-all"
          >
            <RotateCw size={12} />
            <span>Retry</span>
          </button>
        </div>
      )}

      {/* Action Bar / Glyph Row */}
      {!message.inFlight && !message.hideGlyphs && (
        <div className="mt-3 pt-2 border-t border-[#181a22] flex items-center justify-between text-zinc-500 opacity-60 group-hover:opacity-100 transition-opacity text-xs select-none">
          <div className="flex items-center gap-1.5">
            {/* Copy Button */}
            <button
              onClick={handleCopy}
              className="p-1 hover:text-zinc-200 rounded hover:bg-zinc-800/60"
              title="Copy"
              aria-label="Copy message text"
            >
              {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
            </button>

            {/* Speak TTS Button */}
            <button
              onClick={() => onSpeak(displayedContent)}
              className="p-1 hover:text-zinc-200 rounded hover:bg-zinc-800/60"
              title="Read aloud"
              aria-label="Listen to message"
            >
              <Volume2 size={13} />
            </button>

            {/* Branch from here */}
            <button
              onClick={() => onBranch(message.id)}
              className="p-1 hover:text-zinc-200 rounded hover:bg-zinc-800/60"
              title="Branch conversation from this point"
              aria-label="Branch timeline from message"
            >
              <GitBranch size={13} />
            </button>

            {!isUser && (
              <>
                {/* Regenerate */}
                <button
                  onClick={() => onRegenerate(message.id)}
                  className="p-1 hover:text-zinc-200 rounded hover:bg-zinc-800/60"
                  title="Regenerate"
                  aria-label="Regenerate answer"
                >
                  <RotateCw size={13} />
                </button>

                {/* "That was a hedge" affordance (Spec Section 4 Tier 3) */}
                <button
                  onClick={() => onHedgeReport(message.id, message.winningRung)}
                  className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[11px] font-mono text-zinc-400 hover:text-amber-400 hover:bg-amber-950/30 border border-transparent hover:border-amber-900/50 transition-colors"
                  title="Trigger automated repair ladder climb"
                  aria-label="Report hedge and repair"
                >
                  <ShieldAlert size={12} />
                  <span className="hidden sm:inline">HEDGE</span>
                </button>

                {/* Stripper Reversible Undo Toggle (Spec Section 6) */}
                {message.rawContent && message.rawContent !== message.content && (
                  <button
                    onClick={() => setShowRaw(!showRaw)}
                    className="flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono text-zinc-400 hover:text-blue-300 hover:bg-blue-950/30"
                    title="Toggle raw / stripped version"
                  >
                    <Sliders size={11} />
                    <span>{showRaw ? 'STRIPPED' : 'RAW'}</span>
                  </button>
                )}

                {/* Receipts glyph toggle (Spec Section 2) */}
                {message.receipts && message.receipts.length > 0 && (
                  <button
                    onClick={() => setShowReceipts(!showReceipts)}
                    className="p-1 hover:text-zinc-200 rounded hover:bg-zinc-800/60 font-mono text-[10px]"
                    title="Verification receipts"
                    aria-label="Toggle receipts"
                  >
                    {showReceipts ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
                  </button>
                )}
              </>
            )}
          </div>

          <div>
            <button
              onClick={() => onDelete(message.id)}
              className="p-1 hover:text-red-400 rounded hover:bg-zinc-800/60"
              title="Delete message"
              aria-label="Delete message"
            >
              <Trash2 size={13} />
            </button>
          </div>
        </div>
      )}

      {/* Randomly Generated Follow-Up Options with Shuffle Button */}
      {!isUser && !message.inFlight && isLatest && !dismissedChips && activeChips.length > 0 && (
        <div
          data-testid="followup-chips-row"
          className="mt-3.5 pt-2.5 border-t border-zinc-800/60 flex flex-wrap items-center gap-2 select-none"
        >
          <span className="text-[10px] font-mono text-zinc-400 uppercase tracking-wider flex items-center gap-1">
            <Sparkles size={11} className="text-blue-400" />
            <span>Follow-ups:</span>
          </span>
          {activeChips.map((chip, idx) => (
            <button
              key={`${chip}-${idx}`}
              type="button"
              onClick={() => onSelectChip?.(chip)}
              className="px-2.5 py-1 rounded-lg bg-[#141722] hover:bg-[#1e2336] border border-zinc-700/70 hover:border-blue-500/60 text-zinc-200 hover:text-white text-xs font-mono transition-all text-left shadow-2xs"
            >
              {chip}
            </button>
          ))}
          <div className="flex items-center gap-1.5 ml-auto">
            <button
              type="button"
              onClick={() =>
                setCustomRandomChips(sampleRandomFollowUps(activeChips, displayedContent || ''))
              }
              className="flex items-center gap-1 px-2 py-1 rounded-md bg-zinc-800/70 hover:bg-zinc-700/80 text-[10px] font-mono text-zinc-300 hover:text-white transition-colors"
              title="Randomize follow-up options"
              aria-label="Shuffle follow-up options"
            >
              <Shuffle size={11} className="text-blue-400" />
              <span>Shuffle</span>
            </button>
            <button
              type="button"
              onClick={() => setDismissedChips(true)}
              className="text-xs text-zinc-500 hover:text-zinc-300 px-1"
              title="Dismiss suggestions"
              aria-label="Dismiss follow-up options"
            >
              ×
            </button>
          </div>
        </div>
      )}
    </article>
  );
};

export const MessageItem = React.memo(
  MessageItemComponent,
  (prev, next) =>
    prev.message === next.message &&
    prev.isLatest === next.isLatest
);

// -----------------------------------------------------------------------------
// Structured Markdown & Code Blocks Formatter
// -----------------------------------------------------------------------------
function renderInlineMarkdown(line: string): React.ReactNode[] {
  if (!line) return [line];
  // Tokenize inline code `...`, links [text](url), bold **...**, italic *...*
  const tokenRegex = /(`[^`]+`|\[[^\]]+\]\([^)]+\)|\*\*[^*]+\*\*|\*[^*\n]+\*)/g;
  const parts = line.split(tokenRegex);

  return parts.map((part, i) => {
    if (part.startsWith('`') && part.endsWith('`') && part.length > 2) {
      return (
        <code
          key={i}
          className="px-1.5 py-0.5 mx-0.5 rounded bg-zinc-800/90 border border-zinc-700/70 text-blue-300 font-mono text-[12px]"
        >
          {part.slice(1, -1)}
        </code>
      );
    }
    if (part.startsWith('[') && part.includes('](') && part.endsWith(')')) {
      const closeBracket = part.indexOf('](');
      const label = part.slice(1, closeBracket);
      const url = part.slice(closeBracket + 2, -1);
      return (
        <a
          key={i}
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-400 hover:text-blue-300 underline underline-offset-2 inline-flex items-center gap-0.5"
        >
          <span>{label}</span>
          <ExternalLink size={10} className="inline" />
        </a>
      );
    }
    if (part.startsWith('**') && part.endsWith('**') && part.length > 4) {
      return (
        <strong key={i} className="font-semibold text-white">
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith('*') && part.endsWith('*') && part.length > 2) {
      return (
        <em key={i} className="italic text-zinc-100">
          {part.slice(1, -1)}
        </em>
      );
    }
    return <React.Fragment key={i}>{part}</React.Fragment>;
  });
}

function renderStructuredTextSegment(text: string, segIndex: number) {
  const lines = text.split('\n');
  const blocks: React.ReactNode[] = [];
  let i = 0;

  while (i < lines.length) {
    const rawLine = lines[i];
    const trimmed = rawLine.trim();

    if (!trimmed) {
      i++;
      continue;
    }

    // Horizontal Rule
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(trimmed)) {
      blocks.push(<hr key={`${segIndex}-hr-${i}`} className="border-zinc-800 my-3" />);
      i++;
      continue;
    }

    // Headings (#, ##, ###, ####)
    const headingMatch = trimmed.match(/^(#{1,4})\s+(.+)$/);
    if (headingMatch) {
      const level = headingMatch[1].length;
      const headingText = headingMatch[2];
      const sizeClass =
        level === 1
          ? 'text-lg font-bold text-white mt-4 mb-1.5 border-b border-zinc-800/80 pb-1'
          : level === 2
          ? 'text-base font-bold text-zinc-100 mt-3.5 mb-1'
          : level === 3
          ? 'text-sm font-semibold text-blue-300 mt-3 mb-1'
          : 'text-xs font-semibold uppercase tracking-wider text-zinc-400 mt-2.5 mb-1';
      blocks.push(
        <div key={`${segIndex}-h-${i}`} className={sizeClass}>
          {renderInlineMarkdown(headingText)}
        </div>
      );
      i++;
      continue;
    }

    // Markdown Table (| col | col |)
    if (trimmed.startsWith('|') && trimmed.endsWith('|') && i + 1 < lines.length && /^\s*\|[\s\-:|]+\|\s*$/.test(lines[i + 1])) {
      const headerCells = trimmed
        .slice(1, -1)
        .split('|')
        .map((c) => c.trim());
      i += 2; // Skip header and separator row
      const bodyRows: string[][] = [];
      while (i < lines.length && lines[i].trim().startsWith('|') && lines[i].trim().endsWith('|')) {
        const rowCells = lines[i]
          .trim()
          .slice(1, -1)
          .split('|')
          .map((c) => c.trim());
        bodyRows.push(rowCells);
        i++;
      }
      blocks.push(
        <div key={`${segIndex}-tbl-${i}`} className="my-3 overflow-x-auto rounded-lg border border-zinc-800">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-[#121520] text-zinc-300 font-mono border-b border-zinc-800">
              <tr>
                {headerCells.map((cell, cIdx) => (
                  <th key={cIdx} className="py-2 px-3 font-semibold">
                    {renderInlineMarkdown(cell)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/70 bg-[#0a0c12]">
              {bodyRows.map((row, rIdx) => (
                <tr key={rIdx} className="hover:bg-zinc-900/50">
                  {row.map((cell, cIdx) => (
                    <td key={cIdx} className="py-2 px-3 text-zinc-300">
                      {renderInlineMarkdown(cell)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
      continue;
    }

    // Blockquote (> ...)
    if (trimmed.startsWith('>')) {
      const quoteLines: string[] = [];
      while (i < lines.length && lines[i].trim().startsWith('>')) {
        quoteLines.push(lines[i].trim().replace(/^>\s?/, ''));
        i++;
      }
      blocks.push(
        <blockquote
          key={`${segIndex}-q-${i}`}
          className="my-2.5 pl-3.5 py-1 border-l-2 border-blue-500/70 bg-blue-950/15 rounded-r text-zinc-300 italic space-y-1"
        >
          {quoteLines.map((ql, qi) => (
            <div key={qi}>{renderInlineMarkdown(ql)}</div>
          ))}
        </blockquote>
      );
      continue;
    }

    // Unordered List (- , * , • )
    if (/^[-*•]\s+/.test(trimmed)) {
      const items: string[] = [];
      while (i < lines.length && /^[-*•]\s+/.test(lines[i].trim())) {
        items.push(lines[i].trim().replace(/^[-*•]\s+/, ''));
        i++;
      }
      blocks.push(
        <ul key={`${segIndex}-ul-${i}`} className="my-2 pl-5 list-disc space-y-1 text-zinc-200 marker:text-blue-400">
          {items.map((it, idx) => (
            <li key={idx} className="leading-relaxed">
              {renderInlineMarkdown(it)}
            </li>
          ))}
        </ul>
      );
      continue;
    }

    // Ordered List (1. , 2. )
    if (/^\d+[.)]\s+/.test(trimmed)) {
      const items: string[] = [];
      while (i < lines.length && /^\d+[.)]\s+/.test(lines[i].trim())) {
        items.push(lines[i].trim().replace(/^\d+[.)]\s+/, ''));
        i++;
      }
      blocks.push(
        <ol key={`${segIndex}-ol-${i}`} className="my-2 pl-5 list-decimal space-y-1 text-zinc-200 marker:text-blue-400 marker:font-mono">
          {items.map((it, idx) => (
            <li key={idx} className="leading-relaxed">
              {renderInlineMarkdown(it)}
            </li>
          ))}
        </ol>
      );
      continue;
    }

    // Standard Paragraph
    blocks.push(
      <p key={`${segIndex}-p-${i}`} className="leading-relaxed text-zinc-200">
        {renderInlineMarkdown(rawLine)}
      </p>
    );
    i++;
  }

  return (
    <div key={segIndex} className="space-y-2">
      {blocks}
    </div>
  );
}

function renderFormattedContent(
  text: string,
  onCreateArtifact?: (title: string, type: any, code: string) => void
) {
  if (!text) return null;

  const segments: { type: 'code' | 'text'; lang?: string; code?: string; text?: string }[] = [];
  let remaining = text;

  while (remaining.length > 0) {
    const fenceStart = remaining.indexOf('```');
    if (fenceStart === -1) {
      segments.push({ type: 'text', text: remaining });
      break;
    }

    if (fenceStart > 0) {
      segments.push({ type: 'text', text: remaining.slice(0, fenceStart) });
      remaining = remaining.slice(fenceStart);
    }

    const newlineAfterFence = remaining.indexOf('\n');
    if (newlineAfterFence === -1) {
      break;
    }

    const lang = remaining.slice(3, newlineAfterFence).trim();
    const restAfterFenceHeader = remaining.slice(newlineAfterFence + 1);

    const fenceEnd = restAfterFenceHeader.indexOf('```');
    if (fenceEnd === -1) {
      segments.push({ type: 'code', lang, code: restAfterFenceHeader });
      break;
    } else {
      const codeContent = restAfterFenceHeader.slice(0, fenceEnd);
      segments.push({ type: 'code', lang, code: codeContent });
      remaining = restAfterFenceHeader.slice(fenceEnd + 3);
    }
  }

  return segments.map((seg, index) => {
    if (seg.type === 'code' && seg.code !== undefined) {
      const code = seg.code.trimEnd();
      const lang = seg.lang || 'code';
      const lineCount = code.split('\n').length;
      const isUserscript = code.includes('==UserScript==') || lang.toLowerCase().includes('user');

      return (
        <div key={index} className="my-3 rounded-xl overflow-hidden border border-zinc-800 bg-[#07080b] shadow-md">
          {/* Code Header Bar */}
          <div className="bg-[#10121a] px-3 py-1.5 border-b border-zinc-800/80 flex items-center justify-between text-xs font-mono text-zinc-400 select-none">
            <div className="flex items-center gap-2">
              <span className="text-blue-400 font-semibold uppercase">{lang || 'CODE'}</span>
              <span className="text-[10px] text-zinc-600">{lineCount} lines</span>
            </div>
            <div className="flex items-center gap-2">
              {isUserscript && (
                <button
                  onClick={() => navigator.clipboard.writeText(code)}
                  className="flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-700/60 text-emerald-300 hover:bg-emerald-900 text-[11px] font-bold"
                  title="Copy ready for Tampermonkey / Violentmonkey"
                >
                  <Copy size={11} />
                  <span>Copy for Tampermonkey</span>
                </button>
              )}

              {onCreateArtifact && (
                <button
                  onClick={() => {
                    const artType = isUserscript ? 'userscript' : lang === 'html' ? 'html' : lang === 'svg' ? 'svg' : 'code';
                    onCreateArtifact(`${lang || 'code'}-snippet`, artType, code);
                  }}
                  className="flex items-center gap-1 px-2 py-0.5 rounded bg-blue-950/40 border border-blue-800/40 text-blue-300 hover:bg-blue-900/60 text-[11px]"
                  title="Open into Workspace Artifact"
                >
                  <ExternalLink size={11} />
                  <span>Into Workspace</span>
                </button>
              )}

              <button
                onClick={() => navigator.clipboard.writeText(code)}
                className="p-1 hover:text-zinc-200 rounded"
                title="Copy code"
              >
                <Copy size={12} />
              </button>
            </div>
          </div>

          {/* Code Body */}
          <pre className="p-3.5 text-xs font-mono text-zinc-200 overflow-x-auto leading-relaxed">
            <code>{code}</code>
          </pre>
        </div>
      );
    }

    return renderStructuredTextSegment(seg.text || '', index);
  });
}

