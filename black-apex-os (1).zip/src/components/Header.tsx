import React from 'react';
import { PanelLeft, PanelRight, Settings as SettingsIcon, Plus, GitBranch, Keyboard } from 'lucide-react';

interface HeaderProps {
  conversationTitle: string;
  isSidebarOpen: boolean;
  isArtifactsOpen: boolean;
  isBranch?: boolean;
  onToggleSidebar: () => void;
  onToggleArtifacts: () => void;
  onOpenSettings: () => void;
  onNewConversation: () => void;
  onOpenShortcuts?: () => void;
  activeArtifactCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  conversationTitle,
  isSidebarOpen,
  isArtifactsOpen,
  isBranch,
  onToggleSidebar,
  onToggleArtifacts,
  onOpenSettings,
  onNewConversation,
  onOpenShortcuts,
  activeArtifactCount = 0,
}) => {
  return (
    <header className="h-12 border-b border-[#1f232d] bg-[#0c0d12]/95 backdrop-blur px-3 flex items-center justify-between text-xs select-none z-20">
      <div className="flex items-center gap-2">
        <button
          onClick={onToggleSidebar}
          aria-label="Toggle navigation drawer"
          className="p-1.5 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60 rounded transition-colors"
          title="Toggle Sidebar (Ctrl+B / ⌘B)"
        >
          <PanelLeft size={16} />
        </button>

        <button
          onClick={onNewConversation}
          aria-label="Create new conversation"
          className="flex items-center gap-1.5 px-2 py-1 text-zinc-300 hover:text-white bg-zinc-800/40 hover:bg-zinc-800 border border-zinc-700/40 rounded transition-colors"
          title="New Conversation (Ctrl+Shift+O)"
        >
          <Plus size={13} />
          <span className="font-mono text-[11px]">NEW</span>
        </button>

        <div className="h-4 w-[1px] bg-zinc-800 mx-1" />

        <div className="flex items-center gap-1.5 text-zinc-300 font-mono tracking-wider font-semibold">
          <span className="text-zinc-500">APEX</span>
          <span className="text-zinc-600">//</span>
          <span className="text-zinc-200">OS</span>
        </div>

        {isBranch && (
          <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-950/40 border border-amber-800/40 text-amber-300 text-[10px] font-mono">
            <GitBranch size={10} />
            BRANCH
          </span>
        )}
      </div>

      <div className="flex items-center gap-1.5 max-w-[40%] truncate">
        <span className="text-zinc-400 truncate font-mono text-[11px]">
          {conversationTitle || 'Untitled Session'}
        </span>
      </div>

      <div className="flex items-center gap-1.5 sm:gap-2">
        <button
          onClick={onToggleArtifacts}
          aria-label="Toggle artifacts and code preview pane"
          className={`flex items-center gap-1.5 px-2 py-1 rounded transition-colors text-xs font-mono ${
            isArtifactsOpen
              ? 'bg-blue-950/60 text-blue-300 border border-blue-800/50'
              : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
          }`}
          title="Toggle Artifacts Workspace (Ctrl+Shift+W)"
        >
          <PanelRight size={15} />
          <span className="hidden sm:inline">WORKSPACE</span>
          {activeArtifactCount > 0 && (
            <span className="px-1 py-0.2 bg-blue-500/20 text-blue-300 text-[10px] rounded">
              {activeArtifactCount}
            </span>
          )}
        </button>

        {onOpenShortcuts && (
          <button
            onClick={onOpenShortcuts}
            aria-label="Open keyboard shortcuts cheat sheet"
            className="p-1.5 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60 rounded transition-colors"
            title="Keyboard Shortcuts (Ctrl+/ or ?)"
          >
            <Keyboard size={16} />
          </button>
        )}

        <button
          onClick={onOpenSettings}
          aria-label="Open system settings"
          className="p-1.5 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60 rounded transition-colors"
          title="System Settings (Ctrl+Shift+S)"
        >
          <SettingsIcon size={16} />
        </button>
      </div>
    </header>
  );
};
