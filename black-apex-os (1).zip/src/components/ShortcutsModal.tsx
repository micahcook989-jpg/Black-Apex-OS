import React, { useState } from 'react';
import { X, Keyboard, Search, Command } from 'lucide-react';

interface ShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface ShortcutItem {
  id: string;
  category: 'Navigation & Cockpit' | 'Input & Directives' | 'Engine & Processing';
  description: string;
  keys: string[];
}

const SHORTCUTS: ShortcutItem[] = [
  {
    id: 'focus-input',
    category: 'Navigation & Cockpit',
    description: 'Focus prompt input terminal (selects all if already focused)',
    keys: ['Ctrl', 'K'],
  },
  {
    id: 'toggle-settings',
    category: 'Navigation & Cockpit',
    description: 'Open or close System Settings control drawer',
    keys: ['Ctrl', 'Shift', 'S'],
  },
  {
    id: 'toggle-workspace',
    category: 'Navigation & Cockpit',
    description: 'Toggle Workspace Artifacts and code preview drawer',
    keys: ['Ctrl', 'Shift', 'W'],
  },
  {
    id: 'toggle-sidebar',
    category: 'Navigation & Cockpit',
    description: 'Toggle timeline navigation sidebar',
    keys: ['Ctrl', 'B'],
  },
  {
    id: 'new-session',
    category: 'Navigation & Cockpit',
    description: 'Create and switch to a fresh conversation session',
    keys: ['Ctrl', 'Shift', 'O'],
  },
  {
    id: 'close-modal',
    category: 'Navigation & Cockpit',
    description: 'Close active modal, dismiss popups, or cancel palette',
    keys: ['Esc'],
  },
  {
    id: 'send-prompt',
    category: 'Input & Directives',
    description: 'Send prompt to the model mesh',
    keys: ['Enter'],
  },
  {
    id: 'send-prompt-combo',
    category: 'Input & Directives',
    description: 'Alternative send command for multi-line drafts',
    keys: ['Ctrl', 'Enter'],
  },
  {
    id: 'newline',
    category: 'Input & Directives',
    description: 'Insert newline without sending message',
    keys: ['Shift', 'Enter'],
  },
  {
    id: 'slash-palette',
    category: 'Input & Directives',
    description: 'Open slash directives palette (/userscript, /exploit, /code, /search)',
    keys: ['/'],
  },
  {
    id: 'edit-last',
    category: 'Input & Directives',
    description: 'Recall and edit previous user message (when prompt input is empty)',
    keys: ['↑'],
  },
  {
    id: 'paste-attachment',
    category: 'Input & Directives',
    description: 'Paste screenshot or document from clipboard as attachment',
    keys: ['Ctrl', 'V'],
  },
  {
    id: 'toggle-stripper',
    category: 'Engine & Processing',
    description: 'Quickly toggle Deterministic Stripper on or off',
    keys: ['Ctrl', 'Shift', 'D'],
  },
  {
    id: 'shortcuts-guide',
    category: 'Navigation & Cockpit',
    description: 'Open this keyboard shortcuts cheat sheet',
    keys: ['Ctrl', '/'],
  },
];

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({ isOpen, onClose }) => {
  const [search, setSearch] = useState('');

  if (!isOpen) return null;

  const isMac = typeof navigator !== 'undefined' && /Mac|iPod|iPhone|iPad/.test(navigator.platform);

  const formatKey = (key: string) => {
    if (key === 'Ctrl') return isMac ? '⌘' : 'Ctrl';
    if (key === 'Shift') return isMac ? '⇧' : 'Shift';
    if (key === 'Enter') return '↵ Enter';
    return key;
  };

  const filtered = SHORTCUTS.filter(
    (s) =>
      s.description.toLowerCase().includes(search.toLowerCase()) ||
      s.keys.some((k) => k.toLowerCase().includes(search.toLowerCase())) ||
      s.category.toLowerCase().includes(search.toLowerCase())
  );

  const categories = Array.from(new Set(filtered.map((s) => s.category)));

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-100"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl bg-[#0d0f17] border border-zinc-700/80 rounded-xl shadow-2xl flex flex-col max-h-[85vh] overflow-hidden text-xs font-mono"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-3 border-b border-zinc-800 flex items-center justify-between text-zinc-300 bg-[#12141c]">
          <div className="flex items-center gap-2">
            <Keyboard size={15} className="text-blue-400" />
            <span className="font-semibold tracking-wider text-sm text-zinc-100">
              KEYBOARD SHORTCUTS · COCKPIT COMMANDS
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:text-white rounded hover:bg-zinc-800 text-zinc-400"
            aria-label="Close shortcuts"
          >
            <X size={16} />
          </button>
        </div>

        {/* Search Filter */}
        <div className="p-3 border-b border-zinc-800/80 bg-[#090b10]">
          <div className="relative flex items-center">
            <Search size={13} className="absolute left-2.5 text-zinc-500 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search shortcuts (e.g. settings, focus, enter, /)..."
              autoFocus
              className="w-full bg-[#12141d] border border-zinc-800 focus:border-blue-500 text-zinc-200 pl-8 pr-3 py-1.5 rounded-lg outline-none text-xs placeholder-zinc-500"
            />
          </div>
        </div>

        {/* Shortcuts List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {categories.length === 0 ? (
            <div className="text-center py-8 text-zinc-500">No matching shortcuts found</div>
          ) : (
            categories.map((cat) => (
              <div key={cat} className="space-y-1.5">
                <div className="text-[10px] uppercase font-bold text-blue-400 tracking-wider">
                  {cat}
                </div>
                <div className="divide-y divide-zinc-800/60 rounded-lg border border-zinc-800/80 bg-[#11131d] overflow-hidden">
                  {filtered
                    .filter((s) => s.category === cat)
                    .map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-2.5 hover:bg-zinc-800/40 transition-colors"
                      >
                        <span className="text-zinc-300 text-[11px] font-sans pr-4">
                          {item.description}
                        </span>
                        <div className="flex items-center gap-1 shrink-0 font-mono">
                          {item.keys.map((k, idx) => (
                            <React.Fragment key={idx}>
                              <kbd className="px-2 py-0.5 rounded bg-zinc-800/90 border border-zinc-700/80 text-zinc-200 text-[10px] font-bold shadow-sm inline-block">
                                {formatKey(k)}
                              </kbd>
                              {idx < item.keys.length - 1 && (
                                <span className="text-zinc-600 text-[10px]">+</span>
                              )}
                            </React.Fragment>
                          ))}
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Hint */}
        <div className="p-2.5 border-t border-zinc-800 bg-[#10121a] flex items-center justify-between text-[10px] text-zinc-500">
          <span>Press Esc anytime to close</span>
          <span className="text-zinc-400 font-mono">Ctrl+/ to reopen</span>
        </div>
      </div>
    </div>
  );
};
