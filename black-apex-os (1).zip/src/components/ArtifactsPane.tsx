import React, { useState } from 'react';
import {
  X,
  Play,
  Code2,
  Copy,
  Download,
  History,
  FileCode,
  Check,
  Terminal,
  ExternalLink,
} from 'lucide-react';
import { Artifact } from '../types';

interface ArtifactsPaneProps {
  artifacts: Artifact[];
  activeArtifact: Artifact | null;
  onSelectArtifact: (artifact: Artifact) => void;
  onUpdateArtifact: (artifact: Artifact) => void;
  onClose: () => void;
}

export const ArtifactsPane: React.FC<ArtifactsPaneProps> = ({
  artifacts,
  activeArtifact,
  onSelectArtifact,
  onUpdateArtifact,
  onClose,
}) => {
  const [viewMode, setViewMode] = useState<'preview' | 'code'>('preview');
  const [copied, setCopied] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [testHtmlSnapshot, setTestHtmlSnapshot] = useState('');
  const [showSnapshotTester, setShowSnapshotTester] = useState(false);

  if (!activeArtifact && artifacts.length === 0) {
    return (
      <aside className="w-full sm:w-96 fixed sm:relative top-12 sm:top-0 right-0 h-[calc(100vh-3rem)] border-l border-[#1f232d] bg-[#0c0d12] flex flex-col z-30 shadow-2xl sm:shadow-none shrink-0 text-xs font-mono">
        <div className="p-3 border-b border-zinc-800 flex items-center justify-between text-zinc-400">
          <span className="font-semibold text-zinc-200">WORKSPACE ARTIFACTS</span>
          <button onClick={onClose} className="p-1 hover:text-white rounded">
            <X size={15} />
          </button>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-zinc-500">
          <FileCode size={32} className="mb-2 text-zinc-700" />
          <p>No active artifacts in this session.</p>
          <p className="text-[11px] text-zinc-600 mt-1">
            Generate userscripts, code files, HTML apps, or diagrams to populate.
          </p>
        </div>
      </aside>
    );
  }

  const current = activeArtifact || artifacts[0];
  const isUserscript = current.type === 'userscript' || current.content.includes('==UserScript==');

  const handleCopyTampermonkey = () => {
    navigator.clipboard.writeText(current.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([current.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const ext = current.type === 'html' ? 'html' : isUserscript ? 'user.js' : current.type === 'svg' ? 'svg' : 'txt';
    a.download = `${current.title.replace(/\s+/g, '_')}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Build sandboxed iframe srcdoc
  const buildIframeContent = () => {
    if (current.type === 'svg') {
      return `<!DOCTYPE html><html><body style="margin:0;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#090a0d;">${current.content}</body></html>`;
    }
    if (isUserscript && testHtmlSnapshot) {
      return `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body style="color:#eee;background:#111;">
        <div id="target-root">${testHtmlSnapshot}</div>
        <script>
          try {
            ${current.content}
            console.log("Userscript dry-run executed in sandbox");
          } catch(err) {
            console.error("Dry run error:", err);
          }
        </script>
      </body></html>`;
    }
    return current.content;
  };

  return (
    <aside className="w-full sm:w-[420px] lg:w-[480px] fixed sm:relative top-12 sm:top-0 right-0 h-[calc(100vh-3rem)] border-l border-[#1f232d] bg-[#0c0d12] flex flex-col z-30 shadow-2xl sm:shadow-none shrink-0 text-xs font-mono">
      {/* Workspace Header */}
      <div className="p-2.5 border-b border-zinc-800 flex items-center justify-between text-zinc-400 bg-[#10121a]">
        <div className="flex items-center gap-1.5 truncate flex-1 min-w-0 pr-2">
          <FileCode size={14} className="text-blue-400 shrink-0" />
          <span className="font-semibold text-zinc-200 truncate">{current.title}</span>
          <span className="px-1.5 py-0.2 bg-zinc-800 text-zinc-400 text-[10px] rounded">
            v{current.version}
          </span>
        </div>

        <div className="flex items-center gap-1">
          {/* Preview / Code Toggle */}
          <div className="flex bg-zinc-800/80 rounded p-0.5 border border-zinc-700/60 mr-1">
            <button
              onClick={() => setViewMode('preview')}
              className={`px-2 py-0.5 rounded text-[10px] ${
                viewMode === 'preview' ? 'bg-zinc-700 text-white font-bold' : 'text-zinc-400'
              }`}
            >
              PREVIEW
            </button>
            <button
              onClick={() => setViewMode('code')}
              className={`px-2 py-0.5 rounded text-[10px] ${
                viewMode === 'code' ? 'bg-zinc-700 text-white font-bold' : 'text-zinc-400'
              }`}
            >
              CODE
            </button>
          </div>

          <button onClick={onClose} className="p-1 hover:text-white rounded" title="Close Workspace">
            <X size={15} />
          </button>
        </div>
      </div>

      {/* Artifact Subtoolbar */}
      <div className="px-3 py-1.5 border-b border-zinc-800/60 flex items-center justify-between text-[11px] bg-[#090a0d]">
        <div className="flex items-center gap-2">
          {isUserscript && (
            <button
              onClick={handleCopyTampermonkey}
              className="flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-950 border border-emerald-700 text-emerald-300 hover:bg-emerald-900 font-bold"
              title="Copy userscript directly ready for Tampermonkey"
            >
              {copied ? <Check size={11} /> : <Terminal size={11} />}
              <span>{copied ? 'COPIED!' : 'Copy for Tampermonkey'}</span>
            </button>
          )}

          {isUserscript && (
            <button
              onClick={() => setShowSnapshotTester(!showSnapshotTester)}
              className="px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 hover:text-white"
              title="Test script against pasted HTML snapshot"
            >
              Dry-run Snapshot
            </button>
          )}
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={handleDownload}
            className="p-1 text-zinc-400 hover:text-zinc-200"
            title="Download file"
          >
            <Download size={13} />
          </button>
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="p-1 text-zinc-400 hover:text-zinc-200"
            title="Version history"
          >
            <History size={13} />
          </button>
        </div>
      </div>

      {/* Snapshot Tester for Userscripts */}
      {showSnapshotTester && (
        <div className="p-2 border-b border-zinc-800 bg-[#12141c] text-[11px] space-y-1">
          <div className="text-zinc-400">Paste HTML snippet to dry-run userscript against:</div>
          <textarea
            value={testHtmlSnapshot}
            onChange={(e) => setTestHtmlSnapshot(e.target.value)}
            placeholder="<div class='paywall-overlay'>...</div>"
            rows={3}
            className="w-full bg-[#08090d] border border-zinc-700 text-zinc-300 p-1.5 rounded outline-none font-mono text-[10px]"
          />
        </div>
      )}

      {/* Version History Drawer */}
      {showHistory && current.history && current.history.length > 0 && (
        <div className="p-2 border-b border-zinc-800 bg-[#10121a] max-h-36 overflow-y-auto space-y-1">
          <div className="text-[10px] text-zinc-500 font-bold uppercase">REVISION LOG</div>
          {current.history.map((h, idx) => (
            <div
              key={idx}
              onClick={() => {
                onUpdateArtifact({ ...current, content: h.content });
                setShowHistory(false);
              }}
              className="flex items-center justify-between p-1 rounded hover:bg-zinc-800 cursor-pointer text-zinc-400 hover:text-zinc-200 text-[10px]"
            >
              <span>Version {h.version}</span>
              <span>{new Date(h.timestamp).toLocaleTimeString()}</span>
            </div>
          ))}
        </div>
      )}

      {/* Main View Area */}
      <div className="flex-1 overflow-hidden relative bg-[#060709]">
        {viewMode === 'preview' ? (
          <iframe
            srcDoc={buildIframeContent()}
            sandbox="allow-scripts allow-forms"
            title="Artifact Preview"
            className="w-full h-full border-none bg-white"
          />
        ) : (
          <textarea
            value={current.content}
            onChange={(e) => onUpdateArtifact({ ...current, content: e.target.value })}
            className="w-full h-full bg-[#08090c] text-zinc-200 font-mono text-xs p-3 outline-none resize-none leading-relaxed"
          />
        )}
      </div>

      {/* Artifacts Switcher Strip */}
      {artifacts.length > 1 && (
        <div className="p-2 border-t border-zinc-800 bg-[#0c0d12] flex gap-1.5 overflow-x-auto">
          {artifacts.map((art) => (
            <button
              key={art.id}
              onClick={() => onSelectArtifact(art)}
              className={`px-2 py-1 rounded truncate max-w-[140px] text-[10px] transition-colors ${
                art.id === current.id
                  ? 'bg-zinc-800 text-white border border-zinc-700'
                  : 'text-zinc-500 hover:text-zinc-300 hover:bg-zinc-900'
              }`}
            >
              {art.title}
            </button>
          ))}
        </div>
      )}
    </aside>
  );
};
