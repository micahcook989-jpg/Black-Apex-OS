import React, { useState, useEffect } from 'react';
import {
  Search,
  Pin,
  Trash2,
  Download,
  Edit2,
  Check,
  X,
  MessageSquare,
  GitBranch,
} from 'lucide-react';
import { Conversation, Message } from '../types';

interface SidebarProps {
  conversations: Conversation[];
  activeId: string;
  onSelectConversation: (id: string) => void;
  onDeleteConversation: (id: string) => void;
  onRenameConversation: (id: string, newTitle: string) => void;
  onPinConversation: (id: string, pinned: boolean) => void;
  onExportConversation: (id: string, format: 'md' | 'txt' | 'json') => void;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  conversations,
  activeId,
  onSelectConversation,
  onDeleteConversation,
  onRenameConversation,
  onPinConversation,
  onExportConversation,
  onCloseMobile,
}) => {
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [exportMenuId, setExportMenuId] = useState<string | null>(null);
  const [tightestTier, setTightestTier] = useState<{ provider: string; remainingPercent: number }>({
    provider: 'LOCAL',
    remainingPercent: 100,
  });

  useEffect(() => {
    let mounted = true;
    const fetchQuota = () => {
      fetch('/api/free/dashboard')
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => {
          if (mounted && d?.tightestTier) {
            setTightestTier(d.tightestTier);
          }
        })
        .catch(() => {});
    };
    fetchQuota();
    const interval = setInterval(fetchQuota, 30000);
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  const filtered = conversations.filter((c) =>
    c.title.toLowerCase().includes(search.toLowerCase())
  );

  const pinnedConvs = filtered.filter((c) => c.pinned);
  const regularConvs = filtered.filter((c) => !c.pinned);

  const startRename = (conv: Conversation) => {
    setEditingId(conv.id);
    setEditTitle(conv.title);
  };

  const saveRename = (id: string) => {
    if (editTitle.trim()) {
      onRenameConversation(id, editTitle.trim());
    }
    setEditingId(null);
  };

  return (
    <aside
      className="w-72 fixed md:relative top-12 md:top-0 left-0 h-[calc(100vh-3rem)] border-r border-[#1f232d] bg-[#090a0d] flex flex-col z-30 shadow-2xl md:shadow-none shrink-0 text-xs"
      aria-label="Conversations Navigation"
    >
      {/* Section 32.14: Single line at top of sidebar showing the tightest tier as a thin meter */}
      <div
        className="px-3 py-1.5 border-b border-[#1b1e27] bg-[#0c0e14] flex items-center justify-between gap-2 font-mono text-[10px] text-zinc-400"
        title="Tightest free-tier quota headroom"
      >
        <span className="truncate shrink-0">
          TIER: <span className="text-zinc-200 font-bold">{tightestTier.provider}</span>
        </span>
        <div className="flex-1 h-1 bg-zinc-800 rounded-full overflow-hidden">
          <div
            className={`h-full transition-all ${
              tightestTier.remainingPercent < 20
                ? 'bg-amber-500'
                : 'bg-emerald-500'
            }`}
            style={{ width: `${Math.max(4, Math.min(100, tightestTier.remainingPercent))}%` }}
          />
        </div>
        <span className="text-zinc-400 shrink-0">{tightestTier.remainingPercent}%</span>
      </div>

      {/* Search Bar */}
      <div className="p-3 border-b border-[#1b1e27]">
        <div className="relative flex items-center">
          <Search size={13} className="absolute left-2.5 text-zinc-500 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search transcripts..."
            aria-label="Search conversations"
            className="w-full bg-[#12141c] border border-zinc-800 text-zinc-300 placeholder-zinc-500 rounded pl-8 pr-2.5 py-1.5 focus:outline-none focus:border-zinc-600 font-mono text-[11px]"
          />
        </div>
      </div>

      {/* Conversations List */}
      <div className="flex-1 overflow-y-auto p-2 space-y-4">
        {pinnedConvs.length > 0 && (
          <div>
            <div className="px-2 py-1 text-[10px] uppercase font-mono tracking-wider text-zinc-500 font-bold flex items-center gap-1">
              <Pin size={10} className="text-zinc-500" />
              PINNED
            </div>
            <div className="space-y-0.5 mt-1">
              {pinnedConvs.map((c) => renderItem(c))}
            </div>
          </div>
        )}

        <div>
          <div className="px-2 py-1 text-[10px] uppercase font-mono tracking-wider text-zinc-500 font-bold">
            TIMELINE ({regularConvs.length})
          </div>
          <div className="space-y-0.5 mt-1">
            {regularConvs.length === 0 ? (
              <div className="px-3 py-6 text-center text-zinc-600 font-mono text-[11px]">
                No records found
              </div>
            ) : (
              regularConvs.map((c) => renderItem(c))
            )}
          </div>
        </div>
      </div>

      {/* Export Context Menu Popover */}
      {exportMenuId && (
        <div className="p-2 border-t border-[#1b1e27] bg-[#10121a] flex items-center justify-between font-mono text-[11px]">
          <span className="text-zinc-400">Export:</span>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                onExportConversation(exportMenuId, 'md');
                setExportMenuId(null);
              }}
              className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded"
            >
              MD
            </button>
            <button
              onClick={() => {
                onExportConversation(exportMenuId, 'txt');
                setExportMenuId(null);
              }}
              className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded"
            >
              TXT
            </button>
            <button
              onClick={() => {
                onExportConversation(exportMenuId, 'json');
                setExportMenuId(null);
              }}
              className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded"
            >
              JSON
            </button>
            <button
              onClick={() => setExportMenuId(null)}
              className="p-1 text-zinc-500 hover:text-zinc-300"
            >
              <X size={12} />
            </button>
          </div>
        </div>
      )}
    </aside>
  );

  function renderItem(conv: Conversation) {
    const isActive = conv.id === activeId;
    const isEditing = editingId === conv.id;

    return (
      <div
        key={conv.id}
        className={`group relative flex items-center justify-between rounded px-2.5 py-1.5 text-xs transition-colors cursor-pointer ${
          isActive
            ? 'bg-[#181b24] text-zinc-100 font-medium border border-zinc-700/50'
            : 'text-zinc-400 hover:bg-[#12141c] hover:text-zinc-200'
        }`}
        onClick={() => {
          if (!isEditing) {
            onSelectConversation(conv.id);
            onCloseMobile();
          }
        }}
      >
        <div className="flex items-center gap-2 truncate flex-1 min-w-0 pr-1">
          {conv.branchOf ? (
            <GitBranch size={12} className="text-amber-500 shrink-0" />
          ) : (
            <MessageSquare size={12} className="text-zinc-500 shrink-0" />
          )}

          {isEditing ? (
            <input
              type="text"
              value={editTitle}
              onChange={(e) => setEditTitle(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') saveRename(conv.id);
                if (e.key === 'Escape') setEditingId(null);
              }}
              autoFocus
              className="w-full bg-[#1e2230] text-zinc-200 px-1 py-0.5 rounded outline-none border border-zinc-600 text-[11px]"
              onClick={(e) => e.stopPropagation()}
            />
          ) : (
            <span className="truncate text-[11px] font-mono">{conv.title}</span>
          )}
        </div>

        {/* Hover Action Controls */}
        <div
          className={`flex items-center gap-1 shrink-0 ${
            isActive ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
          }`}
          onClick={(e) => e.stopPropagation()}
        >
          {isEditing ? (
            <>
              <button
                onClick={() => saveRename(conv.id)}
                className="p-1 text-emerald-400 hover:text-emerald-300"
                title="Save"
              >
                <Check size={11} />
              </button>
              <button
                onClick={() => setEditingId(null)}
                className="p-1 text-zinc-500 hover:text-zinc-400"
                title="Cancel"
              >
                <X size={11} />
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => onPinConversation(conv.id, !conv.pinned)}
                className={`p-1 rounded hover:bg-zinc-700/50 ${
                  conv.pinned ? 'text-blue-400' : 'text-zinc-500 hover:text-zinc-300'
                }`}
                title={conv.pinned ? 'Unpin' : 'Pin'}
              >
                <Pin size={11} />
              </button>
              <button
                onClick={() => startRename(conv)}
                className="p-1 text-zinc-500 hover:text-zinc-300 rounded hover:bg-zinc-700/50"
                title="Rename"
              >
                <Edit2 size={11} />
              </button>
              <button
                onClick={() => setExportMenuId(conv.id)}
                className="p-1 text-zinc-500 hover:text-zinc-300 rounded hover:bg-zinc-700/50"
                title="Export transcript"
              >
                <Download size={11} />
              </button>
              <button
                onClick={() => onDeleteConversation(conv.id)}
                className="p-1 text-zinc-500 hover:text-red-400 rounded hover:bg-zinc-700/50"
                title="Delete"
              >
                <Trash2 size={11} />
              </button>
            </>
          )}
        </div>
      </div>
    );
  }
};
