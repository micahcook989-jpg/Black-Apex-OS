import { useEffect } from 'react';

interface KeyboardShortcutHandlers {
  onFocusInput?: () => void;
  onOpenPalette?: () => void;
  onFindInConversation?: () => void;
  onNewSession?: () => void;
  onRegenerateLast?: () => void;
  onCopyLastAnswer?: () => void;
  onToggleSidebar?: () => void;
  onToggleWorkspace?: () => void;
  onPrevConversation?: () => void;
  onNextConversation?: () => void;
  onToggleSettings?: () => void;
  onToggleStripper?: () => void;
  onToggleShortcuts?: () => void;
  onEscape?: () => void;
}

export function useKeyboardShortcuts({
  onFocusInput,
  onOpenPalette,
  onFindInConversation,
  onNewSession,
  onRegenerateLast,
  onCopyLastAnswer,
  onToggleSidebar,
  onToggleWorkspace,
  onPrevConversation,
  onNextConversation,
  onToggleSettings,
  onToggleStripper,
  onToggleShortcuts,
  onEscape,
}: KeyboardShortcutHandlers) {
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isModifier = e.ctrlKey || e.metaKey;
      const key = e.key.toLowerCase();
      const target = e.target as HTMLElement;
      const isTyping =
        target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable;

      // Escape: close overlay, then cancel stream (Section 18.3)
      if (e.key === 'Escape') {
        onEscape?.();
        return;
      }

      // Alt+Up / Alt+Down: Previous / Next Conversation
      if (e.altKey && e.key === 'ArrowUp') {
        e.preventDefault();
        onPrevConversation?.();
        return;
      }
      if (e.altKey && e.key === 'ArrowDown') {
        e.preventDefault();
        onNextConversation?.();
        return;
      }

      // Cmd/Ctrl + K: Open Fuzzy Command Palette
      if (isModifier && !e.shiftKey && key === 'k') {
        e.preventDefault();
        onOpenPalette?.();
        return;
      }

      // Cmd/Ctrl + F: Find in Conversation
      if (isModifier && !e.shiftKey && key === 'f') {
        e.preventDefault();
        onFindInConversation?.();
        return;
      }

      // Cmd/Ctrl + B: Toggle Navigation Sidebar
      if (isModifier && !e.shiftKey && key === 'b') {
        e.preventDefault();
        onToggleSidebar?.();
        return;
      }

      // Cmd/Ctrl + J or Cmd/Ctrl+Shift+W: Toggle Artifacts Pane
      if ((isModifier && !e.shiftKey && key === 'j') || (isModifier && e.shiftKey && key === 'w')) {
        e.preventDefault();
        onToggleWorkspace?.();
        return;
      }

      // Cmd/Ctrl + Shift + N: New Conversation
      if (isModifier && e.shiftKey && key === 'n') {
        e.preventDefault();
        onNewSession?.();
        return;
      }

      // Cmd/Ctrl + Shift + G: Regenerate Last Answer
      if (isModifier && e.shiftKey && key === 'g') {
        e.preventDefault();
        onRegenerateLast?.();
        return;
      }

      // Cmd/Ctrl + Shift + C: Copy Last Answer
      if (isModifier && e.shiftKey && key === 'c') {
        e.preventDefault();
        onCopyLastAnswer?.();
        return;
      }

      // Cmd/Ctrl + Shift + S: Open Settings
      if (isModifier && e.shiftKey && key === 's') {
        e.preventDefault();
        onToggleSettings?.();
        return;
      }

      // Cmd/Ctrl + Shift + D: Toggle Stripper
      if (isModifier && e.shiftKey && key === 'd') {
        e.preventDefault();
        onToggleStripper?.();
        return;
      }

      // Cmd/Ctrl + /: Open Shortcuts Guide
      if (isModifier && key === '/') {
        e.preventDefault();
        onToggleShortcuts?.();
        return;
      }

      // Global '?' key when not typing in an input
      if (!isModifier && e.key === '?' && !isTyping) {
        e.preventDefault();
        onToggleShortcuts?.();
        return;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    onOpenPalette,
    onFindInConversation,
    onNewSession,
    onRegenerateLast,
    onCopyLastAnswer,
    onToggleSidebar,
    onToggleWorkspace,
    onPrevConversation,
    onNextConversation,
    onToggleSettings,
    onToggleStripper,
    onToggleShortcuts,
    onEscape,
  ]);
}
