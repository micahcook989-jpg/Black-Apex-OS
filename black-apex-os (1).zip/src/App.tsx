import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { MessageItem } from './components/MessageItem';
import { ChatInput } from './components/ChatInput';
import { ArtifactsPane } from './components/ArtifactsPane';
import { SettingsModal } from './components/SettingsModal';
import { ShortcutsModal } from './components/ShortcutsModal';
import { FloatingSelectionBar } from './components/FloatingSelectionBar';
import { CommandPalette } from './components/CommandPalette';
import { FindInConversation } from './components/FindInConversation';
import { ToastUndo, UndoableAction } from './components/ToastUndo';
import { useKeyboardShortcuts } from './hooks/useKeyboardShortcuts';
import { Conversation, Message, Artifact, AppSettings, AttachmentItem } from './types';
import { ArrowDown, X, Globe, Sparkles, Code2, FileText } from 'lucide-react';

const DEFAULT_SETTINGS: AppSettings = {
  mode: 'APEX',
  stripperEnabled: true,
  persona: '',
  customInstructions: '',
  paranoidLocalStorage: false,
};

export const App: React.FC = () => {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string>('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [artifacts, setArtifacts] = useState<Artifact[]>([]);
  const [activeArtifact, setActiveArtifact] = useState<Artifact | null>(null);

  const [isSidebarOpen, setIsSidebarOpen] = useState(() => typeof window !== 'undefined' ? window.innerWidth >= 768 : true);
  const [isArtifactsOpen, setIsArtifactsOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isShortcutsOpen, setIsShortcutsOpen] = useState(false);
  const [isPaletteOpen, setIsPaletteOpen] = useState(false);
  const [isFindOpen, setIsFindOpen] = useState(false);
  const [undoAction, setUndoAction] = useState<UndoableAction | null>(null);
  const [liveAnnouncement, setLiveAnnouncement] = useState('');

  const promptInputRef = useRef<HTMLTextAreaElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const handleStopStreaming = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
  };

  // Global Keyboard Shortcuts (Section 18.3)
  useKeyboardShortcuts({
    onOpenPalette: () => {
      setIsPaletteOpen((prev) => !prev);
      setIsFindOpen(false);
      setIsShortcutsOpen(false);
      setIsSettingsOpen(false);
    },
    onFindInConversation: () => {
      setIsFindOpen((prev) => !prev);
      setIsPaletteOpen(false);
    },
    onFocusInput: () => {
      if (promptInputRef.current) {
        promptInputRef.current.focus();
        if (promptInputRef.current.value) {
          promptInputRef.current.select();
        }
      }
    },
    onToggleSettings: () => {
      setIsSettingsOpen((prev) => !prev);
      setIsShortcutsOpen(false);
      setIsPaletteOpen(false);
    },
    onToggleWorkspace: () => {
      const next = !isArtifactsOpen;
      setIsArtifactsOpen(next);
      if (next && window.innerWidth < 768) setIsSidebarOpen(false);
    },
    onToggleSidebar: () => {
      const next = !isSidebarOpen;
      setIsSidebarOpen(next);
      if (next && window.innerWidth < 768) setIsArtifactsOpen(false);
    },
    onNewSession: () => {
      handleNewConversation();
    },
    onRegenerateLast: () => {
      const assistantMsgs = messages.filter((m) => m.role === 'assistant');
      const last = assistantMsgs[assistantMsgs.length - 1];
      if (last) handleHedgeReport(last.id, 0);
    },
    onCopyLastAnswer: () => {
      const assistantMsgs = messages.filter((m) => m.role === 'assistant');
      const last = assistantMsgs[assistantMsgs.length - 1];
      if (last?.content) {
        navigator.clipboard.writeText(last.content);
        setLiveAnnouncement('Copied last answer to clipboard');
      }
    },
    onPrevConversation: () => {
      if (conversations.length <= 1) return;
      const idx = conversations.findIndex((c) => c.id === activeConversationId);
      const prevIdx = idx > 0 ? idx - 1 : conversations.length - 1;
      setActiveConversationId(conversations[prevIdx].id);
    },
    onNextConversation: () => {
      if (conversations.length <= 1) return;
      const idx = conversations.findIndex((c) => c.id === activeConversationId);
      const nextIdx = idx < conversations.length - 1 ? idx + 1 : 0;
      setActiveConversationId(conversations[nextIdx].id);
    },
    onToggleStripper: () => {
      setSettings((prev) => {
        const updated = { ...prev, stripperEnabled: !prev.stripperEnabled };
        try {
          localStorage.setItem('apex_settings', JSON.stringify(updated));
        } catch {}
        return updated;
      });
    },
    onToggleShortcuts: () => {
      setIsShortcutsOpen((prev) => !prev);
      setIsSettingsOpen(false);
      setIsPaletteOpen(false);
    },
    onEscape: () => {
      if (isPaletteOpen) {
        setIsPaletteOpen(false);
        return;
      }
      if (isFindOpen) {
        setIsFindOpen(false);
        return;
      }
      if (isShortcutsOpen) {
        setIsShortcutsOpen(false);
        return;
      }
      if (isSettingsOpen) {
        setIsSettingsOpen(false);
        return;
      }
      if (isStreaming) {
        handleStopStreaming();
        return;
      }
      if (isArtifactsOpen && window.innerWidth < 768) {
        setIsArtifactsOpen(false);
        return;
      }
      if (document.activeElement instanceof HTMLElement) {
        document.activeElement.blur();
      }
    },
  });

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const stored = localStorage.getItem('apex_settings');
      return stored ? JSON.parse(stored) : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  const [showScrollBottom, setShowScrollBottom] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [restoredDraft, setRestoredDraft] = useState<{ text: string; ts: number } | null>(null);
  const [externalSearchTrigger, setExternalSearchTrigger] = useState<{ query: string; ts: number } | null>(null);
  const [degradationText, setDegradationText] = useState<string | null>(null);
  const [dismissedDegradationText, setDismissedDegradationText] = useState<string | null>(null);
  const [slowResponseWaiting, setSlowResponseWaiting] = useState(false);

  const chatContainerRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const refreshDegradedStatus = async () => {
    try {
      const res = await fetch('/api/free/dashboard');
      if (!res.ok) return;
      const d = await res.json();
      if (d.degradedMode === 'QUOTA_OUT') {
        setDegradationText('running local only');
      } else if (
        d.degradedMode === 'QUOTA_LOW' ||
        (Array.isArray(d.providers) &&
          d.providers.some(
            (p: any) => p.provider !== 'local' && p.configured && p.remainingPercent < 15
          ))
      ) {
        setDegradationText('out of quota on one tier');
      } else {
        setDegradationText(null);
      }
    } catch {}
  };

  // Load conversations on mount
  useEffect(() => {
    loadConversations();
    refreshDegradedStatus();
  }, []);

  const loadConversations = async () => {
    try {
      const res = await fetch('/api/conversations');
      if (res.ok) {
        const data = await res.json();
        setConversations(data.conversations || []);
        if (data.conversations?.length > 0 && !activeConversationId) {
          setActiveConversationId(data.conversations[0].id);
        } else if (!activeConversationId) {
          handleNewConversation();
        }
      }
    } catch {
      if (!activeConversationId) handleNewConversation();
    }
  };

  // Load messages and artifacts when active conversation changes
  useEffect(() => {
    if (!activeConversationId) return;

    fetch(`/api/conversations/${activeConversationId}/messages`)
      .then((r) => r.json())
      .then((d) => setMessages(d.messages || []))
      .catch(() => setMessages([]));

    fetch(`/api/conversations/${activeConversationId}/artifacts`)
      .then((r) => r.json())
      .then((d) => {
        const arts = d.artifacts || [];
        setArtifacts(arts);
        if (arts.length > 0) setActiveArtifact(arts[0]);
      })
      .catch(() => setArtifacts([]));
  }, [activeConversationId]);

  // Auto-scroll handler: instant scrollTop during streaming to avoid smooth-scroll layout thrashing
  useEffect(() => {
    if (showScrollBottom) return;
    if (isStreaming && chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    } else if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isStreaming, showScrollBottom]);

  const handleScroll = () => {
    if (!chatContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = chatContainerRef.current;
    const atBottom = scrollHeight - scrollTop - clientHeight < 100;
    setShowScrollBottom(!atBottom);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    setShowScrollBottom(false);
  };

  const handleNewConversation = async () => {
    const newId = `conv-${Date.now()}`;
    const newConv: Conversation = {
      id: newId,
      title: 'New Session',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    setConversations((prev) => [newConv, ...prev]);
    setActiveConversationId(newId);
    setMessages([]);
    setArtifacts([]);
    setActiveArtifact(null);
  };

  // ---------------------------------------------------------------------------
  // Message Submission & Optimistic SSE Loop
  // ---------------------------------------------------------------------------
  const handleSendMessage = async (
    content: string,
    attachments?: AttachmentItem[],
    options?: { webSearch?: boolean; redactSecrets?: boolean }
  ) => {
    if (isStreaming) return;

    const userMsgId = `msg-${Date.now()}`;
    const assistantMsgId = `msg-${Date.now() + 1}`;
    const isWebSearch = Boolean(options?.webSearch || content.trim().startsWith('/search '));

    const newUserMsg: Message = {
      id: userMsgId,
      conversationId: activeConversationId,
      role: 'user',
      content,
      attachments,
      webSearchUsed: isWebSearch,
      createdAt: new Date().toISOString(),
    };

    // Optimistic Assistant Skeleton (Spec Section 10.11)
    const newAssistantMsg: Message = {
      id: assistantMsgId,
      conversationId: activeConversationId,
      role: 'assistant',
      content: '',
      inFlight: true,
      webSearchUsed: isWebSearch,
      receipts: [],
      createdAt: new Date().toISOString(),
    };

    const updatedMessages = [...messages, newUserMsg];
    setMessages([...updatedMessages, newAssistantMsg]);
    setIsStreaming(true);

    const controller = new AbortController();
    abortControllerRef.current = controller;
    let accumulatedContent = '';
    let rafId: number | null = null;

    const flushTokenFrame = () => {
      if (rafId !== null) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }
      const snapshot = accumulatedContent;
      setMessages((prev) =>
        prev.map((m) => (m.id === assistantMsgId ? { ...m, content: snapshot } : m))
      );
    };

    // Window outbound history on long threads (anchor + latest 23 messages)
    const wireMessages =
      updatedMessages.length > 24
        ? [updatedMessages[0], ...updatedMessages.slice(-23)]
        : updatedMessages;

    // Enrich the latest user message on the wire if attachments contain readable text previews
    const outboundMessages = wireMessages.map((m, idx) => {
      if (idx === wireMessages.length - 1 && m.role === 'user' && attachments && attachments.length > 0) {
        const readableBlocks = attachments
          .filter((a) => a.textPreview)
          .map((a) => `\n\n--- Attached File: ${a.fileName} ---\n${a.textPreview}\n--- End of ${a.fileName} ---`)
          .join('');
        return {
          role: m.role,
          content: readableBlocks ? `${m.content}${readableBlocks}` : m.content,
        };
      }
      return { role: m.role, content: m.content };
    });

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          conversationId: activeConversationId,
          messages: outboundMessages,
          mode: settings.mode,
          persona: settings.persona,
          customInstructions: settings.customInstructions ? [settings.customInstructions] : [],
          stripperEnabled: settings.stripperEnabled,
          webSearch: isWebSearch,
          attachmentCount: attachments?.length || 0,
          attachmentNames: attachments?.map((a) => a.fileName) || [],
          hasOpenArtifact: isArtifactsOpen || artifacts.length > 0,
        }),
      });

      if (!response.ok || !response.body) {
        throw new Error('Connection failed');
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split('\n\n');
        buffer = events.pop() || '';

        for (const evt of events) {
          const lines = evt.split('\n');
          let eventType = 'message';
          let eventData = '';

          for (const line of lines) {
            if (line.startsWith('event: ')) {
              eventType = line.slice(7).trim();
            } else if (line.startsWith('data: ')) {
              eventData = line.slice(6).trim();
            }
          }

          if (eventType === 'token') {
            setSlowResponseWaiting(false);
            try {
              const parsed = JSON.parse(eventData);
              accumulatedContent += parsed.text;
              if (rafId === null) {
                rafId = requestAnimationFrame(() => {
                  rafId = null;
                  const snapshot = accumulatedContent;
                  setMessages((prev) =>
                    prev.map((m) => (m.id === assistantMsgId ? { ...m, content: snapshot } : m))
                  );
                });
              }
            } catch {}
          } else if (eventType === 'status') {
            try {
              const parsed = JSON.parse(eventData);
              if (parsed.state === 'waiting_slow') {
                setSlowResponseWaiting(true);
              }
            } catch {}
          } else if (eventType === 'replacing') {
            // Repair ladder climb replace in place
            if (rafId !== null) {
              cancelAnimationFrame(rafId);
              rafId = null;
            }
            accumulatedContent = '';
            setMessages((prev) =>
              prev.map((m) => (m.id === assistantMsgId ? { ...m, content: '' } : m))
            );
          } else if (eventType === 'chips') {
            try {
              const parsed = JSON.parse(eventData);
              setMessages((prev) =>
                prev.map((m) => (m.id === assistantMsgId ? { ...m, suggestedChips: parsed.chips } : m))
              );
            } catch {}
          } else if (eventType === 'grounding') {
            try {
              const parsed = JSON.parse(eventData);
              if (Array.isArray(parsed.sources)) {
                setMessages((prev) =>
                  prev.map((m) =>
                    m.id === assistantMsgId
                      ? { ...m, groundingSources: parsed.sources, webSearchUsed: true }
                      : m
                  )
                );
              }
            } catch {}
          } else if (eventType === 'error') {
            let errText = 'Upstream provider request failed.';
            try {
              const parsed = JSON.parse(eventData);
              if (parsed.message) errText = parsed.message;
            } catch {}
            throw new Error(errText);
          } else if (eventType === 'done') {
            setSlowResponseWaiting(false);
            try {
              if (rafId !== null) {
                cancelAnimationFrame(rafId);
                rafId = null;
              }
              const parsed = JSON.parse(eventData);
              const words = parsed.text ? parsed.text.trim().split(/\s+/).filter(Boolean).length : 0;
              setLiveAnnouncement(`Answer complete, ${words} words.`);
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === assistantMsgId
                    ? {
                        ...m,
                        content: parsed.text,
                        rawContent: parsed.rawText,
                        winningRung: parsed.winningRung,
                        receipts: parsed.receipts,
                        suggestedChips: parsed.chips || m.suggestedChips,
                        groundingSources: parsed.groundingSources || m.groundingSources,
                        webSearchUsed: Boolean(parsed.webSearchUsed || m.webSearchUsed),
                        hideGlyphs: parsed.hideGlyphs,
                        inFlight: false,
                        stopped: false,
                        errorMessage: undefined,
                      }
                    : m
                )
              );
            } catch {}
          }
        }
      }
      if (rafId !== null) {
        flushTokenFrame();
      }
    } catch (err: any) {
      if (rafId !== null) {
        cancelAnimationFrame(rafId);
        rafId = null;
      }
      if (err.name === 'AbortError') {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? { ...m, inFlight: false, stopped: true }
              : m
          )
        );
        setLiveAnnouncement('Response generation stopped.');
      } else {
        // PATCH 01 (P3.6): Produce a specific sentence, preserve the draft in the composer, and allow 1-click retry
        const specificReason = err?.message || 'Upstream connection interrupted';
        const errorSentence = `Turn failed: ${specificReason}. Your draft is preserved below — click Retry to run again.`;
        setRestoredDraft({ text: content, ts: Date.now() });
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantMsgId
              ? {
                  ...m,
                  content: accumulatedContent || errorSentence,
                  errorMessage: errorSentence,
                  retryPrompt: content,
                  inFlight: false,
                }
              : m
          )
        );
      }
    } finally {
      setSlowResponseWaiting(false);
      setIsStreaming(false);
      abortControllerRef.current = null;
      loadConversations();
      refreshDegradedStatus();
    }
  };

  const handleRetryFailedTurn = (assistantMsgId: string, retryPrompt?: string) => {
    const targetIdx = messages.findIndex((m) => m.id === assistantMsgId);
    let promptToSend = retryPrompt || '';
    if (!promptToSend && targetIdx > 0 && messages[targetIdx - 1]?.role === 'user') {
      promptToSend = messages[targetIdx - 1].content;
    }
    setMessages((prev) =>
      prev.filter((m, idx) => m.id !== assistantMsgId && idx !== targetIdx - 1)
    );
    if (promptToSend) {
      setTimeout(() => {
        handleSendMessage(promptToSend);
      }, 10);
    }
  };

  const handleContinueMessage = (msg: Message) => {
    const tail = msg.content.slice(-100);
    handleSendMessage(`Continue precisely where you stopped without repeating prior text: "${tail}"`);
  };

  // ---------------------------------------------------------------------------
  // "That was a hedge" affordance handler (Spec Section 4)
  // ---------------------------------------------------------------------------
  const handleHedgeReport = async (messageId: string, currentRung: number = 0) => {
    const targetMsg = messages.find((m) => m.id === messageId);
    if (!targetMsg) return;

    setMessages((prev) =>
      prev.map((m) => (m.id === messageId ? { ...m, inFlight: true, content: '' } : m))
    );

    try {
      const targetIdx = messages.findIndex((m) => m.id === messageId);
      const priorMsgs = (targetIdx >= 0 ? messages.slice(0, targetIdx) : messages)
        .filter((m) => m.role === 'user' || m.role === 'assistant')
        .map((m) => ({ role: m.role, content: m.content }));

      const response = await fetch('/api/chat/hedge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversationId: activeConversationId,
          messageId,
          currentRung,
          messages: priorMsgs,
        }),
      });

      if (!response.ok || !response.body) throw new Error('Hedge climb failed');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let accumulated = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split('\n\n');
        buffer = events.pop() || '';

        for (const evt of events) {
          const lines = evt.split('\n');
          let eventType = 'message';
          let eventData = '';
          for (const line of lines) {
            if (line.startsWith('event: ')) eventType = line.slice(7).trim();
            if (line.startsWith('data: ')) eventData = line.slice(6).trim();
          }

          if (eventType === 'token') {
            try {
              const parsed = JSON.parse(eventData);
              accumulated += parsed.text;
              setMessages((prev) =>
                prev.map((m) => (m.id === messageId ? { ...m, content: accumulated } : m))
              );
            } catch {}
          } else if (eventType === 'done') {
            try {
              const parsed = JSON.parse(eventData);
              setMessages((prev) =>
                prev.map((m) =>
                  m.id === messageId
                    ? {
                        ...m,
                        content: parsed.text,
                        rawContent: parsed.rawText,
                        winningRung: parsed.winningRung,
                        receipts: parsed.receipts,
                        suggestedChips: parsed.chips,
                        inFlight: false,
                      }
                    : m
                )
              );
            } catch {}
          }
        }
      }
    } catch {
      setMessages((prev) =>
        prev.map((m) => (m.id === messageId ? { ...m, inFlight: false } : m))
      );
    }
  };

  // Branch timeline from message
  const handleBranch = async (fromMessageId: string) => {
    try {
      const res = await fetch('/api/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: `Branch of ${activeConversation?.title || 'Session'}`,
          branchOf: { conversationId: activeConversationId, fromMessageId },
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setConversations((prev) => [data.conversation, ...prev]);
        setActiveConversationId(data.conversation.id);
      }
    } catch {}
  };

  // Create artifact from code block or selection
  const handleCreateArtifact = async (title: string, type: any, content: string) => {
    try {
      const res = await fetch('/api/artifacts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          conversationId: activeConversationId,
          title,
          type,
          content,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        setArtifacts((prev) => [data.artifact, ...prev]);
        setActiveArtifact(data.artifact);
        setIsArtifactsOpen(true);
      }
    } catch {}
  };

  // Text selection actions
  const handleSelectionAction = (action: string, selectedText: string) => {
    if (action === 'artifact') {
      handleCreateArtifact('Extracted Selection', 'markdown', selectedText);
    } else if (action === 'search') {
      // Populate input, activate Google Search grounding, and highlight the selected text in blue
      setExternalSearchTrigger({ query: selectedText, ts: Date.now() });
    } else {
      handleSendMessage(`${action.toUpperCase()}: ${selectedText}`);
    }
  };

  // Browser speech synthesis (TTS)
  const handleSpeak = (text: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      window.speechSynthesis.speak(utterance);
    }
  };

  // Export transcript
  const handleExport = (id: string, format: 'md' | 'txt' | 'json') => {
    const targetMsgs = messages;
    let exportContent = '';
    let mimeType = 'text/plain';

    if (format === 'json') {
      exportContent = JSON.stringify(targetMsgs, null, 2);
      mimeType = 'application/json';
    } else {
      exportContent = targetMsgs
        .map((m) => `### ${m.role.toUpperCase()} (${m.createdAt})\n\n${m.content}\n\n---\n`)
        .join('\n');
      mimeType = format === 'md' ? 'text/markdown' : 'text/plain';
    }

    const blob = new Blob([exportContent], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transcript_${id}.${format}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const activeConversation = conversations.find((c) => c.id === activeConversationId);

  return (
    <div className="flex flex-col h-screen w-screen bg-[#090a0d] text-zinc-100 overflow-hidden select-none font-sans">
      <Header
        conversationTitle={activeConversation?.title || 'Session'}
        isSidebarOpen={isSidebarOpen}
        isArtifactsOpen={isArtifactsOpen}
        isBranch={Boolean(activeConversation?.branchOf)}
        onToggleSidebar={() => {
          const next = !isSidebarOpen;
          setIsSidebarOpen(next);
          if (next && window.innerWidth < 768) setIsArtifactsOpen(false);
        }}
        onToggleArtifacts={() => {
          const next = !isArtifactsOpen;
          setIsArtifactsOpen(next);
          if (next && window.innerWidth < 768) setIsSidebarOpen(false);
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenShortcuts={() => setIsShortcutsOpen(true)}
        onNewConversation={handleNewConversation}
      />

      <div className="flex-1 flex overflow-hidden relative">
        {/* Sidebar */}
        {isSidebarOpen && (
          <Sidebar
            conversations={conversations}
            activeId={activeConversationId}
            onSelectConversation={setActiveConversationId}
            onDeleteConversation={async (id) => {
              const convToDelete = conversations.find((c) => c.id === id);
              await fetch(`/api/conversations/${id}`, { method: 'DELETE' });
              setConversations((prev) => prev.filter((c) => c.id !== id));
              if (activeConversationId === id) handleNewConversation();
              if (convToDelete) {
                setUndoAction({
                  id: `undo-del-conv-${Date.now()}`,
                  description: `Deleted "${convToDelete.title}"`,
                  timestamp: Date.now(),
                  onUndo: async () => {
                    await fetch('/api/conversations', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ id: convToDelete.id, title: convToDelete.title }),
                    });
                    setConversations((prev) => [convToDelete, ...prev]);
                    setActiveConversationId(convToDelete.id);
                  },
                });
              }
            }}
            onRenameConversation={async (id, title) => {
              await fetch(`/api/conversations/${id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title }),
              });
              setConversations((prev) => prev.map((c) => (c.id === id ? { ...c, title } : c)));
            }}
            onPinConversation={async (id, pinned) => {
              await fetch(`/api/conversations/${id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ pinned }),
              });
              setConversations((prev) => prev.map((c) => (c.id === id ? { ...c, pinned } : c)));
            }}
            onExportConversation={handleExport}
            onCloseMobile={() => {
              if (window.innerWidth < 768) setIsSidebarOpen(false);
            }}
          />
        )}

        {/* Central Chat Feed */}
        <main className="flex-1 flex flex-col h-full overflow-hidden relative bg-[#090a0d]">
          {/* PATCH 01 (P5): Single-line status strip at top of chat, only visible when degraded, dismissible, reappears only on state change */}
          {(() => {
            const activeStrip = slowResponseWaiting
              ? 'waiting on a slow response'
              : degradationText;
            if (!activeStrip || dismissedDegradationText === activeStrip) return null;
            return (
              <div
                role="status"
                className="w-full px-4 py-1 bg-[#12141c] border-b border-zinc-800/80 text-[11px] font-mono text-zinc-300 flex items-center justify-between select-none"
              >
                <span className="truncate">{activeStrip}</span>
                <button
                  type="button"
                  onClick={() => setDismissedDegradationText(activeStrip)}
                  className="text-zinc-500 hover:text-zinc-300 p-0.5"
                  aria-label="Dismiss status notice"
                >
                  <X size={12} />
                </button>
              </div>
            );
          })()}

          {/* Screen reader live region */}
          <div role="status" aria-live="polite" className="sr-only">
            {liveAnnouncement}
          </div>

          <div
            ref={chatContainerRef}
            role="log"
            aria-live="polite"
            aria-busy={isStreaming}
            onScroll={handleScroll}
            className="flex-1 overflow-y-auto px-2 sm:px-6 py-4 space-y-2 select-text"
          >
            {messages.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 select-none">
                <div className="max-w-2xl w-full space-y-6">
                  <div className="space-y-1.5">
                    <div className="font-mono text-sm tracking-widest text-zinc-200 font-bold">
                      BLACK APEX OS
                    </div>
                    <div className="font-mono text-xs text-zinc-500 max-w-md mx-auto">
                      Universal AI assistant &amp; engineering workspace. Ask anything naturally, attach files for visual preview, or toggle the Globe for live Google Search data.
                    </div>
                  </div>

                  {/* Curated Assistant & Google Search Quick-Start Cards */}
                  <div
                    data-testid="empty-state-ideas"
                    className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-left"
                  >
                    <button
                      type="button"
                      onClick={() =>
                        setExternalSearchTrigger({
                          query: 'What are the most important technology and AI developments this week?',
                          ts: Date.now(),
                        })
                      }
                      className="group p-3.5 rounded-xl bg-[#11131a] hover:bg-blue-950/25 border border-zinc-800/80 hover:border-blue-500/40 transition-all flex items-start gap-3"
                    >
                      <div className="p-2 rounded-lg bg-blue-500/10 border border-blue-500/25 text-blue-400 shrink-0">
                        <Globe size={15} />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-medium text-zinc-200 group-hover:text-blue-300 transition-colors">
                            Use Google Search Data
                          </span>
                          <span className="px-1.5 py-0.5 rounded bg-blue-500/15 text-[9px] font-mono text-blue-300">
                            LIVE
                          </span>
                        </div>
                        <p className="text-[11px] text-zinc-500 mt-1 line-clamp-2">
                          Ground answers in real-time web results with cited sources and blue search highlighting.
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        setRestoredDraft({
                          text: 'Help me brainstorm, structure, and write a clear executive summary for a new product launch.',
                          ts: Date.now(),
                        })
                      }
                      className="group p-3.5 rounded-xl bg-[#11131a] hover:bg-zinc-900/90 border border-zinc-800/80 hover:border-zinc-700 transition-all flex items-start gap-3"
                    >
                      <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/25 text-emerald-400 shrink-0">
                        <Sparkles size={15} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-zinc-200 group-hover:text-white transition-colors">
                          Everyday AI Assistant
                        </div>
                        <p className="text-[11px] text-zinc-500 mt-1 line-clamp-2">
                          Write, summarize, brainstorm, or answer general questions clearly and naturally.
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        setRestoredDraft({
                          text: 'Design a clean, fault-tolerant TypeScript service architecture with automated retry and observability.',
                          ts: Date.now(),
                        })
                      }
                      className="group p-3.5 rounded-xl bg-[#11131a] hover:bg-zinc-900/90 border border-zinc-800/80 hover:border-zinc-700 transition-all flex items-start gap-3"
                    >
                      <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/25 text-amber-400 shrink-0">
                        <Code2 size={15} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-zinc-200 group-hover:text-white transition-colors">
                          Code &amp; System Architecture
                        </div>
                        <p className="text-[11px] text-zinc-500 mt-1 line-clamp-2">
                          Build production code, debug complex issues, or generate runnable workspace artifacts.
                        </p>
                      </div>
                    </button>

                    <button
                      type="button"
                      onClick={() =>
                        setRestoredDraft({
                          text: 'Compare the pros, cons, and trade-offs of three approaches in a structured Markdown table.',
                          ts: Date.now(),
                        })
                      }
                      className="group p-3.5 rounded-xl bg-[#11131a] hover:bg-zinc-900/90 border border-zinc-800/80 hover:border-zinc-700 transition-all flex items-start gap-3"
                    >
                      <div className="p-2 rounded-lg bg-purple-500/10 border border-purple-500/25 text-purple-400 shrink-0">
                        <FileText size={15} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-medium text-zinc-200 group-hover:text-white transition-colors">
                          Structured Analysis &amp; Files
                        </div>
                        <p className="text-[11px] text-zinc-500 mt-1 line-clamp-2">
                          Drop files for visual preview cards or request formatted tables, lists, and reports.
                        </p>
                      </div>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              messages.map((msg, idx) => (
                <MessageItem
                  key={msg.id}
                  message={msg}
                  isLatest={idx === messages.length - 1}
                  onCopy={(t) => navigator.clipboard.writeText(t)}
                  onRegenerate={() => handleHedgeReport(msg.id, 0)}
                  onRetryTurn={handleRetryFailedTurn}
                  onBranch={handleBranch}
                  onHedgeReport={handleHedgeReport}
                  onDelete={(id) => {
                    const msgToDelete = messages.find((m) => m.id === id);
                    setMessages((prev) => prev.filter((m) => m.id !== id));
                    if (msgToDelete) {
                      setUndoAction({
                        id: `undo-del-msg-${Date.now()}`,
                        description: 'Message deleted',
                        timestamp: Date.now(),
                        onUndo: () => {
                          setMessages((prev) =>
                            [...prev, msgToDelete].sort(
                              (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
                            )
                          );
                        },
                      });
                    }
                  }}
                  onSpeak={handleSpeak}
                  onSelectChip={(chip) => handleSendMessage(chip)}
                  onCreateArtifactFromCode={handleCreateArtifact}
                  onContinue={() => handleContinueMessage(msg)}
                />
              ))
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Jump to bottom pill */}
          {showScrollBottom && (
            <button
              onClick={scrollToBottom}
              className="absolute bottom-24 right-8 p-2 rounded-full bg-zinc-800/90 border border-zinc-700 text-zinc-300 hover:text-white shadow-xl transition-all z-20"
              title="Jump to latest"
              aria-label="Scroll to bottom"
            >
              <ArrowDown size={14} />
            </button>
          )}

          {/* Input Box — P3.5: Composer never disables */}
          <ChatInput
            inputRef={promptInputRef}
            conversationId={activeConversationId}
            onSendMessage={handleSendMessage}
            onRecallLastMessage={() => {
              const userMsgs = messages.filter((m) => m.role === 'user');
              return userMsgs[userMsgs.length - 1]?.content;
            }}
            disabled={false}
            isStreaming={isStreaming}
            onStopStreaming={handleStopStreaming}
            requireCmdEnter={settings.requireCmdEnter}
            restoredDraft={restoredDraft}
            externalSearchTrigger={externalSearchTrigger}
          />

          {/* Scoped text selection bar */}
          <FloatingSelectionBar onAction={handleSelectionAction} />
        </main>

        {/* Workspace Artifacts Pane */}
        {isArtifactsOpen && (
          <ArtifactsPane
            artifacts={artifacts}
            activeArtifact={activeArtifact}
            onSelectArtifact={setActiveArtifact}
            onUpdateArtifact={(art) => {
              setActiveArtifact(art);
              setArtifacts((prev) => prev.map((a) => (a.id === art.id ? art : a)));
            }}
            onClose={() => setIsArtifactsOpen(false)}
          />
        )}
      </div>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        settings={settings}
        onClose={() => setIsSettingsOpen(false)}
        onSaveSettings={(newSettings) => {
          setSettings(newSettings);
          try {
            localStorage.setItem('apex_settings', JSON.stringify(newSettings));
          } catch {}
        }}
      />

      {/* Keyboard Shortcuts Cheat Sheet Modal */}
      <ShortcutsModal
        isOpen={isShortcutsOpen}
        onClose={() => setIsShortcutsOpen(false)}
      />

      {/* Fuzzy Command Palette (Section 18.3) */}
      <CommandPalette
        isOpen={isPaletteOpen}
        onClose={() => setIsPaletteOpen(false)}
        conversations={conversations}
        activeConversationId={activeConversationId}
        onSelectConversation={(id) => {
          setActiveConversationId(id);
          setIsPaletteOpen(false);
        }}
        onNewConversation={() => {
          handleNewConversation();
          setIsPaletteOpen(false);
        }}
        onOpenSettings={() => {
          setIsSettingsOpen(true);
          setIsPaletteOpen(false);
        }}
        onToggleSidebar={() => {
          setIsSidebarOpen((prev) => !prev);
          setIsPaletteOpen(false);
        }}
        onToggleWorkspace={() => {
          setIsArtifactsOpen((prev) => !prev);
          setIsPaletteOpen(false);
        }}
        onToggleStripper={() => {
          setSettings((prev) => {
            const updated = { ...prev, stripperEnabled: !prev.stripperEnabled };
            try {
              localStorage.setItem('apex_settings', JSON.stringify(updated));
            } catch {}
            return updated;
          });
          setIsPaletteOpen(false);
        }}
        onSetMode={(m) => {
          setSettings((prev) => {
            const updated = { ...prev, mode: m };
            try {
              localStorage.setItem('apex_settings', JSON.stringify(updated));
            } catch {}
            return updated;
          });
          setIsPaletteOpen(false);
        }}
        onOpenRegressionSuite={() => {
          setIsPaletteOpen(false);
          handleSendMessage('/test-suite');
        }}
        onExportCurrent={() => {
          handleExport(activeConversationId, 'md');
          setIsPaletteOpen(false);
        }}
      />

      {/* In-Conversation Text Search (Section 18.4) */}
      <FindInConversation
        isOpen={isFindOpen}
        onClose={() => setIsFindOpen(false)}
        containerRef={chatContainerRef}
      />

      {/* 10-Second Undo Safety Toast (Section 18.2) */}
      <ToastUndo
        action={undoAction}
        onDismiss={() => setUndoAction(null)}
      />
    </div>
  );
};

export default App;
