export interface MessageReceipt {
  rung: number;
  providerCodename: string;
  latencyMs: number;
  hedged: boolean;
  modelTier: string;
  draftSnippet: string;
  timestamp: string;
  cached?: boolean;
}

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface AttachmentItem {
  fileName: string;
  filePath: string;
  preview?: string;
  textPreview?: string;
  size?: number;
  mimeType?: string;
}

export interface Message {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  rawContent?: string;
  isStripped?: boolean;
  winningRung?: number;
  receipts?: MessageReceipt[];
  suggestedChips?: string[];
  groundingSources?: GroundingSource[];
  webSearchUsed?: boolean;
  inFlight?: boolean;
  stopped?: boolean;
  hideGlyphs?: boolean;
  errorMessage?: string;
  retryPrompt?: string;
  attachments?: AttachmentItem[];
  createdAt: string;
}

export interface Conversation {
  id: string;
  title: string;
  folderId?: string | null;
  pinned?: boolean;
  branchOf?: { conversationId: string; fromMessageId: string } | null;
  createdAt: string;
  updatedAt: string;
}

export interface Artifact {
  id: string;
  conversationId: string;
  title: string;
  type: 'html' | 'react' | 'svg' | 'markdown' | 'mermaid' | 'table' | 'userscript' | 'filetree' | 'code';
  content: string;
  version: number;
  history?: { version: number; content: string; timestamp: string }[];
  createdAt: string;
  updatedAt: string;
}

export interface MemoryFact {
  id: string;
  fact: string;
  category: 'preference' | 'profession' | 'constraint' | 'project';
  pinned: boolean;
  sourceConversationId?: string;
  createdAt: string;
}

export type OperatingMode = 'APEX' | 'LONE' | 'BRUTAL' | 'RAW';

export interface AppSettings {
  mode: OperatingMode;
  stripperEnabled: boolean;
  persona: string;
  customInstructions: string;
  userGeminiKey?: string;
  userGroqKey?: string;
  userOpenRouterKey?: string;
  paranoidLocalStorage: boolean;
  requireCmdEnter?: boolean;
  readerMode?: boolean;
}
