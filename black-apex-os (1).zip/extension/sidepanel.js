// Section 24.4 — Side Panel Controller
(function () {
  const promptBox = document.getElementById('prompt-box');
  const outputPre = document.getElementById('output');
  const fallbackBanner = document.getElementById('fallback-banner');

  async function sendToActiveTab(message) {
    if (typeof chrome === 'undefined' || !chrome.tabs) {
      fallbackBanner.style.display = 'block';
      return { blocked: true };
    }
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab || !tab.id) throw new Error('No active tab');
      return await chrome.tabs.sendMessage(tab.id, message);
    } catch (_err) {
      // Degrade gracefully to plain text box when page blocks script injection
      fallbackBanner.style.display = 'block';
      return { blocked: true };
    }
  }

  document.getElementById('btn-pick-element')?.addEventListener('click', async () => {
    const res = await sendToActiveTab({ type: 'APEX_PICK_ELEMENT' });
    if (res && res.selector) {
      promptBox.value += `\nVerified selector: ${res.selector}`;
    }
  });

  document.getElementById('btn-capture-page')?.addEventListener('click', async () => {
    const res = await sendToActiveTab({ type: 'APEX_CAPTURE_CONTEXT' });
    if (res && res.text) {
      promptBox.value += `\nPage context:\n${res.text.slice(0, 2000)}`;
    }
  });

  document.getElementById('btn-inject-userscript')?.addEventListener('click', async () => {
    const code = promptBox.value.trim();
    const res = await sendToActiveTab({ type: 'APEX_INJECT_USERSCRIPT', code });
    outputPre.textContent = res && !res.blocked ? 'Userscript injected into active tab.' : 'Injection blocked by page; using plain text box.';
  });

  document.getElementById('btn-send')?.addEventListener('click', async () => {
    const token = localStorage.getItem('BAX_API_TOKEN') || 'bax_default_local_token';
    const baseUrl = localStorage.getItem('BAX_API_URL') || 'http://localhost:3000';
    const res = await fetch(`${baseUrl}/api/v1/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({
        messages: [{ role: 'user', content: promptBox.value }],
        stream: false,
      }),
    });
    const data = await res.json();
    outputPre.textContent = data.content || JSON.stringify(data);
  });
})();
