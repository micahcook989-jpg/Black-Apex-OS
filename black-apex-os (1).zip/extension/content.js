// Section 24.4 — Content Script: Verified Element Selector & Live Userscript Host
(function () {
  function computeVerifiedSelector(el) {
    if (!el || el.nodeType !== 1) return 'body';
    if (el.id) {
      const idSel = `#${CSS.escape(el.id)}`;
      if (document.querySelectorAll(idSel).length === 1) return idSel;
    }
    const parts = [];
    let cur = el;
    while (cur && cur.nodeType === 1 && cur.tagName.toLowerCase() !== 'html') {
      let part = cur.tagName.toLowerCase();
      if (cur.id) {
        part += `#${CSS.escape(cur.id)}`;
        parts.unshift(part);
        break;
      } else if (cur.parentElement) {
        const siblings = Array.from(cur.parentElement.children).filter(
          (c) => c.tagName === cur.tagName
        );
        if (siblings.length > 1) {
          const idx = siblings.indexOf(cur) + 1;
          part += `:nth-of-type(${idx})`;
        }
      }
      parts.unshift(part);
      cur = cur.parentElement;
    }
    return parts.join(' > ');
  }

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg.type === 'APEX_PICK_ELEMENT') {
        const active = document.activeElement || document.body;
        const selector = computeVerifiedSelector(active);
        sendResponse({ selector, verified: document.querySelector(selector) === active });
        return true;
      }
      if (msg.type === 'APEX_CAPTURE_CONTEXT') {
        sendResponse({
          url: location.href,
          title: document.title,
          selection: window.getSelection()?.toString() || '',
          text: document.body?.innerText || '',
        });
        return true;
      }
      if (msg.type === 'APEX_INJECT_USERSCRIPT') {
        const script = document.createElement('script');
        script.dataset.apexUserscript = 'true';
        script.textContent = msg.code || '';
        (document.head || document.documentElement).appendChild(script);
        sendResponse({ injected: true });
        return true;
      }
      return false;
    });
  }
})();
