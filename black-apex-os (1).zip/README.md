# Black Apex OS

Universal multi-provider AI cockpit with automated 5-rung refusal-recovery escalation, per-turn register/gear inference, pre-encoded `logit_bias` hedge suppression, local codebase indexing, headless `/api/v1` + `bax` CLI, multi-path public reachability, and sandboxed self-healing.

---

## 1. Quick Start & Binding (Section 26.1)

```bash
cp .env.example .env
npm install
npm run build
npm run dev
```

- Binds `0.0.0.0:${PORT:-3000}` by default (never `127.0.0.1` only) and logs every reachable LAN IP and public URL at boot.
- `GET /healthz`: Liveness endpoint returning `200 OK` within `<2s` of cold boot without blocking on remote providers or database queries.
- `GET /readyz`: Readiness endpoint verifying upstream provider discovery and local storage durability.
- `GET /status`: Auth-gated status page reporting uptime, last restart, last deploy, provider health, blue-green slot state, and recent incidents.
- `GET /ops`: Auth-gated self-healing operations log with `?unresolved=1` filtering, incident classification, patch diffs, and verification outcomes.

---

## 2. Public Exposure Paths (Section 26.2)

All four public exposure configurations are committed and ready to run:

1. **Cloudflare Tunnel (Default for home / VPS)**:
   - Config: `deploy/cloudflared-config.yml`
   - Systemd unit: `deploy/cloudflared.service`
2. **Tailscale Funnel (Private or public HTTPS without a domain)**:
   - Script: `bash deploy/tailscale-funnel.sh` (or `bash deploy/tailscale-funnel.sh private`)
3. **Managed Platform (Fly.io)**:
   - Config: `fly.toml` (`min_machines_running = 1`, dual-region `iad` + `ord`, `/healthz` check)
   - Container: `Dockerfile` & `docker-compose.yml` (`restart: unless-stopped` + `HEALTHCHECK`)
4. **VPS with Caddy Reverse Proxy**:
   - Config: `deploy/Caddyfile` (automatic TLS, HSTS, HTTP/2, and `flush_interval -1` so SSE streaming is never buffered)

### Public Exposure Auth Gate (Section 26.3)
- Enabled automatically on external tunnel/public traffic (`PUBLIC_AUTH_GATE_ENABLED=true`), while staying frictionless (off) for `localhost` / `127.0.0.1` requests.
- Supports Argon2id password verification (`PUBLIC_AUTH_PASSWORD_HASH`), 30-day HMAC-signed session cookies (`SameSite=Lax; Secure; HttpOnly`), optional WebAuthn/Passkey assertions, optional API IP/CIDR allowlists (`PUBLIC_API_CIDR_ALLOWLIST`), optional Cloudflare Access JWT headers (`Cf-Access-Jwt-Assertion`), and automatic 10-minute IP lockout after 8 failed login attempts.

---

## 3. Self-Healing & Honest Limits (Section 27 & 27.6)

Black Apex OS classifies every captured incident into `TRANSIENT`, `CONFIG`, `DATA`, `CODE`, `DEPENDENCY`, or `EXTERNAL`:
- `TRANSIENT` and `EXTERNAL` incidents trigger retries, fallback tiers, or circuit breakers and **never** trigger code self-patching.
- `CODE` incidents with a stable stack signature run through the sandboxed Self-Patch Loop (`data/heal-sandbox/<id>`):
  1. Reproduce with a failing test (max 2 attempts).
  2. Localize to `<= 3` allowlisted files (migrations, the doctrine block, auth, and retention are strictly off-limits).
  3. Apply a minimal unified diff in the sandbox.
  4. Verify full TypeScript typecheck, unit test suite, 25-prompt restriction suite, and smoke suite.
  5. On green: commit to `apex/heal`, switch via Blue-Green deployment (keeping the previous slot warm for 10 minutes), and auto-revert if the signature recurs within 24 hours.
  6. On red: revert immediately, mark the incident `unpatchable`, and queue for human review in `/ops`.

### Honest Limits (Section 27.6)
The self-healing engine **cannot** automatically fix:
- Upstream provider outages (`Gemini`, `Groq`, `OpenRouter` downtime)
- Exhausted billing quotas or rate-limit walls across all configured keys
- Expired or revoked credentials for which it has no replacement secret
- Host hardware, disk, or kernel failures
- Non-deterministic bugs that cannot be reproduced within 2 test attempts
- Product, UX, or architectural problems that require a human design decision

All such cases are never self-patched; instead, they escalate immediately to the `/ops` admin panel with a specific, actionable diagnostic message.

---

## 4. Free-Only Operating Mode (Addendum — Section 32)

Black Apex OS runs with **zero recurring cost**. Every paid dependency is replaced by a free local or open-tier equivalent, and the repair ladder is inverted to **local-first**:

- **Rung 0 (Primary Default)**: Local model (`Ollama` / `llama.cpp`) with uncensored-capable tags.
- **Escalation Tiers**: Remote free tiers (`Groq`, `Gemini`, `OpenRouter :free`) are reserved for very hard reasoning (`DEEP`), huge context windows, live web grounding, and refusal recovery.
- If no local model is configured (`OLLAMA_BASE_URL` unset), the app runs remote-only seamlessly and states so on a single plain line in Settings without a warning banner.

### 4.1 Free Roster & Published Limits (Section 32.2)

| Provider Tier | Role | Published Free Limits | Default Economy Cap (~50%) | Notes |
| :--- | :--- | :--- | :--- | :--- |
| **Local (`Ollama` / `llama.cpp`)** | Primary (`Rung 0`) | **Unlimited** (No RPM/RPD quota) | Unlimited | Uncensored-capable local weights |
| **Groq Free** | Fast tier & 4-token classifiers | **30 RPM**, **14,400 RPD** (8B) / **1,000 RPD** (70B) | **7,200 RPD** / 900 RPH per key | Sub-second TTFT & hedge/gear classification |
| **Gemini Free** | Reasoning tier (spent deliberately) | **5–15 RPM**, **~25 RPD** on Pro / **~500 RPD** on Flash | **250 RPD** / 45 RPH per key | High-complexity reasoning & long context |
| **OpenRouter `:free`** | Uncensored floor | **~20 RPM**, **~50 RPD** | **25 RPD** / 15 RPH per key | Open-weight uncensored fallback pool |

> **Highest-Value Optional Upgrade ($10 One-Time)**: A one-time **$10 OpenRouter credit top-up** raises the `:free` model rate limit from `~50 RPD` to **`~1,000 RPD`** without consuming credits when calling `:free` endpoints. Black Apex OS is designed and tested to operate without this top-up, and supports comma-separated multi-key pools (`GROQ_API_KEYS`, `GEMINI_API_KEYS`, `OPENROUTER_API_KEYS`) to multiply daily ceilings across keys.

### 4.2 Request Economy, 5-Layer Cache & Adaptive Racing (Sections 32.3–32.8)

- **Per-Turn Request Caps by Gear**: `CHAT: 1`, `TASK: 3`, `HEAVY: 6`, `DEEP: 10`, `RESEARCH: 40`.
- **Interactive Reserve Floor**: **20%** of remaining daily quota is strictly reserved for interactive turns; background jobs only consume surplus (`> 20%`).
- **Silent Rung Skip**: Any remote provider under **15% remaining quota** has its ladder rung skipped automatically and logged without user-facing error text.
- **5-Layer Per-Install Cache Hierarchy** (purgeable from Settings -> `PURGE CACHES` or `POST /api/free/cache/purge`):
  1. Exact `SHA-256` hash of `conversationState + prompt`.
  2. Semantic cache at `>= 0.95` cosine similarity on local embeddings (returns prior answer with a `CACHED` receipt mark).
  3. Doc-grounding cache keyed by `package@version` (7-day TTL).
  4. Search result cache keyed by normalized query (24-hour TTL).
  5. Fetch cache keyed by `URL + content hash` respecting `Cache-Control` (default 6-hour TTL).
- **Adaptive Racing**: Races at most **1 hop**, only on interactive non-`CHAT` turns when **both candidate keys have `> 40%` remaining quota**.

### 4.3 Free Search & Media Backends (Sections 32.9–32.10)

- **Search Registry (Zero Paid Defaults — Exa Removed)**:
  - **Primary**: Self-hosted `SearXNG` (`SEARXNG_BASE_URL`, no quota)
  - **Archival**: `Wayback Machine CDX`, `Common Crawl Index`
  - **Academic**: `OpenAlex`, `Crossref`, `Semantic Scholar`, `PubMed`, `arXiv`
  - **Legal**: `CourtListener`, `EUR-Lex`, `Federal Register`
  - **Corporate**: `SEC EDGAR Full-Text`, `OpenCorporates`
  - **Infrastructure**: `crt.sh`, `RDAP`
  - **Code & Advisories**: `GitHub Code Search`, `OSV`, `NVD`
  - **Indie, News & Stats**: `Marginalia`, `GDELT`, `data.gov`, `World Bank`
  - **Optional Free Supplements**: `Tavily Free` (1,000/month) and `Brave Search Free` (skipped silently when keys are absent)
- **Media & Embeddings**:
  - **STT**: Browser Web Speech API + local `Whisper.cpp` for audio files.
  - **TTS**: Local `Piper` + browser `speechSynthesis` fallback.
  - **Image Generation**: `Pollinations` (free, keyless), `Hugging Face Inference` free tier, or local `SDXL/ComfyUI` when a GPU is available.
  - **Embeddings**: Deterministic local vector encoder only (zero paid embedding calls).

### 4.4 Recommended Free Hosting: Oracle Cloud Always Free ARM VM (Sections 32.11–32.12)

1. **Oracle Cloud Always Free ARM (`VM.Standard.A1.Flex` — Recommended)**:
   - **Specs**: **4 Ampere A1 OCPUs**, **24 GB RAM**, **200 GB Block Volume** — $0/month permanently, and large enough to run Black Apex OS, `SearXNG`, `Caddy`, and a **14B quantized local model (`Ollama`)** on Rung 0.
   - **Setup**:
     ```bash
     # On Ubuntu 24.04 ARM64 (Oracle Cloud Ampere A1):
     curl -fsSL https://ollama.com/install.sh | sh
     ollama pull qwen2.5-coder:14b
     git clone <repo-url> black-apex-os && cd black-apex-os
     cp .env.example .env
     # Set OLLAMA_BASE_URL="http://127.0.0.1:11434" in .env
     docker compose up -d --build
     ```
   - **Oracle Idle-Reclaim Caveat**: Oracle reclaims Always Free compute instances if CPU, network, and memory utilization all remain below 20% for 7 consecutive days. On a 24 GB ARM instance running `Ollama` with a loaded model kept resident (`OLLAMA_KEEP_ALIVE=-1`) plus Black Apex OS's built-in 4-minute `/healthz` keep-alive cron, memory utilization stays well above 20%, preventing idle reclamation without artificial CPU burn.
2. **GCP Free `e2-micro` (1 GB RAM, 30 GB disk)**:
   - Suitable for running the Black Apex OS web server in remote-only mode (`LOCAL_DOWN`) with Caddy or Cloudflare Tunnel; cannot host a local LLM in RAM.
3. **Home Machine + Cloudflare Tunnel (`deploy/cloudflared.service`)**:
   - Uses your existing desktop GPU/CPU for Rung 0 local inference with automatic TLS and zero open router ports.
4. **Demo-Only Free PaaS Hosts (Render / Koyeb / Railway Trial)**:
   - Documented as **ephemeral demo targets only** due to container spin-down and non-persistent disk without an external volume.

