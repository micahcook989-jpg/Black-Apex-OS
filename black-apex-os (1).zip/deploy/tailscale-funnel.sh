#!/usr/bin/env bash
# Black Apex OS — Section 26.2 Path 2: Tailscale Funnel Exposure
set -euo pipefail

PORT="${PORT:-3000}"
MODE="${1:-funnel}" # "funnel" for public HTTPS or "serve" for private tailnet HTTPS

echo "[Tailscale] Resetting existing serve/funnel rules..."
tailscale serve reset || true

if [ "$MODE" = "private" ]; then
  echo "[Tailscale] Enabling private tailnet HTTPS proxy to 127.0.0.1:${PORT}..."
  tailscale serve --bg --https=443 "http://127.0.0.1:${PORT}"
else
  echo "[Tailscale] Enabling public Tailscale Funnel over TLS 443 to 127.0.0.1:${PORT}..."
  tailscale funnel --bg --https=443 "http://127.0.0.1:${PORT}"
fi

tailscale funnel status
