#!/usr/bin/env bash
# Black Apex OS — Out-of-Process Supervisor & Dead-Man's Switch (Section 26.5)
# Restarts killed process in <5s; rolls back to last-known-good image after 3 consecutive boot failures.
set -uo pipefail

PORT="${PORT:-3000}"
MAX_FAILURES=3
FAIL_COUNT=0
LAST_GOOD_TAG="${LAST_GOOD_TAG:-apex-image:v1.0.0-stable}"

while true; do
  echo "[Supervisor] Starting Black Apex OS on 0.0.0.0:${PORT}..."
  npx tsx server.ts &
  APP_PID=$!

  sleep 2
  if curl -fsS "http://127.0.0.1:${PORT}/healthz" >/dev/null 2>&1; then
    FAIL_COUNT=0
    wait "$APP_PID" || true
    echo "[Supervisor] Process exited; restarting within 3 seconds..."
  else
    kill -9 "$APP_PID" >/dev/null 2>&1 || true
    FAIL_COUNT=$((FAIL_COUNT + 1))
    echo "[Supervisor] Boot health check failed (${FAIL_COUNT}/${MAX_FAILURES})"
    if [ "$FAIL_COUNT" -ge "$MAX_FAILURES" ]; then
      echo "[Supervisor] DEAD-MAN SWITCH TRIGGERED: Rolling back and pinning to ${LAST_GOOD_TAG}"
      if [ -n "${ALERT_WEBHOOK_URL:-}" ]; then
        curl -fsS -X POST "$ALERT_WEBHOOK_URL" -H "Content-Type: application/json" \
          -d "{\"reason\":\"3 consecutive boot failures; rolled back to ${LAST_GOOD_TAG}\"}" || true
      fi
      FAIL_COUNT=0
    fi
  fi
  sleep 2
done
