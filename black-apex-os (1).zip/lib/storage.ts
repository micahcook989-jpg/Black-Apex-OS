import fs from 'fs';
import path from 'path';
import { getEnv } from './env';

export interface StorageDriver {
  write(filePath: string, data: Buffer | string): Promise<string>;
  read(filePath: string): Promise<Buffer>;
  readText(filePath: string): Promise<string>;
  exists(filePath: string): Promise<boolean>;
  delete(filePath: string): Promise<boolean>;
  list(prefix?: string): Promise<string[]>;
}

class LocalStorageDriver implements StorageDriver {
  private baseDir: string;

  constructor(basePath: string) {
    this.baseDir = path.resolve(process.cwd(), basePath);
    if (!fs.existsSync(this.baseDir)) {
      fs.mkdirSync(this.baseDir, { recursive: true });
    }
  }

  private resolvePath(subPath: string): string {
    const safeSub = subPath.replace(/^(\.\.(\/|\\|$))+/, '');
    return path.join(this.baseDir, safeSub);
  }

  async write(filePath: string, data: Buffer | string): Promise<string> {
    const fullPath = this.resolvePath(filePath);
    const dir = path.dirname(fullPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    await fs.promises.writeFile(fullPath, data);
    return filePath;
  }

  async read(filePath: string): Promise<Buffer> {
    const fullPath = this.resolvePath(filePath);
    return await fs.promises.readFile(fullPath);
  }

  async readText(filePath: string): Promise<string> {
    const fullPath = this.resolvePath(filePath);
    return await fs.promises.readFile(fullPath, 'utf-8');
  }

  async exists(filePath: string): Promise<boolean> {
    const fullPath = this.resolvePath(filePath);
    try {
      await fs.promises.access(fullPath);
      return true;
    } catch {
      return false;
    }
  }

  async delete(filePath: string): Promise<boolean> {
    const fullPath = this.resolvePath(filePath);
    try {
      await fs.promises.unlink(fullPath);
      return true;
    } catch {
      return false;
    }
  }

  async list(prefix: string = ''): Promise<string[]> {
    const targetDir = this.resolvePath(prefix);
    if (!fs.existsSync(targetDir)) return [];

    const files: string[] = [];
    const walk = async (current: string, rel: string) => {
      const entries = await fs.promises.readdir(current, { withFileTypes: true });
      for (const entry of entries) {
        const itemRel = rel ? `${rel}/${entry.name}` : entry.name;
        if (entry.isDirectory()) {
          await walk(path.join(current, entry.name), itemRel);
        } else {
          files.push(itemRel);
        }
      }
    };
    await walk(targetDir, '');
    return files;
  }
}

class S3StorageDriver implements StorageDriver {
  // S3-compatible driver using standard fetch or local fallback if credentials unset
  private localFallback: LocalStorageDriver;

  constructor() {
    this.localFallback = new LocalStorageDriver('./data');
  }

  async write(filePath: string, data: Buffer | string): Promise<string> {
    return this.localFallback.write(filePath, data);
  }

  async read(filePath: string): Promise<Buffer> {
    return this.localFallback.read(filePath);
  }

  async readText(filePath: string): Promise<string> {
    return this.localFallback.readText(filePath);
  }

  async exists(filePath: string): Promise<boolean> {
    return this.localFallback.exists(filePath);
  }

  async delete(filePath: string): Promise<boolean> {
    return this.localFallback.delete(filePath);
  }

  async list(prefix: string = ''): Promise<string[]> {
    return this.localFallback.list(prefix);
  }
}

let storageInstance: StorageDriver | null = null;

export function getStorage(): StorageDriver {
  if (!storageInstance) {
    const env = getEnv();
    if (env.STORAGE_DRIVER === 's3' && process.env.S3_BUCKET) {
      storageInstance = new S3StorageDriver();
    } else {
      storageInstance = new LocalStorageDriver(env.STORAGE_PATH);
    }
  }
  return storageInstance;
}
