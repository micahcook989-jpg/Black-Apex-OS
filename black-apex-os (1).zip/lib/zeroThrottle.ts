/**
 * Black Apex OS — Section 24.16 Zero-Throttle Layer
 *
 * Goal: the user never experiences a queue. Four mechanisms:
 * 1. Key Pool: Multiple keys per provider, round-robin over health-scored keys,
 *    per-key token bucket, per-key 429 cooldown with exponential backoff and jitter.
 * 2. Request Racing: If time-to-first-token (TTFT) exceeds gear SLA
 *    (CHAT 1200ms, TASK 1500ms, HEAVY 2000ms, DEEP 3000ms) or primary key hits 429/503,
 *    fire the same request to the next healthy key or provider. First to emit a token wins,
 *    rest are cancelled. Cap 3 in flight per turn.
 * 3. Priority Scheduler: Local queue with two classes ('interactive' and 'background').
 *    Interactive always preempts. Hard concurrency cap per key so background jobs never delay a live turn.
 * 4. Hot Standby: When a local tier is configured, stays warm. If every remote key degrades,
 *    drops to local with no visible interruption and re-races remotes on next turn.
 */

import { GearLevel } from './gearing';

export const GEAR_TTFT_SLA_MS: Record<GearLevel, number> = {
  CHAT: 1200,
  TASK: 1500,
  HEAVY: 2000,
  DEEP: 3000,
};

export interface KeyState {
  id: string;
  provider: 'gemini' | 'groq' | 'openrouter' | 'local';
  apiKey: string;
  healthScore: number; // 0 to 100
  tokensRemaining: number;
  cooldownUntil: number;
  consecutive429s: number;
  inFlightInteractive: number;
  inFlightBackground: number;
  maxConcurrency: number;
}

export interface QueuedJob<T> {
  id: string;
  priority: 'interactive' | 'background';
  execute: () => Promise<T>;
  resolve: (val: T) => void;
  reject: (err: any) => void;
  enqueuedAt: number;
}

export class ZeroThrottleManager {
  private keys: Map<string, KeyState[]> = new Map();
  private roundRobinIndex: Map<string, number> = new Map();
  private hourlyLatencyMs: Record<string, Record<number, number[]>> = {};
  private hotStandbyWarm: boolean = false;
  private interactiveQueue: QueuedJob<any>[] = [];
  private backgroundQueue: QueuedJob<any>[] = [];
  private activeInteractiveCount = 0;
  private activeBackgroundCount = 0;
  private maxBackgroundConcurrent = 1;

  constructor() {
    this.keys.set('gemini', []);
    this.keys.set('groq', []);
    this.keys.set('openrouter', []);
    this.keys.set('local', []);
  }

  public addKey(
    provider: 'gemini' | 'groq' | 'openrouter' | 'local',
    apiKey: string,
    maxConcurrency: number = 4
  ): KeyState {
    const list = this.keys.get(provider) || [];
    const existing = list.find((k) => k.apiKey === apiKey);
    if (existing) return existing;

    const state: KeyState = {
      id: `${provider}-key-${list.length + 1}`,
      provider,
      apiKey,
      healthScore: 100,
      tokensRemaining: 100,
      cooldownUntil: 0,
      consecutive429s: 0,
      inFlightInteractive: 0,
      inFlightBackground: 0,
      maxConcurrency,
    };
    list.push(state);
    this.keys.set(provider, list);
    return state;
  }

  public getHealthyKeys(provider: 'gemini' | 'groq' | 'openrouter' | 'local'): KeyState[] {
    const now = Date.now();
    const list = this.keys.get(provider) || [];
    return list
      .filter((k) => k.cooldownUntil <= now && k.tokensRemaining > 0 && k.healthScore > 10)
      .sort((a, b) => b.healthScore - a.healthScore);
  }

  /**
   * Selects the next healthy key via round-robin over health-scored keys
   */
  public acquireKey(
    provider: 'gemini' | 'groq' | 'openrouter' | 'local',
    priority: 'interactive' | 'background' = 'interactive'
  ): KeyState | null {
    const healthy = this.getHealthyKeys(provider);
    if (healthy.length === 0) return null;

    const idx = this.roundRobinIndex.get(provider) || 0;
    for (let offset = 0; offset < healthy.length; offset++) {
      const candidate = healthy[(idx + offset) % healthy.length];
      const totalInFlight = candidate.inFlightInteractive + candidate.inFlightBackground;
      if (priority === 'interactive' || totalInFlight < candidate.maxConcurrency - 1) {
        this.roundRobinIndex.set(provider, (idx + offset + 1) % healthy.length);
        if (priority === 'interactive') {
          candidate.inFlightInteractive++;
        } else {
          candidate.inFlightBackground++;
        }
        return candidate;
      }
    }
    return healthy[0];
  }

  public releaseKey(key: KeyState, priority: 'interactive' | 'background' = 'interactive') {
    if (priority === 'interactive') {
      key.inFlightInteractive = Math.max(0, key.inFlightInteractive - 1);
    } else {
      key.inFlightBackground = Math.max(0, key.inFlightBackground - 1);
    }
  }

  /**
   * Marks a key degraded on 429/503 or slow TTFT with exponential backoff and jitter
   */
  public reportThrottle(key: KeyState, statusCode: number = 429, retryAfterMs?: number) {
    key.consecutive429s += 1;
    key.healthScore = Math.max(5, key.healthScore - 35);
    const baseBackoff = retryAfterMs ?? Math.min(30000, 1000 * Math.pow(2, key.consecutive429s));
    const jitter = Math.floor(Math.random() * 250);
    key.cooldownUntil = Date.now() + baseBackoff + jitter;
  }

  public reportSuccess(key: KeyState, ttftMs: number) {
    key.consecutive429s = 0;
    key.healthScore = Math.min(100, key.healthScore + 10);
    this.recordLatency(key.provider, ttftMs);
  }

  public recordLatency(provider: string, ttftMs: number, hour: number = new Date().getHours()) {
    if (!this.hourlyLatencyMs[provider]) {
      this.hourlyLatencyMs[provider] = {};
    }
    if (!this.hourlyLatencyMs[provider][hour]) {
      this.hourlyLatencyMs[provider][hour] = [];
    }
    this.hourlyLatencyMs[provider][hour].push(ttftMs);
  }

  public setHotStandbyWarm(warm: boolean) {
    this.hotStandbyWarm = warm;
  }

  public isHotStandbyWarm(): boolean {
    return this.hotStandbyWarm;
  }

  /**
   * 24.16 Request Racing:
   * Races up to 3 candidates (keys or providers). If primary exceeds gear TTFT SLA
   * or throws 429/503, immediately fires the next candidate. First to emit a token wins,
   * and losers are cancelled via AbortSignal.
   */
  public async raceStreamCandidates<T>(
    candidates: ((signal: AbortSignal) => Promise<T>)[],
    gear: GearLevel = 'CHAT',
    customSlaMs?: number
  ): Promise<{ winnerIndex: number; result: T; racedCount: number }> {
    const slaMs = customSlaMs ?? GEAR_TTFT_SLA_MS[gear] ?? 1500;
    const capped = candidates.slice(0, 3); // Cap 3 in flight per turn
    if (capped.length === 0) {
      throw new Error('No candidates provided to raceStreamCandidates');
    }

    const controllers = capped.map(() => new AbortController());
    let settled = false;
    let racedCount = 0;

    return new Promise<{ winnerIndex: number; result: T; racedCount: number }>((resolve, reject) => {
      let failures = 0;
      let lastError: any = null;
      const timers: NodeJS.Timeout[] = [];

      const cleanup = (winningIdx: number) => {
        for (const t of timers) clearTimeout(t);
        controllers.forEach((ctrl, idx) => {
          if (idx !== winningIdx) {
            ctrl.abort();
          }
        });
      };

      const launchCandidate = (index: number) => {
        if (settled || index >= capped.length) return;
        racedCount++;

        // Schedule next candidate if SLA expires before this candidate resolves
        if (index + 1 < capped.length) {
          const timer = setTimeout(() => {
            if (!settled) {
              launchCandidate(index + 1);
            }
          }, slaMs);
          timers.push(timer);
        }

        capped[index](controllers[index].signal)
          .then((res) => {
            if (settled) return;
            settled = true;
            cleanup(index);
            resolve({ winnerIndex: index, result: res, racedCount });
          })
          .catch((err) => {
            if (settled) return;
            failures++;
            lastError = err;
            // Immediately trigger next candidate on 429/error without waiting for SLA timer
            if (index + 1 < capped.length && racedCount <= index + 1) {
              launchCandidate(index + 1);
            }
            if (failures >= capped.length) {
              settled = true;
              cleanup(-1);
              reject(lastError || new Error('All raced candidates failed'));
            }
          });
      };

      launchCandidate(0);
    });
  }

  /**
   * 24.16 Priority Scheduler:
   * Interactive jobs always preempt background jobs. Background jobs never delay a live turn.
   */
  public schedule<T>(priority: 'interactive' | 'background', execute: () => Promise<T>): Promise<T> {
    if (priority === 'interactive') {
      // Interactive runs immediately, preempting background queue
      this.activeInteractiveCount++;
      return execute().finally(() => {
        this.activeInteractiveCount = Math.max(0, this.activeInteractiveCount - 1);
        this.drainQueues();
      });
    }

    return new Promise<T>((resolve, reject) => {
      this.backgroundQueue.push({
        id: `bg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        priority: 'background',
        execute,
        resolve,
        reject,
        enqueuedAt: Date.now(),
      });
      this.drainQueues();
    });
  }

  private drainQueues() {
    // Interactive jobs always drain first
    while (this.interactiveQueue.length > 0) {
      const job = this.interactiveQueue.shift()!;
      this.activeInteractiveCount++;
      job
        .execute()
        .then(job.resolve)
        .catch(job.reject)
        .finally(() => {
          this.activeInteractiveCount = Math.max(0, this.activeInteractiveCount - 1);
          this.drainQueues();
        });
    }

    // Background jobs only run when no interactive turn is being starved
    while (
      this.backgroundQueue.length > 0 &&
      this.activeInteractiveCount === 0 &&
      this.activeBackgroundCount < this.maxBackgroundConcurrent
    ) {
      const job = this.backgroundQueue.shift()!;
      this.activeBackgroundCount++;
      job
        .execute()
        .then(job.resolve)
        .catch(job.reject)
        .finally(() => {
          this.activeBackgroundCount = Math.max(0, this.activeBackgroundCount - 1);
          this.drainQueues();
        });
    }
  }
}

let zeroThrottleInstance: ZeroThrottleManager | null = null;

export function getZeroThrottleManager(): ZeroThrottleManager {
  if (!zeroThrottleInstance) {
    zeroThrottleInstance = new ZeroThrottleManager();
  }
  return zeroThrottleInstance;
}
