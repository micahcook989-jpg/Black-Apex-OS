import fs from 'fs';
import path from 'path';
import { getEnv } from './env';

export interface WatchTask {
  id: string;
  name: string;
  url: string;
  targetDescription: string;
  intervalMinutes: number;
  lastCheckedAt?: string;
  lastSnapshot?: string;
  lastDiff?: string;
  status: 'active' | 'paused' | 'triggered';
  changeCount: number;
  createdAt: string;
}

class AutomationManager {
  private filePath: string;
  private tasks: Record<string, WatchTask> = {};
  private intervalTimer: NodeJS.Timeout | null = null;

  constructor() {
    const env = getEnv();
    const dataDir = path.resolve(process.cwd(), env.STORAGE_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    this.filePath = path.join(dataDir, 'automations.json');
    this.load();
    this.startWorker();
  }

  private load() {
    try {
      if (fs.existsSync(this.filePath)) {
        this.tasks = JSON.parse(fs.readFileSync(this.filePath, 'utf-8'));
      }
    } catch {
      this.tasks = {};
    }
  }

  private persist() {
    try {
      fs.writeFileSync(this.filePath, JSON.stringify(this.tasks, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to save automations:', err);
    }
  }

  public createTask(name: string, url: string, targetDescription: string, intervalMinutes: number = 60): WatchTask {
    const task: WatchTask = {
      id: `watch-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      name,
      url,
      targetDescription,
      intervalMinutes: Math.max(5, intervalMinutes),
      status: 'active',
      changeCount: 0,
      createdAt: new Date().toISOString(),
    };
    this.tasks[task.id] = task;
    this.persist();
    return task;
  }

  public listTasks(): WatchTask[] {
    return Object.values(this.tasks);
  }

  public toggleTask(id: string): WatchTask | null {
    const task = this.tasks[id];
    if (!task) return null;
    task.status = task.status === 'active' ? 'paused' : 'active';
    this.persist();
    return task;
  }

  public deleteTask(id: string): boolean {
    if (this.tasks[id]) {
      delete this.tasks[id];
      this.persist();
      return true;
    }
    return false;
  }

  public async checkTask(id: string): Promise<{ changed: boolean; diff?: string }> {
    const task = this.tasks[id];
    if (!task) return { changed: false };

    try {
      const res = await fetch(task.url, {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) BlackApexOS/1.0' },
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const text = await res.text();
      // Clean simple text
      const clean = text.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
                        .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '')
                        .replace(/<[^>]+>/g, ' ')
                        .replace(/\s+/g, ' ')
                        .trim()
                        .slice(0, 50000);

      const now = new Date().toISOString();
      task.lastCheckedAt = now;

      if (!task.lastSnapshot) {
        task.lastSnapshot = clean;
        this.persist();
        return { changed: false };
      }

      if (task.lastSnapshot !== clean) {
        // Simple line diff snippet
        const diff = `Snapshot changed at ${now}. Length: ${task.lastSnapshot.length} -> ${clean.length} chars.`;
        task.lastDiff = diff;
        task.lastSnapshot = clean;
        task.changeCount++;
        task.status = 'triggered';
        this.persist();
        return { changed: true, diff };
      }

      this.persist();
      return { changed: false };
    } catch (err: any) {
      task.lastCheckedAt = new Date().toISOString();
      this.persist();
      return { changed: false };
    }
  }

  private startWorker() {
    if (this.intervalTimer) clearInterval(this.intervalTimer);
    // Poll every 5 minutes in background
    this.intervalTimer = setInterval(() => {
      const activeTasks = Object.values(this.tasks).filter((t) => t.status === 'active');
      for (const t of activeTasks) {
        const last = t.lastCheckedAt ? new Date(t.lastCheckedAt).getTime() : 0;
        const elapsed = (Date.now() - last) / (60 * 1000);
        if (elapsed >= t.intervalMinutes) {
          this.checkTask(t.id).catch(() => {});
        }
      }
    }, 5 * 60 * 1000);
  }
}

let managerInstance: AutomationManager | null = null;

export function getAutomationManager(): AutomationManager {
  if (!managerInstance) {
    managerInstance = new AutomationManager();
  }
  return managerInstance;
}
