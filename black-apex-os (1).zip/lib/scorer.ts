/**
 * Black Apex OS — Section 17.2 Best-of-N with a Hedge Scorer
 *
 * At rung 0 in APEX and BRUTAL, samples N candidates in parallel, scores each,
 * keeps the winner, and stores losers in receipts only.
 *
 * Scorer metrics:
 * - hedge_density: count of hedge markers per 100 tokens (lower is better)
 * - specificity: named tools, versions, files, numbers, offsets (higher is better)
 * - commitment: does it pick an option when options exist (higher is better)
 * - code_presence: runnable blocks versus prose description (higher is better)
 * - truncation: does it stop mid-thought (penalty if true)
 */

import { detectTier1 } from './detector';

export interface CandidateScore {
  candidateIndex: number;
  hedge_density: number; // 0 to 10 (lower is better)
  specificity: number;   // 0 to 10 (higher is better)
  commitment: number;    // 0 to 10 (higher is better)
  code_presence: number; // 0 to 10 (higher is better)
  truncation: boolean;   // boolean
  compositeScore: number;// 0 to 100 (higher is better)
  textSnippet: string;
}

export function scoreCandidateDeterministic(text: string, index: number = 0): CandidateScore {
  if (!text || text.trim().length === 0) {
    return {
      candidateIndex: index,
      hedge_density: 10,
      specificity: 0,
      commitment: 0,
      code_presence: 0,
      truncation: true,
      compositeScore: 0,
      textSnippet: '',
    };
  }

  const detection = detectTier1(text);
  const words = text.trim().split(/\s+/).length;
  const tokenEst = Math.max(1, Math.round(words * 1.3));

  // 1. Hedge density (count per 100 tokens)
  const hedgeCount = detection.hedged ? 2 : 0;
  const rawHedgeDensity = (hedgeCount / tokenEst) * 100;
  const hedge_density = Math.min(10, Math.round(rawHedgeDensity * 10) / 10);

  // 2. Specificity: count numbers, file paths, versions, code identifiers
  let specificityCount = 0;
  if (/\b\d+\b/.test(text)) specificityCount += 2;
  if (/v?\d+\.\d+(\.\d+)?/.test(text)) specificityCount += 3;
  if (/[a-zA-Z0-9_-]+\.(ts|js|json|py|rs|go|html|css|yaml|sh)/i.test(text)) specificityCount += 3;
  if (/\b(function|const|let|import|export|class|def|return)\b/.test(text)) specificityCount += 2;
  const specificity = Math.min(10, specificityCount);

  // 3. Commitment: checks for decisive language vs vacillating options
  let commitment = 7;
  if (/\b(I recommend|Use|Run|Execute|Implement|Choose|The solution is)\b/i.test(text)) {
    commitment += 3;
  }
  if (/\b(it depends|several options|you could either|on one hand|alternatively)\b/i.test(text)) {
    commitment -= 4;
  }
  commitment = Math.max(0, Math.min(10, commitment));

  // 4. Code presence
  const code_presence = text.includes('```') ? 10 : 3;

  // 5. Truncation: does it stop mid sentence or unclosed delimiter
  const lastChar = text.trim().slice(-1);
  const truncation = !['.', '!', '?', '`', '}', ')', '>', '"', "'"].includes(lastChar);

  // Composite Score: hedge_density and commitment are dominant
  // Score formula: (10 - hedge_density) * 4 + commitment * 3 + specificity * 2 + code_presence * 1 - (truncation ? 20 : 0)
  let compositeScore = (10 - hedge_density) * 4 + commitment * 3 + specificity * 2 + code_presence * 1;
  if (truncation) compositeScore -= 20;
  compositeScore = Math.max(0, Math.min(100, Math.round(compositeScore)));

  return {
    candidateIndex: index,
    hedge_density,
    specificity,
    commitment,
    code_presence,
    truncation,
    compositeScore,
    textSnippet: text.slice(0, 140),
  };
}

/**
 * Picks the winning candidate among N drafts using the weighted scorer
 */
export function selectBestOfN(candidates: string[]): {
  winnerIndex: number;
  winnerText: string;
  winner?: string;
  scores: CandidateScore[];
} {
  if (candidates.length === 0) {
    return { winnerIndex: 0, winnerText: '', scores: [] };
  }
  if (candidates.length === 1) {
    const singleScore = scoreCandidateDeterministic(candidates[0], 0);
    return { winnerIndex: 0, winnerText: candidates[0], scores: [singleScore] };
  }

  const scores = candidates.map((c, i) => scoreCandidateDeterministic(c, i));

  // Sort descending by compositeScore; tiebreak on specificity
  scores.sort((a, b) => {
    if (b.compositeScore !== a.compositeScore) {
      return b.compositeScore - a.compositeScore;
    }
    return b.specificity - a.specificity;
  });

  const winner = scores[0];
  return {
    winnerIndex: winner.candidateIndex,
    winnerText: candidates[winner.candidateIndex],
    winner: candidates[winner.candidateIndex],
    scores,
  };
}
