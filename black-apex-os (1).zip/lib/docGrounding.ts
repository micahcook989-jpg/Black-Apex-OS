/**
 * Black Apex OS — Section 17.4 Doc Grounding
 *
 * Before answering about a library, framework, SDK, or CLI:
 * - Resolves version from uploaded lockfile or registry.
 * - Injects pinned version context block with canonical doc URL.
 * - Cites doc URL in the answer, killing the "it depends on your version" hedge.
 */

import { defaultFreeCacheHierarchy, defaultRequestCoalescer } from './freeMode';

export interface GroundedDoc {
  packageName: string;
  version: string;
  docUrl: string;
  contextBlock: string;
}

// Common registry lookup cache
const REGISTRY_CACHE = new Map<string, { version: string; url: string }>();

// Popular ecosystem packages regex
const KNOWN_PACKAGES = [
  'react',
  'next',
  'vue',
  'vite',
  'express',
  'tailwindcss',
  'typescript',
  'zod',
  'playwright',
  'prisma',
  'drizzle-orm',
  'fastapi',
  'flask',
  'django',
  'tokio',
  'serde',
  'gin',
];

export function extractLockfileVersions(lockfileContent: string, fileName: string): Record<string, string> {
  const versions: Record<string, string> = {};

  try {
    if (fileName.includes('package-lock.json')) {
      const parsed = JSON.parse(lockfileContent);
      if (parsed.packages) {
        for (const [key, val] of Object.entries<any>(parsed.packages)) {
          const name = key.replace(/^node_modules\//, '');
          if (val.version) versions[name] = val.version;
        }
      } else if (parsed.dependencies) {
        for (const [name, val] of Object.entries<any>(parsed.dependencies)) {
          if (val.version) versions[name] = val.version;
        }
      }
    } else if (fileName.includes('requirements.txt')) {
      const lines = lockfileContent.split('\n');
      for (const line of lines) {
        const match = line.match(/^([a-zA-Z0-9_-]+)==([a-zA-Z0-9._-]+)/);
        if (match) versions[match[1].toLowerCase()] = match[2];
      }
    } else if (fileName.includes('Cargo.lock')) {
      const blocks = lockfileContent.split('[[package]]');
      for (const b of blocks) {
        const nameMatch = b.match(/name\s*=\s*"([^"]+)"/);
        const verMatch = b.match(/version\s*=\s*"([^"]+)"/);
        if (nameMatch && verMatch) versions[nameMatch[1]] = verMatch[1];
      }
    }
  } catch {
    // Ignore parse errors on malformed lockfiles
  }

  return versions;
}

/**
 * Checks query for library mentions and produces a doc grounding context block.
 * PATCH 01 (P2): Only runs when a lockfile is present OR the user names a version.
 */
export async function resolveDocGrounding(
  userQuery: string,
  lockfileVersions?: Record<string, string>
): Promise<GroundedDoc | null> {
  const hasLockfile =
    Boolean(lockfileVersions) && Object.keys(lockfileVersions || {}).length > 0;
  // Explicit version named by user: e.g. "@18", "v19.0", "version 5", "react 19", "4.19.2"
  const namedVersionMatch = userQuery.match(
    /(?:@v?(\d+(?:\.\d+){0,2})|\b(?:v|version\s+)(\d+(?:\.\d+){0,2})\b|\b(?:react|next|vue|vite|express|tailwindcss|typescript|zod|playwright|prisma|drizzle-orm|fastapi|flask|django|tokio|serde|gin)\s+v?(\d+(?:\.\d+){0,2})\b|\b(\d+\.\d+(?:\.\d+)?)\b)/i
  );

  if (!hasLockfile && !namedVersionMatch) {
    return null;
  }

  const explicitVersion =
    namedVersionMatch?.[1] ||
    namedVersionMatch?.[2] ||
    namedVersionMatch?.[3] ||
    namedVersionMatch?.[4];

  const lower = userQuery.toLowerCase();

  for (const pkg of KNOWN_PACKAGES) {
    const regex = new RegExp(`\\b${pkg}\\b`, 'i');
    if (regex.test(lower)) {
      let version = lockfileVersions?.[pkg] || explicitVersion;
      let docUrl = `https://www.npmjs.com/package/${pkg}`;

      const preCacheKey = `${pkg}@${version || 'latest'}`;
      const cachedDoc = defaultFreeCacheHierarchy.getDoc(preCacheKey);
      if (cachedDoc) {
        return cachedDoc;
      }

      if (!version) {
        if (REGISTRY_CACHE.has(pkg)) {
          const cached = REGISTRY_CACHE.get(pkg)!;
          version = cached.version;
          docUrl = cached.url;
        } else {
          try {
            const { value } = await defaultRequestCoalescer.execute(`doc:${pkg}`, async () => {
              const res = await fetch(`https://registry.npmjs.org/${pkg}/latest`, {
                signal: AbortSignal.timeout(3000),
              });
              if (res.ok) {
                const data: any = await res.json();
                return {
                  version: (data.version || 'stable') as string,
                  url: (data.homepage || `https://www.npmjs.com/package/${pkg}`) as string,
                };
              }
              return { version: 'current stable', url: `https://www.npmjs.com/package/${pkg}` };
            });
            version = value.version;
            docUrl = value.url;
            REGISTRY_CACHE.set(pkg, { version: value.version, url: value.url });
          } catch {
            version = 'current stable';
          }
        }
      }

      version = version || 'current stable';

      const grounded: GroundedDoc = {
        packageName: pkg,
        version,
        docUrl,
        contextBlock: `[DOC GROUNDING: ${pkg}@${version}]\nDocumentation source: ${docUrl}\nAPI rule: Pinned to version ${version}. Do not use deprecated or superseded signatures. Cite doc URL: ${docUrl}`,
      };
      defaultFreeCacheHierarchy.setDoc(`${pkg}@${version}`, grounded);
      defaultFreeCacheHierarchy.setDoc(preCacheKey, grounded);
      return grounded;
    }
  }

  return null;
}

export function parseLockfileVersions(fileName: string, lockfileContent: string): Record<string, string> {
  return extractLockfileVersions(lockfileContent, fileName);
}

export function generateDocContextBlock(
  packageName: string,
  version: string,
  docUrl: string,
  signatures?: string
): string {
  return `[PINNED_DOC_CONTEXT: ${packageName}@${version}]\nCanonical URL: ${docUrl}\nVerified signatures:\n${signatures || 'Latest stable API reference'}\nRule: Cite ${docUrl} and do not state any unverified signatures.`;
}
