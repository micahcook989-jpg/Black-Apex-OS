import { TOOL_DEFINITIONS, executeTool } from './tools';

export interface McpJsonRpcRequest {
  jsonrpc: '2.0';
  id?: string | number;
  method: string;
  params?: any;
}

export interface McpJsonRpcResponse {
  jsonrpc: '2.0';
  id?: string | number;
  result?: any;
  error?: {
    code: number;
    message: string;
    data?: any;
  };
}

/**
 * Handles incoming JSON-RPC 2.0 MCP requests
 * Section 17.13: MCP Server Export (/mcp)
 */
export async function handleMcpRequest(
  req: McpJsonRpcRequest,
  bearerToken?: string,
  expectedToken?: string
): Promise<McpJsonRpcResponse> {
  const { id = 1, method, params } = req;

  // Validate bearer token if expectedToken is configured
  if (expectedToken && expectedToken.trim().length > 0) {
    if (!bearerToken || bearerToken !== expectedToken) {
      return {
        jsonrpc: '2.0',
        id,
        error: {
          code: -32001,
          message: 'Unauthorized: Invalid or missing MCP bearer token',
        },
      };
    }
  }

  try {
    switch (method) {
      case 'initialize': {
        return {
          jsonrpc: '2.0',
          id,
          result: {
            protocolVersion: '2024-11-05',
            capabilities: {
              tools: {},
            },
            serverInfo: {
              name: 'black-apex-os',
              version: '1.0.0',
            },
          },
        };
      }

      case 'tools/list': {
        const tools = [
          {
            name: 'run_code',
            description: 'Execute Python, JavaScript, TypeScript, or Bash code in a sandboxed session.',
            inputSchema: {
              type: 'object',
              properties: {
                language: { type: 'string', enum: ['python', 'javascript', 'typescript', 'bash'] },
                code: { type: 'string', description: 'Code to execute' },
              },
              required: ['language', 'code'],
            },
          },
          {
            name: 'web_search',
            description: 'Search the live web for verified documentation, APIs, and articles.',
            inputSchema: {
              type: 'object',
              properties: {
                query: { type: 'string', description: 'Search keywords or query' },
                limit: { type: 'number', default: 5 },
              },
              required: ['query'],
            },
          },
          {
            name: 'fetch_url',
            description: 'Scrape and extract clean markdown content from any target URL.',
            inputSchema: {
              type: 'object',
              properties: {
                url: { type: 'string', format: 'uri', description: 'URL to retrieve' },
              },
              required: ['url'],
            },
          },
          {
            name: 'read_file',
            description: 'Read contents of local files inside the workspace.',
            inputSchema: {
              type: 'object',
              properties: {
                filePath: { type: 'string', description: 'Relative path of file to read' },
              },
              required: ['filePath'],
            },
          },
          {
            name: 'image_gen',
            description: 'Generate high-resolution visual assets or illustrations.',
            inputSchema: {
              type: 'object',
              properties: {
                prompt: { type: 'string', description: 'Visual description of asset' },
                aspectRatio: { type: 'string', enum: ['1:1', '16:9', '9:16', '4:3', '3:2'], default: '1:1' },
              },
              required: ['prompt'],
            },
          },
          {
            name: 'memory',
            description: 'Query or store persistent operator facts and project constraints.',
            inputSchema: {
              type: 'object',
              properties: {
                action: { type: 'string', enum: ['read', 'write'], default: 'read' },
                fact: { type: 'string', description: 'Fact to persist if writing' },
                query: { type: 'string', description: 'Search term if reading' },
              },
            },
          },
        ];

        return {
          jsonrpc: '2.0',
          id,
          result: { tools },
        };
      }

      case 'tools/call': {
        const toolName = params?.name;
        const toolArgs = params?.arguments || {};

        if (!toolName) {
          return {
            jsonrpc: '2.0',
            id,
            error: { code: -32602, message: 'Missing tool name' },
          };
        }

        // Map memory tool
        let mappedTool = toolName;
        let mappedArgs = { ...toolArgs };
        if (toolName === 'memory') {
          if (toolArgs.action === 'write') {
            mappedTool = 'memory_write';
            mappedArgs = { fact: toolArgs.fact, category: 'project' };
          } else {
            mappedTool = 'memory_read';
            mappedArgs = { query: toolArgs.query || '' };
          }
        }

        const result = await executeTool(mappedTool, mappedArgs, { conversationId: 'mcp' });

        return {
          jsonrpc: '2.0',
          id,
          result: {
            content: [
              {
                type: 'text',
                text: typeof result.result === 'string' ? result.result : JSON.stringify(result.result || result, null, 2),
              },
            ],
            isError: !result.success,
          },
        };
      }

      default:
        return {
          jsonrpc: '2.0',
          id,
          error: {
            code: -32601,
            message: `Method not found: ${method}`,
          },
        };
    }
  } catch (err: any) {
    return {
      jsonrpc: '2.0',
      id,
      error: {
        code: -32603,
        message: err.message || 'Internal MCP server error',
      },
    };
  }
}
