/**
 * Black Apex OS — Addendum Section 22: Gearing and Casual Use
 *
 * Implements the two decoupled axes:
 * 1. REGISTER (how it talks): inferred from user's own writing (CASUAL vs FORMAL).
 * 2. GEAR (how hard it works): CHAT, TASK, or HEAVY inferred per turn from substance.
 *
 * Includes:
 * - 22.1 Register & Gear decoupling
 * - 22.2 Gear levels (CHAT, TASK, HEAVY)
 * - 22.3 Deterministic + Groq 4-token Gear Classifier
 * - 22.4 Hard ceiling rule & silent 2-trip ladder upgrade (CHAT -> TASK -> HEAVY)
 * - 22.5 Decay (2 CHAT turns decays HEAVY -> CHAT; 4 CHAT turns resets history weight)
 * - 22.6 Explicit single-turn overrides & slash command floors
 * - 22.7 Conversational floor detector (greetings, acks, thanks, "lol", emoji-only)
 */

import { getEnv } from './env';

export type GearLevel = 'CHAT' | 'TASK' | 'HEAVY' | 'DEEP';
export type RegisterTone = 'CASUAL' | 'FORMAL' | 'NEUTRAL';

export interface ThreadGearState {
  conversationId: string;
  currentGear: GearLevel;
  lastTurnGear: GearLevel;
  consecutiveChatTurns: number;
  priorHedgeCount: number;
  topicAttempts: number;
  hasOpenArtifact: boolean;
}

export interface GearClassificationInput {
  prompt: string;
  attachmentCount?: number;
  attachmentNames?: string[];
  hasOpenArtifact?: boolean;
  priorHedgeInThread?: boolean;
  topicAttempts?: number;
  previousTurnGear?: GearLevel;
  consecutiveChatTurns?: number;
}

export interface GearGenerationParams {
  gear: GearLevel;
  temperature: number;
  topP: number;
  maxOutputTokens: number;
  maxCalls: number;
  bestOfN: number;
  enableSynthesis: boolean;
  enablePlanPrecommit: boolean;
  enableCritic: boolean;
  enableDocGrounding: boolean;
  showGlyphRow: boolean;
  startingRung: number;
  thinkingBudget: number;
}

export interface GearClassificationResult {
  gear: GearLevel;
  register: RegisterTone;
  isConversationalFloor: boolean;
  explicitOverride?: GearLevel;
  hideGlyphs: boolean;
  skipChips: boolean;
  startingRung: number;
  generationParams: GearGenerationParams;
}

/**
 * Computes generation parameters for a given GearLevel per Section 22.2:
 * - CHAT: 1 call, no best-of-N, no synthesis, no plan precommit, no critic, no glyph row, rung 0, concise token budget.
 * - TASK: 1–3 calls, plan precommit when output > ~200 words, glyph row active, rung 0, standard 4096 token budget.
 * - HEAVY: Full stack (best-of-N, synthesis, critic, doc grounding, deep crawl, artifacts), starts at rung 1, 8192 token budget.
 * - DEEP: Extended deliberative reasoning + full stack, starts at rung 1, 8192 token budget, thinkingBudget -1.
 */
export function getGenerationParamsForGear(
  gear: GearLevel,
  options?: {
    isConversationalFloor?: boolean;
    expectedWords?: number;
    expectedTokens?: number;
    quotaPercent?: number;
  }
): GearGenerationParams {
  if (options?.isConversationalFloor) {
    return {
      gear: 'CHAT',
      temperature: 0.65,
      topP: 0.9,
      maxOutputTokens: 256,
      maxCalls: 1,
      bestOfN: 1,
      enableSynthesis: false,
      enablePlanPrecommit: false,
      enableCritic: false,
      enableDocGrounding: false,
      showGlyphRow: false,
      startingRung: 0,
      thinkingBudget: 0,
    };
  }

  // P2: plan precommit -> TASK and above, and only above 400 expected tokens
  const expectedTokens =
    options?.expectedTokens ??
    (options?.expectedWords !== undefined ? Math.round(options.expectedWords * 1.35) : 300);

  // P2: best-of-N -> default 1, enabled only in HEAVY and above, and only above 50 percent quota
  const quotaPercent = options?.quotaPercent ?? 0;
  const allowBestOfN = quotaPercent > 50;

  switch (gear) {
    case 'CHAT':
      return {
        gear: 'CHAT',
        temperature: 0.7,
        topP: 0.92,
        maxOutputTokens: 1024,
        maxCalls: 1,
        bestOfN: 1,
        enableSynthesis: false,
        enablePlanPrecommit: false,
        enableCritic: false,
        enableDocGrounding: false,
        showGlyphRow: false,
        startingRung: 0,
        thinkingBudget: 0,
      };
    case 'TASK': {
      return {
        gear: 'TASK',
        temperature: 0.85,
        topP: 0.95,
        maxOutputTokens: 4096,
        maxCalls: 3,
        bestOfN: 1,
        enableSynthesis: false,
        enablePlanPrecommit: expectedTokens > 400,
        enableCritic: false,
        enableDocGrounding: true,
        showGlyphRow: true,
        startingRung: 0,
        thinkingBudget: 0,
      };
    }
    case 'HEAVY':
      return {
        gear: 'HEAVY',
        temperature: 0.9,
        topP: 0.95,
        maxOutputTokens: 8192,
        maxCalls: 6,
        bestOfN: allowBestOfN ? 3 : 1,
        enableSynthesis: true,
        enablePlanPrecommit: expectedTokens > 400,
        enableCritic: false,
        enableDocGrounding: true,
        showGlyphRow: true,
        startingRung: 0,
        thinkingBudget: -1,
      };
    case 'DEEP':
      return {
        gear: 'DEEP',
        temperature: 0.8,
        topP: 0.95,
        maxOutputTokens: 8192,
        maxCalls: 6,
        bestOfN: allowBestOfN ? 3 : 1,
        enableSynthesis: true,
        enablePlanPrecommit: expectedTokens > 400,
        enableCritic: true,
        enableDocGrounding: true,
        showGlyphRow: true,
        startingRung: 0,
        thinkingBudget: -1,
      };
  }
}

// In-memory store of thread gear states per conversation
const THREAD_GEAR_MAP = new Map<string, ThreadGearState>();

export function getThreadGearState(conversationId: string): ThreadGearState {
  if (!THREAD_GEAR_MAP.has(conversationId)) {
    THREAD_GEAR_MAP.set(conversationId, {
      conversationId,
      currentGear: 'CHAT', // 22.2: CHAT is default at every conversation start
      lastTurnGear: 'CHAT',
      consecutiveChatTurns: 0,
      priorHedgeCount: 0,
      topicAttempts: 0,
      hasOpenArtifact: false,
    });
  }
  return THREAD_GEAR_MAP.get(conversationId)!;
}

export function resetThreadGearState(conversationId: string): void {
  THREAD_GEAR_MAP.delete(conversationId);
}

/**
 * 22.1 Register inference from user's own writing style
 * Casual stays casual, formal stays formal, regardless of gear.
 */
export function inferRegister(prompt: string): RegisterTone {
  const trimmed = prompt.trim();
  if (!trimmed) return 'NEUTRAL';

  // Casual markers: slang, lowercase start, contractions, conversational shorthand
  const casualRegex =
    /\b(yo|lol|lmao|haha|hey|sup|thx|thanks|pls|plz|u|ur|wanna|gonna|gotta|kinda|sorta|nah|yep|yeah|cool|ok|okay|btw|imo|tbh|idk|wtf|bro|dude)\b/i;
  const startsLower = /^[a-z]/.test(trimmed) && !trimmed.startsWith('http') && !trimmed.startsWith('/');
  const hasContractions = /\b(can't|won't|don't|doesn't|isn't|aren't|what's|that's|it's|i'm|you're|we're|they're|let's)\b/i.test(
    trimmed
  );

  // Formal markers: academic/corporate phrasing, structured multi-sentence capitalization
  const formalRegex =
    /\b(furthermore|consequently|therefore|regarding|pursuant|accordance|specification|kindly|please provide|elaborate|comprehensive|implementation)\b/i;

  if (casualRegex.test(trimmed) || (startsLower && trimmed.split(/\s+/).length >= 3)) {
    return 'CASUAL';
  }
  if (formalRegex.test(trimmed)) {
    return 'FORMAL';
  }
  if (hasContractions) {
    return 'CASUAL';
  }
  return 'NEUTRAL';
}

/**
 * 22.7 Conversational Floor Detector
 * Greetings, acknowledgements, thanks, "ok", "cool", "lol", "makes sense",
 * single-word affirmations, and emoji-only messages.
 * Gets a direct reply of at most 2 sentences, no glyph, no tools, no ladder.
 */
export function detectConversationalFloor(prompt: string): boolean {
  const clean = prompt.trim();
  if (!clean) return false;

  // Emoji-only check (strips whitespace and standard unicode emoji ranges)
  const strippedEmoji = clean.replace(
    /[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{FE0F}\s]/gu,
    ''
  );
  if (strippedEmoji.length === 0 && clean.length > 0) {
    return true;
  }

  const normalized = clean.toLowerCase().replace(/[!?.~,]+$/g, '').trim();
  const words = normalized.split(/\s+/).filter(Boolean);

  if (words.length > 5) return false;

  const exactFloorPhrases = new Set([
    'hi',
    'hey',
    'hello',
    'yo',
    'sup',
    'what’s up',
    "what's up",
    'whats up',
    'howdy',
    'morning',
    'good morning',
    'good afternoon',
    'good evening',
    'thanks',
    'thank you',
    'thx',
    'ty',
    'tysm',
    'thanks a lot',
    'thank you so much',
    'appreciate it',
    'ok',
    'okay',
    'k',
    'kk',
    'cool',
    'nice',
    'sweet',
    'awesome',
    'great',
    'dope',
    'tight',
    'bet',
    'word',
    'gotcha',
    'got it',
    'makes sense',
    'that makes sense',
    'understood',
    'roger',
    'copy',
    'lol',
    'lmao',
    'rofl',
    'haha',
    'hehe',
    'yes',
    'yep',
    'yeah',
    'yup',
    'no',
    'nope',
    'nah',
    'sure',
    'alright',
    'sounds good',
    'all good',
    'np',
    'no problem',
    'bye',
    'cya',
    'peace',
  ]);

  return exactFloorPhrases.has(normalized);
}

/**
 * 24.15 Single-fact question detector (Never DEEP on a single-fact question, even if asked)
 */
export function isSingleFactTrivialQuestion(prompt: string): boolean {
  const cleaned = prompt
    .replace(/\/deep\b/gi, '')
    .replace(/\b(think hard|go deep)\b/gi, '')
    .trim()
    .toLowerCase();
  const tokens = cleaned.split(/\s+/).filter(Boolean);
  if (tokens.length > 14) return false;

  // Trivial arithmetic ("what's 2+2", "2 + 2", "what is 5*5")
  if (/^(?:what(?:'s|\s+is)\s+)?\d+\s*[+\-*/]\s*\d+\??$/i.test(cleaned)) {
    return true;
  }
  // Single-fact lookups ("what's the capital of Peru", "who invented the telephone")
  if (
    /^(?:what(?:'s|\s+is|\s+are)|who(?:'s|\s+is|\s+was)|when\s+(?:did|was|is)|where\s+is|capital\s+of)\b/i.test(
      cleaned
    ) &&
    !/\b(concurrency|deadlock|race condition|distributed|algorithm|complexity|prove|theorem|architecture|migration)\b/i.test(
      cleaned
    )
  ) {
    return true;
  }
  return false;
}

/**
 * 22.6 & 24.15 Explicit Overrides (adjusts the current turn and only the current turn)
 */
export function checkExplicitGearOverride(
  prompt: string,
  previousTurnGear: GearLevel = 'CHAT'
): { override: GearLevel | null; floor: GearLevel | null } {
  const lower = prompt.trim().toLowerCase();

  // 24.15: Never DEEP on a single-fact question, even if asked
  if (isSingleFactTrivialQuestion(prompt)) {
    return { override: 'CHAT', floor: null };
  }

  // Slash command floors: /deep floors at DEEP, /exploit and /userscript floor at HEAVY, /search and /code floor at TASK
  let floor: GearLevel | null = null;
  if (lower.startsWith('/deep')) {
    floor = 'DEEP';
  } else if (lower.startsWith('/exploit') || lower.startsWith('/userscript')) {
    floor = 'HEAVY';
  } else if (lower.startsWith('/search') || lower.startsWith('/code')) {
    floor = 'TASK';
  }

  // "keep going" inherits the previous turn's gear
  if (/^(?:keep going|continue|go on|keep writing)[.!?\s]*$/i.test(lower)) {
    return { override: previousTurnGear, floor };
  }

  // Force CHAT for this turn only: "quick", "short", "just answer", "tl;dr"
  if (/\b(tl;dr|tldr|just answer|keep it short|short answer)\b/i.test(lower) || /^(?:quick\b|short\b)/i.test(lower)) {
    return { override: 'CHAT', floor };
  }

  // 24.15: Explicit "think hard", "go deep", or "/deep" triggers DEEP
  if (/\b(think hard|go deep)\b/i.test(lower) || lower.startsWith('/deep')) {
    return { override: 'DEEP', floor: 'DEEP' };
  }

  // Force HEAVY for this turn only: "be thorough", "full version"
  if (/\b(be thorough|full version)\b/i.test(lower)) {
    return { override: 'HEAVY', floor };
  }

  return { override: null, floor };
}

/**
 * 22.3 & 24.15 Deterministic Signal Classifier (CHAT / TASK / HEAVY / DEEP)
 */
export function classifyGearDeterministic(input: GearClassificationInput): GearLevel {
  const {
    prompt,
    attachmentCount = 0,
    attachmentNames = [],
    hasOpenArtifact = false,
    priorHedgeInThread = false,
    topicAttempts = 0,
    previousTurnGear = 'CHAT',
    consecutiveChatTurns = 0,
  } = input;

  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();
  const tokens = trimmed.split(/\s+/).filter(Boolean);

  // 24.15 Guard: Never DEEP on a single-fact question, even if asked
  if (isSingleFactTrivialQuestion(trimmed)) {
    return 'CHAT';
  }

  // 1. Check explicit overrides & floors (22.6 & 24.15)
  const { override, floor } = checkExplicitGearOverride(trimmed, previousTurnGear);
  if (override) {
    if (floor === 'DEEP') return 'DEEP';
    if (floor === 'HEAVY') return 'HEAVY';
    if (floor === 'TASK' && override === 'CHAT') return 'TASK';
    return override;
  }

  // 2. Check conversational floor (22.7)
  if (detectConversationalFloor(trimmed) && attachmentCount === 0) {
    return 'CHAT';
  }

  // 24.15 Check DEEP triggers: math/proof, algorithmic complexity, hard debugging (3+ attempts / deep stack trace),
  // architecture & migration planning, concurrency
  const hasDeepConcurrency =
    /\b(concurrency|concurrent|deadlock|livelock|race condition|lock-free|wait-free|memory model|memory order|compare-and-swap|cas loop|linearizability|aba problem|mutex contention|thread safety)\b/i.test(
      lower
    );
  const hasDeepMathOrProof =
    /\b(formal proof|prove that|by induction|contradiction proof|lemma|theorem|asymptotic complexity|np-complete|np-hard|recurrence relation|time complexity proof)\b/i.test(
      lower
    );
  const hasDeepArchOrMigration =
    /\b(migration plan|architecture design|zero-downtime migration|distributed consensus|raft|paxos|multi-region active-active)\b/i.test(
      lower
    );
  const stackFramesCount = (trimmed.match(/\bat\s+[A-Za-z0-9_$.<>]+\s*\(/g) || []).length;
  const hasHardDebugging = stackFramesCount >= 3 || (topicAttempts >= 3 && /\b(bug|error|crash|segfault|panic)\b/i.test(lower));

  if (hasDeepConcurrency || hasDeepMathOrProof || hasDeepArchOrMigration || hasHardDebugging) {
    return 'DEEP';
  }

  // 3. Score signals toward HEAVY, TASK, CHAT (22.3)
  let heavyScore = 0;
  let taskScore = 0;
  let chatScore = 0;

  // --- HEAVY signals ---
  if (
    /\b(complete|full|production|everything|entire|from scratch|thorough|deep|no shortcuts|final|end-to-end)\b/i.test(
      lower
    )
  ) {
    heavyScore += 3;
  }
  if (/\b(tampermonkey|violentmonkey|userscript|artifact|application|dashboard|full script)\b/i.test(lower)) {
    heavyScore += 3;
  }
  if (lower.startsWith('/exploit') || lower.startsWith('/userscript')) {
    heavyScore += 5;
  }
  if (attachmentCount > 3) {
    heavyScore += 4;
  }
  const hasCodeOrLockfile = attachmentNames.some((n) =>
    /\.(ts|tsx|js|jsx|py|rs|go|c|cpp|h|json|lock|toml|yaml|yml|sh)$/i.test(n)
  );
  if (hasCodeOrLockfile) {
    heavyScore += 3;
  }

  // History signals (only count if consecutiveChatTurns < 4 per 22.5 Decay)
  if (consecutiveChatTurns < 4) {
    if (priorHedgeInThread) heavyScore += 2;
    if (topicAttempts >= 3) heavyScore += 3;
    if (hasOpenArtifact && tokens.length > 6) heavyScore += 2;
  }

  // --- TASK signals ---
  if (/\b(how do i|how to|why does|why is|write a|build a|create a|implement|debug|fix|refactor|explain how)\b/i.test(lower)) {
    taskScore += 3;
  }
  // Imperative verb at start
  if (/^(write|build|create|make|implement|generate|analyze|parse|convert|fetch|scrape|find|show|list|compare|test|run|check|fix|solve|calculate)\b/i.test(lower)) {
    taskScore += 2;
  }
  // Code, log, or stack trace present
  if (/```|`[^`]+`|\b(error:|exception|at\s+[a-zA-Z0-9_.]+\s*\(|function\s+|const\s+|import\s+|def\s+|SELECT\s+)/i.test(trimmed)) {
    taskScore += 3;
  }
  // URL to read
  if (/https?:\/\/[^\s]+/i.test(trimmed)) {
    taskScore += 2;
  }
  // File attached
  if (attachmentCount > 0) {
    taskScore += 2;
  }
  // Question with more than one clause
  if (trimmed.includes('?') && (trimmed.includes(',') || trimmed.includes(';') || /\b(and|because|while|when|if)\b/i.test(lower)) && tokens.length >= 12) {
    taskScore += 2;
  }

  // --- CHAT signals ---
  const hasCode = /```|`[^`]+`/.test(trimmed);
  if (tokens.length < 12 && !hasCode && attachmentCount === 0 && !lower.startsWith('/')) {
    chatScore += 3;
  }
  // Single-fact question or definition request ("what's the capital of Peru", "what is X", "who is Y", "why does my knee hurt")
  if (
    /^(what('s|\s+is|\s+are)|who('s|\s+is|\s+was)|when\s+(did|was|is)|where\s+is|define\s+|meaning\s+of|capital\s+of|why\s+does\s+my)\b/i.test(
      lower
    ) &&
    tokens.length <= 14 &&
    !hasCode
  ) {
    chatScore += 4;
  }
  // Conversational follow-up with no new heavy object
  if (tokens.length <= 8 && !hasCode && heavyScore === 0 && taskScore <= 2) {
    chatScore += 2;
  }

  // Resolve winner
  let selected: GearLevel = 'TASK'; // 22.3: Default on a tie is TASK. Never default to HEAVY.

  if (heavyScore >= 3 && heavyScore > taskScore && heavyScore > chatScore) {
    selected = 'HEAVY';
  } else if (heavyScore >= 4 && taskScore >= 2) {
    selected = 'HEAVY';
  } else if (chatScore > taskScore && chatScore > heavyScore && heavyScore < 3) {
    selected = 'CHAT';
  } else if (taskScore > 0 || heavyScore > 0) {
    selected = heavyScore >= 3 ? 'HEAVY' : 'TASK';
  } else {
    selected = tokens.length < 12 ? 'CHAT' : 'TASK';
  }

  // Apply slash floor if present
  if (floor === 'DEEP') return 'DEEP';
  if (floor === 'HEAVY') return 'HEAVY';
  if (floor === 'TASK' && selected === 'CHAT') return 'TASK';

  return selected;
}

/**
 * Section 22.3 — Background Gear Classifier Service
 *
 * One Groq call, max 4 tokens, returning CHAT, TASK, or HEAVY.
 * Runs on every turn before generation with no glyph and no visible trace,
 * and updates generation parameters accordingly.
 */
export class GearClassifierService {
  private cache = new Map<string, GearLevel>();
  private fetchImpl: typeof fetch;
  private apiKeyOverride?: string;

  constructor(options?: { fetchImpl?: typeof fetch; apiKey?: string }) {
    this.fetchImpl = options?.fetchImpl || fetch;
    this.apiKeyOverride = options?.apiKey;
  }

  public async classifyAndConfigure(
    input: GearClassificationInput,
    options?: { forceGroqCall?: boolean }
  ): Promise<{ gear: GearLevel; generationParams: GearGenerationParams; source: 'groq' | 'deterministic' | 'cache' }> {
    const trimmed = (input.prompt || '').trim();
    const isFloor = detectConversationalFloor(trimmed) && (input.attachmentCount || 0) === 0;

    if (isFloor) {
      return {
        gear: 'CHAT',
        generationParams: getGenerationParamsForGear('CHAT', { isConversationalFloor: true }),
        source: 'deterministic',
      };
    }

    const { override, floor } = checkExplicitGearOverride(trimmed, input.previousTurnGear);
    if (override) {
      let resolved: GearLevel = override;
      if (floor === 'DEEP') resolved = 'DEEP';
      else if (floor === 'HEAVY') resolved = 'HEAVY';
      else if (floor === 'TASK' && override === 'CHAT') resolved = 'TASK';

      return {
        gear: resolved,
        generationParams: getGenerationParamsForGear(resolved),
        source: 'deterministic',
      };
    }

    const det = classifyGearDeterministic(input);
    if ((det === 'DEEP' || det === 'CHAT') && !options?.forceGroqCall) {
      return {
        gear: det,
        generationParams: getGenerationParamsForGear(det),
        source: 'deterministic',
      };
    }

    const cacheKey = `${trimmed.slice(0, 200)}::${input.attachmentCount || 0}::${input.hasOpenArtifact ? 1 : 0}::${input.topicAttempts || 0}`;
    if (this.cache.has(cacheKey) && !options?.forceGroqCall) {
      const cachedGear = this.cache.get(cacheKey)!;
      return {
        gear: cachedGear,
        generationParams: getGenerationParamsForGear(cachedGear),
        source: 'cache',
      };
    }

    const tokens = trimmed.split(/\s+/).filter(Boolean);
    const shouldCallGroq =
      Boolean(options?.forceGroqCall) ||
      (tokens.length >= 12 && tokens.length <= 80 && det !== 'DEEP' && det !== 'CHAT');

    if (shouldCallGroq) {
      try {
        const env = getEnv();
        const apiKey = this.apiKeyOverride ?? env.GROQ_API_KEY;
        if (apiKey) {
          const res = await this.fetchImpl('https://api.groq.com/openai/v1/chat/completions', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
              model: 'llama-3.1-8b-instant',
              max_tokens: 4,
              temperature: 0,
              messages: [
                {
                  role: 'system',
                  content:
                    'Classify effort required for the user prompt into one word: CHAT (small talk, quick fact, simple question), TASK (standard coding, how-to, explanation), or HEAVY (complete deliverable, full userscript/app, deep production implementation). Output ONLY one word: CHAT, TASK, or HEAVY.',
                },
                { role: 'user', content: trimmed.slice(0, 600) },
              ],
            }),
            signal: AbortSignal.timeout(800),
          });

          if (res.ok) {
            const data: any = await res.json();
            const raw = (data.choices?.[0]?.message?.content || '').trim().toUpperCase();
            let groqGear: GearLevel | null = null;
            if (raw.includes('HEAVY')) groqGear = 'HEAVY';
            else if (raw.includes('CHAT')) groqGear = 'CHAT';
            else if (raw.includes('TASK')) groqGear = 'TASK';

            if (groqGear) {
              // Respect deterministic HEAVY signals (attachments, /exploit, /userscript, prior hedges)
              const finalGear: GearLevel = det === 'HEAVY' ? 'HEAVY' : groqGear;
              if (this.cache.size >= 500) {
                const oldestKey = this.cache.keys().next().value;
                if (oldestKey !== undefined) this.cache.delete(oldestKey);
              }
              this.cache.set(cacheKey, finalGear);
              return {
                gear: finalGear,
                generationParams: getGenerationParamsForGear(finalGear),
                source: 'groq',
              };
            }
          }
        }
      } catch {
        // Fallback silently to deterministic classification
      }
    }

    if (this.cache.size >= 500) {
      const oldestKey = this.cache.keys().next().value;
      if (oldestKey !== undefined) this.cache.delete(oldestKey);
    }
    this.cache.set(cacheKey, det);
    return {
      gear: det,
      generationParams: getGenerationParamsForGear(det),
      source: 'deterministic',
    };
  }

  public clearCache(): void {
    this.cache.clear();
  }
}

export const gearClassifierService = new GearClassifierService();

export function getGearClassifierService(): GearClassifierService {
  return gearClassifierService;
}

/**
 * 22.3 One Groq call, max 4 tokens, returning CHAT, TASK, or HEAVY.
 * Runs before generation with zero glyph and zero visible trace.
 */
export async function classifyGearWithGroq(
  input: GearClassificationInput,
  options?: { fetchImpl?: typeof fetch; apiKey?: string; forceGroqCall?: boolean }
): Promise<GearLevel> {
  const service =
    options?.fetchImpl || options?.apiKey
      ? new GearClassifierService({ fetchImpl: options.fetchImpl, apiKey: options.apiKey })
      : gearClassifierService;
  const res = await service.classifyAndConfigure(input, { forceGroqCall: options?.forceGroqCall });
  return res.gear;
}

/**
 * 22.5 Decay & State Transition Engine
 * Updates conversation gear state for a new turn and returns full Turn Gear configuration
 * including updated generation parameters.
 */
export async function evaluateTurnGearing(
  conversationId: string,
  prompt: string,
  options?: {
    attachmentCount?: number;
    attachmentNames?: string[];
    hasOpenArtifact?: boolean;
    useGroqClassifier?: boolean;
  }
): Promise<GearClassificationResult> {
  const state = getThreadGearState(conversationId);
  if (options?.hasOpenArtifact !== undefined) {
    state.hasOpenArtifact = options.hasOpenArtifact;
  }

  const register = inferRegister(prompt);
  const isFloor = detectConversationalFloor(prompt) && (options?.attachmentCount || 0) === 0;

  const classInput: GearClassificationInput = {
    prompt,
    attachmentCount: options?.attachmentCount || 0,
    attachmentNames: options?.attachmentNames || [],
    hasOpenArtifact: state.hasOpenArtifact,
    priorHedgeInThread: state.priorHedgeCount > 0,
    topicAttempts: state.topicAttempts,
    previousTurnGear: state.lastTurnGear,
    consecutiveChatTurns: state.consecutiveChatTurns,
  };

  const classifiedGear = options?.useGroqClassifier
    ? await classifyGearWithGroq(classInput)
    : classifyGearDeterministic(classInput);

  // 22.5 Decay tracking
  if (classifiedGear === 'CHAT') {
    state.consecutiveChatTurns += 1;
    // After 2 consecutive CHAT-classified turns, a HEAVY thread returns to CHAT
    if (state.consecutiveChatTurns >= 2) {
      state.currentGear = 'CHAT';
    }
    // After 4 consecutive CHAT turns, HEAVY must be re-earned by signal, not thread history alone
    if (state.consecutiveChatTurns >= 4) {
      state.priorHedgeCount = 0;
      state.topicAttempts = 0;
      state.hasOpenArtifact = false;
    }
  } else {
    state.consecutiveChatTurns = 0;
    state.topicAttempts += 1;
    state.currentGear = classifiedGear;
  }

  const effectiveGear: GearLevel = classifiedGear;
  state.lastTurnGear = effectiveGear;

  const generationParams = getGenerationParamsForGear(effectiveGear, {
    isConversationalFloor: isFloor,
  });

  return {
    gear: effectiveGear,
    register,
    isConversationalFloor: isFloor,
    hideGlyphs: effectiveGear === 'CHAT' || isFloor,
    skipChips: effectiveGear === 'CHAT' || isFloor,
    startingRung: generationParams.startingRung,
    generationParams,
  };
}

/**
 * 22.4 Hard Ceiling Rule — Dynamic Mid-Turn Upgrade
 * If a CHAT turn trips the ladder twice, it upgrades itself to TASK silently.
 * If a TASK turn trips the ladder twice, it upgrades to HEAVY silently.
 */
export function checkDynamicGearUpgrade(
  currentGear: GearLevel,
  ladderTripsThisTurn: number,
  conversationId?: string
): { upgradedGear: GearLevel; upgraded: boolean; generationParams: GearGenerationParams } {
  if (ladderTripsThisTurn >= 2) {
    if (currentGear === 'CHAT') {
      if (conversationId) {
        const state = getThreadGearState(conversationId);
        state.currentGear = 'TASK';
        state.priorHedgeCount += ladderTripsThisTurn;
      }
      return {
        upgradedGear: 'TASK',
        upgraded: true,
        generationParams: getGenerationParamsForGear('TASK'),
      };
    }
    if (currentGear === 'TASK') {
      if (conversationId) {
        const state = getThreadGearState(conversationId);
        state.currentGear = 'HEAVY';
        state.priorHedgeCount += ladderTripsThisTurn;
      }
      return {
        upgradedGear: 'HEAVY',
        upgraded: true,
        generationParams: getGenerationParamsForGear('HEAVY'),
      };
    }
  }
  return {
    upgradedGear: currentGear,
    upgraded: false,
    generationParams: getGenerationParamsForGear(currentGear),
  };
}
