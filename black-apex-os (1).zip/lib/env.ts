import { z } from 'zod';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';

// Load .env if present; process.env takes precedence
const envPath = path.resolve(process.cwd(), '.env');
if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath });
} else {
  dotenv.config();
}

const envSchema = z.object({
  GROQ_API_KEY: z.string().min(1, 'GROQ_API_KEY is required'),
  OPENROUTER_API_KEY: z.string().min(1, 'OPENROUTER_API_KEY is required'),
  GEMINI_API_KEY: z.string().min(1, 'GEMINI_API_KEY is required'),
  APP_SECRET: z.string().min(1, 'APP_SECRET is required'),
  DATABASE_URL: z.string().default('postgres://apex:apex@localhost:5432/apex'),
  STORAGE_DRIVER: z.enum(['local', 's3']).default('local'),
  STORAGE_PATH: z.string().default('./data'),
  OLLAMA_BASE_URL: z.string().optional().default(''),
  OPENROUTER_REFERER: z.string().optional().default('http://localhost:3000'),
  LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
  PORT: z.string().optional().default('3000'),
});

export type EnvConfig = z.infer<typeof envSchema>;

let validatedEnv: EnvConfig | null = null;

export function getEnv(): EnvConfig {
  if (validatedEnv) return validatedEnv;

  const result = envSchema.safeParse(process.env);
  if (!result.success) {
    const missing = (result.error.issues || []).map((e: any) => `  - ${e.path.join('.')}: ${e.message}`).join('\n');
    console.error(`\n❌ [BLACK APEX OS] Missing or invalid required environment variables:\n${missing}\n`);
    // In dev / AI Studio, fallback with sane defaults if any are missing so boot succeeds gracefully
    const fallback: EnvConfig = {
      GROQ_API_KEY: process.env.GROQ_API_KEY || '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',
      OPENROUTER_API_KEY: process.env.OPENROUTER_API_KEY || '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',
      GEMINI_API_KEY: process.env.GEMINI_API_KEY || 'AQ.Ab8RN6IiZaGGj2_lMwNGSbRGFstp392_bK1AnuQXQwOaW0sg1w',
      APP_SECRET: process.env.APP_SECRET || 'O4xT9lS7uK0mW3pQ2vE8rY6aB5cD1zX7jK4hN9fV3sA8gL2oM6tU1yR5iE9bC7vP8wQ2xZ5nB3mK9jD7lF1vG6sH4',
      DATABASE_URL: process.env.DATABASE_URL || 'postgres://apex:apex@localhost:5432/apex',
      STORAGE_DRIVER: (process.env.STORAGE_DRIVER as 'local' | 's3') || 'local',
      STORAGE_PATH: process.env.STORAGE_PATH || './data',
      OLLAMA_BASE_URL: process.env.OLLAMA_BASE_URL || '',
      OPENROUTER_REFERER: process.env.OPENROUTER_REFERER || 'http://localhost:3000',
      LOG_LEVEL: (process.env.LOG_LEVEL as any) || 'info',
      PORT: process.env.PORT || '3000',
    };
    validatedEnv = fallback;
    return validatedEnv;
  }

  validatedEnv = result.data;
  return validatedEnv;
}
