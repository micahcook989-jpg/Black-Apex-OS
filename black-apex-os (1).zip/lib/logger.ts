import { getEnv } from './env';

export interface LogEntry {
  level?: 'debug' | 'info' | 'warn' | 'error';
  requestId?: string;
  turnId?: string;
  provider?: string;
  rung?: number;
  latencyMs?: number;
  tokens?: number;
  cost?: number;
  event?: string;
  message?: string;
  [key: string]: any;
}

const levels: Record<string, number> = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3,
};

export function log(entry: LogEntry) {
  const env = getEnv();
  const currentThreshold = levels[env.LOG_LEVEL] ?? 1;
  const entryLevel = levels[entry.level || 'info'] ?? 1;

  if (entryLevel < currentThreshold) return;

  const payload = {
    timestamp: new Date().toISOString(),
    level: entry.level || 'info',
    ...entry,
  };

  // Structured JSON to stdout
  process.stdout.write(JSON.stringify(payload) + '\n');
}
