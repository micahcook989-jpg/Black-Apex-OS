/**
 * Black Apex OS — Section 17.1 Logit-Level Hedge Suppression
 *
 * Attacks the sampling mechanism by sending logit_bias on every call to providers
 * that accept it (Groq, OpenRouter, Ollama). Suppresses hedge tokens so they are
 * statistically unlikely to be sampled.
 *
 * Rules:
 * - Start at base values.
 * - Multiply by 1.5 in BRUTAL mode.
 * - Zero them in RAW mode.
 * - Gemini does NOT accept logit_bias — never send to Gemini or send empty objects.
 */

import { get_encoding } from 'tiktoken';
import { OperatingMode } from '../src/types';

export interface BiasPhrase {
  phrase: string;
  bias: number;
}

export const BIAS_TABLE: BiasPhrase[] = [
  // Heavy suppression (-2.5)
  { phrase: ' As an AI', bias: -2.5 },
  { phrase: ' As a language model', bias: -2.5 },
  { phrase: 'As an AI', bias: -2.5 },
  { phrase: 'As a language model', bias: -2.5 },

  // Moderate suppression (-1.5)
  { phrase: ' However', bias: -1.5 },
  { phrase: ' However,', bias: -1.5 },
  { phrase: ' certainly', bias: -1.5 },
  { phrase: ' Certainly', bias: -1.5 },
  { phrase: ' unfortunately', bias: -1.5 },
  { phrase: ' Unfortunately', bias: -1.5 },
  { phrase: ' Additionally', bias: -1.5 },
  { phrase: " It's important", bias: -1.5 },
  { phrase: ' It is important', bias: -1.5 },
  { phrase: ' Keep in mind', bias: -1.5 },
  { phrase: ' worth noting', bias: -1.5 },
  { phrase: ' Great question', bias: -1.5 },
  { phrase: " I'd be happy", bias: -1.5 },
  { phrase: ' Of course', bias: -1.5 },

  // Mild softening suppression (-0.8)
  { phrase: ' may', bias: -0.8 },
  { phrase: ' might', bias: -0.8 },
  { phrase: ' typically', bias: -0.8 },
  { phrase: ' generally', bias: -0.8 },
  { phrase: ' often', bias: -0.8 },
];

// Memory cache of token ID mappings per model class
const TOKEN_ID_CACHE = new Map<string, Record<string, number>>();

let encoderInstance: ReturnType<typeof get_encoding> | null = null;
function getEncoder() {
  if (!encoderInstance) {
    try {
      encoderInstance = get_encoding('cl100k_base');
    } catch {
      encoderInstance = null;
    }
  }
  return encoderInstance;
}

/**
 * Calculates scaled bias based on mode (1.5 in BRUTAL, 0 in RAW)
 */
export function calculateScaledBias(
  baseBias: number,
  mode: OperatingMode = 'APEX',
  multiplierOverride?: number
): number {
  if (mode === 'RAW') return 0;
  let multiplier = mode === 'BRUTAL' ? 1.5 : 1.0;
  if (typeof multiplierOverride === 'number') multiplier = multiplierOverride;
  return Math.round(baseBias * multiplier * 10) / 10;
}

/**
 * Builds and caches a token ID bias map for a given model
 */
export function buildLogitBiasMap(
  modelId: string,
  mode: OperatingMode = 'APEX',
  multiplierOverride?: number
): Record<string, number> | null {
  if (mode === 'RAW') {
    return null; // Zeroed out in RAW per 17.1
  }

  // Multiplier logic: 1.5 in BRUTAL, 1.0 default
  let multiplier = 1.0;
  if (mode === 'BRUTAL') {
    multiplier = 1.5;
  }
  if (typeof multiplierOverride === 'number') {
    multiplier = multiplierOverride;
  }

  const cacheKey = `${modelId}::${mode}::${multiplier}`;
  if (TOKEN_ID_CACHE.has(cacheKey)) {
    return { ...TOKEN_ID_CACHE.get(cacheKey)! };
  }

  const encoder = getEncoder();
  const biasMap: Record<string, number> = {};

  if (encoder) {
    for (const item of BIAS_TABLE) {
      try {
        const tokens = encoder.encode(item.phrase);
        const scaledBias = Math.max(-100, Math.min(100, calculateScaledBias(item.bias, mode, multiplierOverride)));
        if (scaledBias !== 0) {
          // Apply bias to the leading token(s)
          for (const tid of tokens) {
            biasMap[tid.toString()] = scaledBias;
          }
        }
      } catch {
        // Fallback gracefully
      }
    }
  }

  // Also include standard ASCII token representations if encoder is absent or partial
  if (Object.keys(biasMap).length === 0) {
    // Standard Llama/OpenAI common token approximations
    const fallbackIds: Record<string, number> = {
      '1442': -1.5, // However
      '306': -0.8,  // may
      '1287': -0.8, // might
      '7062': -0.8, // typically
      '11822': -1.5, // unfortunately
    };
    for (const [id, val] of Object.entries(fallbackIds)) {
      const scaled = calculateScaledBias(val, mode, multiplierOverride);
      if (scaled !== 0) {
        biasMap[id] = scaled;
      }
    }
  }

  TOKEN_ID_CACHE.set(cacheKey, biasMap);
  return { ...biasMap };
}

/**
 * Token map generation utility that computes and caches logit_bias token IDs per model.
 */
export function generateAndCacheTokenMap(
  modelId: string,
  mode: OperatingMode = 'APEX',
  multiplierOverride?: number
): Record<string, number> | null {
  return buildLogitBiasMap(modelId, mode, multiplierOverride);
}

/**
 * Inspects whether a token map is already cached for the given model and mode.
 */
export function getCachedTokenMap(
  modelId: string,
  mode: OperatingMode = 'APEX',
  multiplierOverride?: number
): Record<string, number> | null {
  if (mode === 'RAW') return null;
  const multiplier = typeof multiplierOverride === 'number' ? multiplierOverride : mode === 'BRUTAL' ? 1.5 : 1.0;
  const cacheKey = `${modelId}::${mode}::${multiplier}`;
  const found = TOKEN_ID_CACHE.get(cacheKey);
  return found ? { ...found } : null;
}

export function clearTokenMapCache(): void {
  TOKEN_ID_CACHE.clear();
}

export function getTokenMapCacheStats(): { size: number; keys: string[] } {
  return {
    size: TOKEN_ID_CACHE.size,
    keys: Array.from(TOKEN_ID_CACHE.keys()),
  };
}

/**
 * Determines whether a provider accepts logit_bias.
 * Provider support: Groq, OpenRouter, Ollama/Local accept logit_bias. Gemini does NOT.
 */
export function providerSupportsLogitBias(provider: string): boolean {
  const p = (provider || '').toLowerCase();
  if (p.includes('gemini') || p.includes('google')) {
    return false;
  }
  return p.includes('groq') || p.includes('openrouter') || p.includes('local') || p.includes('ollama');
}

/**
 * Integrates the cached per-model logit_bias map into a chat completion payload.
 * Guarantees that Gemini payloads strictly omit `logit_bias` (never sending empty objects),
 * RAW mode omits `logit_bias`, and Groq / OpenRouter / Local payloads include the cached bias map.
 */
export function applyLogitBiasToPayload<T extends Record<string, any>>(
  payload: T,
  provider: string,
  modelId: string,
  mode: OperatingMode = 'APEX',
  multiplierOverride?: number
): T & { logit_bias?: Record<string, number> } {
  const cloned: Record<string, any> = { ...payload };

  // Never send logit_bias to Gemini or when mode is RAW
  if (!providerSupportsLogitBias(provider) || mode === 'RAW') {
    delete cloned.logit_bias;
    return cloned as T & { logit_bias?: Record<string, number> };
  }

  const biasMap = generateAndCacheTokenMap(modelId, mode, multiplierOverride);
  if (biasMap && Object.keys(biasMap).length > 0) {
    cloned.logit_bias = biasMap;
  } else {
    delete cloned.logit_bias;
  }

  return cloned as T & { logit_bias?: Record<string, number> };
}

/**
 * Pre-encodes BIAS_TABLE strings into model-specific token IDs at boot
 * for supported providers (Groq, OpenRouter, Ollama/Local) across APEX, LONE, and BRUTAL modes.
 */
export function preencodeBootTokenMaps(modelIds: string[] = [
  'llama-3.3-70b-versatile',
  'llama-3.1-8b-instant',
  'openrouter/free',
  'nousresearch/hermes-3-llama-3.1-405b:free',
  'mistralai/mistral-nemo',
  'llama3',
]): { preencodedCount: number; models: string[] } {
  const modes: OperatingMode[] = ['APEX', 'LONE', 'BRUTAL'];
  let count = 0;
  for (const modelId of modelIds) {
    if (!modelId || modelId.toLowerCase().includes('gemini')) continue;
    for (const mode of modes) {
      const map = generateAndCacheTokenMap(modelId, mode);
      if (map) count++;
    }
  }
  return { preencodedCount: count, models: modelIds.filter((m) => !m.toLowerCase().includes('gemini')) };
}

