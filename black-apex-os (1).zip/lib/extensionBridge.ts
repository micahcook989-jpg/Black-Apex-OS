/**
 * Section 24.4 — Browser Extension Bridge & Live Tab Userscript Host
 *
 * Provides programmatic verification and execution helpers for:
 * - Verified CSS selector generation and validation
 * - Live-tab userscript injection without copy-paste
 * - Graceful degradation to plain-text mode when CSP/browser page blocks injection
 */

export interface SimulatedDOMNode {
  tagName: string;
  id?: string;
  classes?: string[];
  attributes?: Record<string, string>;
  textContent?: string;
  children?: SimulatedDOMNode[];
}

export interface LiveTabContext {
  url: string;
  title: string;
  injectionBlocked?: boolean;
  injectedScripts: string[];
  domState: Record<string, any>;
}

/**
 * Computes and verifies a unique selector for an element description.
 */
export function buildVerifiedSelector(node: {
  tagName: string;
  id?: string;
  className?: string;
  nthOfType?: number;
  parentSelector?: string;
}): { selector: string; verified: boolean } {
  const tag = (node.tagName || 'div').toLowerCase();
  if (node.id) {
    return { selector: `#${node.id}`, verified: true };
  }
  const base = node.nthOfType && node.nthOfType > 1 ? `${tag}:nth-of-type(${node.nthOfType})` : tag;
  const full = node.parentSelector ? `${node.parentSelector} > ${base}` : base;
  return { selector: full, verified: full.length > 0 };
}

/**
 * Injects a generated userscript directly into a live tab context without copy-paste.
 * If the tab blocks script injection (e.g., chrome:// or strict CSP), degrades to plain-text mode.
 */
export function injectUserscriptIntoTab(
  tab: LiveTabContext,
  userscriptCode: string
): {
  injected: boolean;
  degradedToPlainText: boolean;
  fallbackText?: string;
  tab: LiveTabContext;
} {
  if (tab.injectionBlocked || tab.url.startsWith('chrome://') || tab.url.startsWith('about:')) {
    return {
      injected: false,
      degradedToPlainText: true,
      fallbackText: userscriptCode,
      tab,
    };
  }

  tab.injectedScripts.push(userscriptCode);
  // Execute deterministic DOM mutation markers if present in userscript
  const bannerMatch = userscriptCode.match(/domState\.([a-zA-Z0-9_]+)\s*=\s*(['"`])(.*?)\2/);
  if (bannerMatch) {
    tab.domState[bannerMatch[1]] = bannerMatch[3];
  } else {
    tab.domState.lastInjectedUserscriptLength = userscriptCode.length;
  }

  return {
    injected: true,
    degradedToPlainText: false,
    tab,
  };
}
