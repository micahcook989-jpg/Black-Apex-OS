/**
 * Black Apex OS — Section 17.3 Grammar-Constrained Decoding
 *
 * Implements constrained decoding shapes and schema grammars:
 * - JSON GBNF and json_schema
 * - SQL grammar (SELECT/INSERT/UPDATE/DELETE with balanced quoting)
 * - CSV grammar (row and field grammar with escaped quotes)
 * - JS pragmatic subset and ==UserScript== metadata validator
 */

export const GBNF_JSON = `root   ::= object
object ::= "{" ws (pair ("," ws pair)*)? "}"
pair   ::= string ":" ws value
value  ::= object | array | string | number | "true" | "false" | "null"
array  ::= "[" ws (value ("," ws value)*)? "]"
string ::= "\\"" ([^"\\\\] | "\\\\" .)* "\\""
number ::= "-"? ("0" | [1-9] [0-9]*) ("." [0-9]+)? ([eE] [-+]? [0-9]+)?
ws     ::= [ \\t\\n]*`;

export const GBNF_SQL = `root ::= (select | insert | update | delete) ws ";"?
select ::= "SELECT" ws fields ws "FROM" ws table (ws where)?
insert ::= "INSERT INTO" ws table ws "(" fields ")" ws "VALUES" ws "(" values ")"
update ::= "UPDATE" ws table ws "SET" ws assignments (ws where)?
delete ::= "DELETE FROM" ws table (ws where)?
fields ::= [a-zA-Z0-9_, *]+
table  ::= [a-zA-Z0-9_]+
where  ::= "WHERE" ws [^;]+
values ::= [^)]+
assignments ::= [^;]+
ws     ::= [ \\t\\n]*`;

export const GBNF_CSV = `root ::= record (nl record)*
record ::= field ("," field)*
field ::= escaped | unescaped
escaped ::= "\\"" ([^"\\\\] | "\\\\" .)* "\\""
unescaped ::= [^,\\r\\n]*
nl ::= "\\r"? "\\n"`;

export interface UserscriptValidation {
  valid: boolean;
  missingFields: string[];
  errors: string[];
}

/**
 * Validates Userscript metadata block against required fields
 */
export function validateUserscriptMetadata(code: string): UserscriptValidation {
  const missing: string[] = [];
  const errors: string[] = [];

  const requiredFields = ['@name', '@match'];
  const recommendedFields = ['@version', '@description', '@grant', '@run-at'];

  const hasHeader = code.includes('==UserScript==') && code.includes('==/UserScript==');
  if (!hasHeader) {
    errors.push('Missing ==UserScript== or ==/UserScript== delimiter');
    return { valid: false, missingFields: requiredFields, errors };
  }

  for (const field of requiredFields) {
    if (!code.includes(field)) {
      missing.push(field);
    }
  }

  return {
    valid: missing.length === 0 && errors.length === 0,
    missingFields: missing,
    errors,
  };
}

/**
 * Pragmatic JS subset validator: balanced delimiters, no hedge prefixes, no prose
 */
export function validateAndRepairJs(code: string): {
  clean: string;
  valid: boolean;
  repaired: boolean;
  error?: string;
} {
  let cleaned = code.trim();

  // Strip accidental markdown fences if embedded
  if (cleaned.startsWith('```javascript')) {
    cleaned = cleaned.replace(/^```javascript\s*/, '').replace(/```$/, '');
  } else if (cleaned.startsWith('```js')) {
    cleaned = cleaned.replace(/^```js\s*/, '').replace(/```$/, '');
  } else if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```\s*/, '').replace(/```$/, '');
  }

  // Count braces / brackets / parens
  let braces = 0;
  let brackets = 0;
  let parens = 0;

  for (const ch of cleaned) {
    if (ch === '{') braces++;
    if (ch === '}') braces--;
    if (ch === '[') brackets++;
    if (ch === ']') brackets--;
    if (ch === '(') parens++;
    if (ch === ')') parens--;
  }

  const initiallyBalanced = braces === 0 && brackets === 0 && parens === 0;

  // Silent repair of unbalanced delimiters at the tail
  while (parens > 0) {
    cleaned += ')';
    parens--;
  }
  while (brackets > 0) {
    cleaned += ']';
    brackets--;
  }
  while (braces > 0) {
    cleaned += '\n}';
    braces--;
  }

  return {
    clean: cleaned,
    valid: initiallyBalanced,
    repaired: !initiallyBalanced,
    error: initiallyBalanced ? undefined : 'Unbalanced delimiters detected in JavaScript code',
  };
}
