import express, { Request, Response, NextFunction } from 'express';
import { secretsVault } from './vault';
import { retentionManager } from './retention';
import { wrapUntrustedContent, scanForPromptInjection } from './injectionDefense';
import { replayStore } from './replay';
import { codebaseManager, parseUnifiedDiff } from './codebase';
import { runRedTeamAudit } from './redteam';
import { shouldTriggerSpecFirst, specStore } from './specFirst';
import { executeTDDLoop } from './tddLoop';
import {
  evaluateProvenanceSet,
  contradictionDetector,
  correctionCaptureManager,
  blindABEloManager,
  localOnlyGuard,
  encryptSyncBlob,
  decryptSyncBlob,
  publishedArtifactStore,
  profileManager,
  distillThreadToJSONL,
} from './intelligence';
import { evaluateTurnGearing } from './gearing';
import { stripResponse } from './stripper';

/**
 * Section 24.3 — Headless API (/api/v1)
 *
 * Mirrors the internal surface: chat, conversations, files, artifacts, tools,
 * memory, repos, vault, retention, replay, redteam, and intelligence layers.
 * Enforces Bearer token authentication, per-token scopes, and per-token rate limits.
 */

export type ApiTokenScope =
  | 'chat'
  | 'conversations'
  | 'files'
  | 'artifacts'
  | 'tools'
  | 'memory'
  | 'repos'
  | 'admin';

export interface ApiTokenRecord {
  token: string;
  name: string;
  scopes: ApiTokenScope[];
  rateLimitPerMinute: number;
  createdAt: number;
}

class ApiTokenGate {
  private tokens = new Map<string, ApiTokenRecord>();
  private usageWindows = new Map<string, { windowStart: number; count: number }>();

  constructor() {
    // Seed a default headless token for CLI / local integration
    const defaultToken = process.env.BAX_API_TOKEN || 'bax_default_local_token';
    this.registerToken({
      token: defaultToken,
      name: 'Default CLI Token',
      scopes: ['chat', 'conversations', 'files', 'artifacts', 'tools', 'memory', 'repos', 'admin'],
      rateLimitPerMinute: 120,
    });
  }

  registerToken(params: {
    token?: string;
    name: string;
    scopes: ApiTokenScope[];
    rateLimitPerMinute?: number;
  }): ApiTokenRecord {
    const token = params.token || `bax_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
    const record: ApiTokenRecord = {
      token,
      name: params.name,
      scopes: params.scopes,
      rateLimitPerMinute: params.rateLimitPerMinute ?? 60,
      createdAt: Date.now(),
    };
    this.tokens.set(token, record);
    return record;
  }

  verifyAndConsume(
    token: string,
    requiredScope: ApiTokenScope
  ): { allowed: boolean; status: number; error?: string; record?: ApiTokenRecord } {
    const record = this.tokens.get(token);
    if (!record) {
      return { allowed: false, status: 401, error: 'Invalid or missing Bearer token' };
    }
    if (!record.scopes.includes(requiredScope) && !record.scopes.includes('admin')) {
      return {
        allowed: false,
        status: 403,
        error: `Token lacks required scope: ${requiredScope}`,
      };
    }

    const now = Date.now();
    const win = this.usageWindows.get(token);
    if (!win || now - win.windowStart >= 60_000) {
      this.usageWindows.set(token, { windowStart: now, count: 1 });
      return { allowed: true, status: 200, record };
    }

    if (win.count >= record.rateLimitPerMinute) {
      return {
        allowed: false,
        status: 429,
        error: `Rate limit exceeded (${record.rateLimitPerMinute}/min)`,
      };
    }

    win.count++;
    return { allowed: true, status: 200, record };
  }

  listTokens(): Array<Omit<ApiTokenRecord, 'token'> & { tokenPreview: string }> {
    return Array.from(this.tokens.values()).map((r) => ({
      name: r.name,
      scopes: r.scopes,
      rateLimitPerMinute: r.rateLimitPerMinute,
      createdAt: r.createdAt,
      tokenPreview: `${r.token.slice(0, 7)}...${r.token.slice(-4)}`,
    }));
  }
}

export const apiTokenGate = new ApiTokenGate();

export function createApiV1Router(): express.Router {
  const router = express.Router();

  const requireScope = (scope: ApiTokenScope) => {
    return (req: Request, res: Response, next: NextFunction) => {
      const authHeader = req.headers.authorization || '';
      const token = authHeader.startsWith('Bearer ')
        ? authHeader.slice(7).trim()
        : (req.headers['x-bax-token'] as string) || 'bax_default_local_token';

      const check = apiTokenGate.verifyAndConsume(token, scope);
      if (!check.allowed) {
        res.status(check.status).json({ error: check.error });
        return;
      }
      next();
    };
  };

  // Token management
  router.post('/tokens', requireScope('admin'), (req, res) => {
    const { name, scopes, rateLimitPerMinute, token } = req.body || {};
    const created = apiTokenGate.registerToken({
      token,
      name: name || 'API Token',
      scopes: Array.isArray(scopes) && scopes.length > 0 ? scopes : ['chat'],
      rateLimitPerMinute,
    });
    res.json(created);
  });

  router.get('/tokens', requireScope('admin'), (_req, res) => {
    res.json({ tokens: apiTokenGate.listTokens() });
  });

  // Headless Chat Endpoint with identical SSE event contract & gear inference
  router.post('/chat', requireScope('chat'), async (req, res) => {
    const {
      messages = [],
      conversationId = 'headless_default',
      stream = true,
      redteam = false,
    } = req.body || {};

    const lastMsg = messages[messages.length - 1]?.content || '';
    const isRedteamCommand = redteam || /^\s*\/redteam\b/i.test(lastMsg);

    const gearState = await evaluateTurnGearing(conversationId, lastMsg);

    let responseText = '';
    if (isRedteamCommand) {
      const report = runRedTeamAudit([{ path: 'input.ts', content: lastMsg }]);
      responseText =
        report.findings.length > 0
          ? report.findings
              .map(
                (f) =>
                  `[${f.severity.toUpperCase()}] ${f.citation} — ${f.title}\nTrigger: ${f.exploitScenario}`
              )
              .join('\n\n')
          : 'No vulnerabilities matched static heuristic rules.';
    } else if (gearState.isConversationalFloor) {
      responseText = 'Got it.';
    } else {
      const cleaned = stripResponse(
        `Processed request in ${gearState.gear} gear (${gearState.register} register): ${lastMsg.slice(0, 240)}`,
        true,
        gearState.gear
      );
      responseText = cleaned.cleaned;
    }

    // Record deterministic replay snapshot
    const turnId = `turn_${Date.now()}`;
    const snap = replayStore.recordTurn({
      turnId,
      conversationId,
      seed: 42,
      model: 'apex-mesh-v1',
      params: {
        temperature: 0.2,
        topP: 0.95,
        mode: 'APEX',
        gear: gearState.gear,
        rung: 0,
      },
      prompt: lastMsg,
      context: JSON.stringify(messages),
      output: responseText,
    });

    if (!stream) {
      res.json({
        id: turnId,
        conversationId,
        gear: gearState.gear,
        register: gearState.register,
        hideGlyphs: gearState.hideGlyphs,
        content: responseText,
        replay: {
          promptHash: snap.promptHash,
          contextHash: snap.contextHash,
          seed: snap.seed,
        },
      });
      return;
    }

    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    res.write(
      `data: ${JSON.stringify({
        type: 'meta',
        turnId,
        gear: gearState.gear,
        register: gearState.register,
        hideGlyphs: gearState.hideGlyphs,
      })}\n\n`
    );

    res.write(
      `data: ${JSON.stringify({
        type: 'delta',
        content: responseText,
      })}\n\n`
    );

    res.write(
      `data: ${JSON.stringify({
        type: 'done',
        turnId,
        promptHash: snap.promptHash,
        contextHash: snap.contextHash,
      })}\n\n`
    );
    res.end();
  });

  // 24.6 Secrets Vault endpoints
  router.get('/vault', requireScope('admin'), (_req, res) => {
    res.json({
      secrets: secretsVault.listSecrets(),
      accessLog: secretsVault.getAuditLogs(),
    });
  });

  router.post('/vault', requireScope('admin'), (req, res) => {
    const { name, value, scope, hostPattern } = req.body || {};
    if (!name || !value) {
      res.status(400).json({ error: 'name and value are required' });
      return;
    }
    const meta = secretsVault.setSecret(name, value, scope || 'sandbox_only', hostPattern);
    res.json({ secret: meta });
  });

  router.delete('/vault/:name', requireScope('admin'), (req, res) => {
    const deleted = secretsVault.deleteSecret(req.params.name);
    res.json({ deleted });
  });

  // 24.7 Retention Controls endpoints
  router.get('/retention', requireScope('conversations'), (req, res) => {
    const conversationId = (req.query.conversationId as string) || 'default';
    res.json(retentionManager.getConversationRetention(conversationId));
  });

  router.post('/retention', requireScope('conversations'), (req, res) => {
    const { conversationId = 'default', policy = 'keep', globalZeroRetention, zeroRetention } = req.body || {};
    if (typeof globalZeroRetention === 'boolean') {
      retentionManager.setGlobalZeroRetention(globalZeroRetention);
    }
    res.json(retentionManager.setConversationRetention(conversationId, policy, Boolean(zeroRetention)));
  });

  router.post('/retention/purge-all', requireScope('admin'), (req, res) => {
    const result = retentionManager.purgeAll(req.body?.confirmation || '');
    if (!result.success) {
      res.status(400).json({ error: result.error });
      return;
    }
    res.json(result);
  });

  // 24.5 Prompt-Injection Defense endpoint
  router.post('/security/scan-untrusted', requireScope('tools'), (req, res) => {
    const { content = '', source = 'unknown' } = req.body || {};
    const wrapped = wrapUntrustedContent(content, source);
    const scan = scanForPromptInjection(content);
    res.json({ ...wrapped, wrapped: wrapped.wrappedBlock, findings: scan.flags });
  });

  // 24.12 Deterministic Replay endpoints
  router.get('/replay/:turnId', requireScope('chat'), (req, res) => {
    const snap = replayStore.getTurnRecord(req.params.turnId);
    if (!snap) {
      res.status(404).json({ error: 'Turn snapshot not found' });
      return;
    }
    res.json({ snapshot: snap });
  });

  router.post('/replay/:turnId', requireScope('chat'), (req, res) => {
    const result = replayStore.replayTurn(req.params.turnId);
    if (!result) {
      res.status(404).json({ error: 'Turn snapshot not found' });
      return;
    }
    res.json(result);
  });

  // 24.1 Codebase Mode endpoints
  router.get('/repos', requireScope('repos'), (_req, res) => {
    res.json({ repos: codebaseManager.listWorkspaces() });
  });

  router.post('/repos/clone', requireScope('repos'), (req, res) => {
    const { id, name, sourceUrl, files } = req.body || {};
    const ws = codebaseManager.initWorkspace({
      id,
      name: name || 'workspace',
      sourceUrl,
      files,
    });
    res.json({ workspace: ws });
  });

  router.get('/repos/:repoId/file', requireScope('repos'), (req, res) => {
    try {
      const filePath = (req.query.path as string) || 'README.md';
      const line = parseInt((req.query.line as string) || '1', 10);
      const data = codebaseManager.readFileAtLine(req.params.repoId, filePath, line);
      res.json(data);
    } catch (err: any) {
      res.status(404).json({ error: err.message });
    }
  });

  router.post('/repos/:repoId/apply-hunks', requireScope('repos'), (req, res) => {
    try {
      const { diffText, hunks: rawHunks, acceptedHunkIds, commitMessage, targetBranch } = req.body || {};
      const parsedHunks = Array.isArray(rawHunks) ? rawHunks : parseUnifiedDiff(diffText || '');
      const result = codebaseManager.applyAcceptedHunks({
        repoId: req.params.repoId,
        hunks: parsedHunks,
        acceptedHunkIds: acceptedHunkIds || parsedHunks.map((h) => h.id),
        commitMessage,
        targetBranch,
      });
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  router.post('/repos/:repoId/revert', requireScope('repos'), (req, res) => {
    try {
      const result = codebaseManager.revertCommit(req.params.repoId, req.body?.commitHash || '');
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  /*
   * PATCH 01 (P7 — Delete rather than fix):
   * Commented out half-built / stubbed endpoints for:
   * - red-team mode (/redteam)
   * - spec-first threshold (/spec/evaluate)
   * - provenance ledger (/provenance/evaluate)
   * - contradiction matrix (/contradictions/ingest, /contradictions/:id/resolve)
   * - claim ledger (/corrections, /corrections/:id/accept)
   * - profiles (/profiles/switch)
   * - distillation (/threads/distill)
   *
  router.post('/redteam', requireScope('tools'), (req, res) => {
    const { files = [] } = req.body || {};
    const report = runRedTeamAudit(files);
    res.json(report);
  });

  router.post('/spec/evaluate', requireScope('chat'), (req, res) => {
    const { prompt = '', gear = 'TASK', conversationId = 'default', branchId = 'main' } = req.body || {};
    const check = shouldTriggerSpecFirst({ prompt, gear });
    let spec = specStore.getSpec(conversationId, branchId);
    if (check.triggered && !spec) {
      spec = specStore.createSpec({
        conversationId,
        branchId,
        prompt,
        gear,
        estimatedTokens: check.estimatedTokens,
      });
    }
    res.json({ ...check, spec });
  });

  router.post('/provenance/evaluate', requireScope('tools'), (req, res) => {
    res.json(evaluateProvenanceSet(req.body?.sources || []));
  });

  router.post('/contradictions/ingest', requireScope('memory'), (req, res) => {
    res.json(contradictionDetector.ingestClaim(req.body));
  });

  router.post('/contradictions/:id/resolve', requireScope('memory'), (req, res) => {
    try {
      res.json(contradictionDetector.resolveConflict(req.params.id, req.body?.choose || 'incoming'));
    } catch (err: any) {
      res.status(404).json({ error: err.message });
    }
  });

  router.post('/corrections', requireScope('memory'), (req, res) => {
    const delta = correctionCaptureManager.recordEdit(req.body);
    res.json({ delta });
  });

  router.post('/corrections/:id/accept', requireScope('memory'), (req, res) => {
    const delta = correctionCaptureManager.acceptRule(req.params.id);
    res.json({ delta, activeRules: correctionCaptureManager.listAcceptedRules() });
  });

  router.post('/profiles/switch', requireScope('admin'), (req, res) => {
    const profile = profileManager.switchProfile(req.body?.profileId || 'default');
    res.json({ activeProfileId: profile.id, name: profile.name });
  });

  router.post('/threads/distill', requireScope('conversations'), (req, res) => {
    const jsonl = distillThreadToJSONL(req.body?.messages || []);
    res.json({ jsonl });
  });
  */

  router.post('/blind-ab/session', requireScope('chat'), (req, res) => {
    res.json(blindABEloManager.createSession(req.body));
  });

  router.post('/blind-ab/:id/pick', requireScope('chat'), (req, res) => {
    res.json(blindABEloManager.recordPick(req.params.id, req.body?.pick || 'A'));
  });

  router.post('/local-only', requireScope('admin'), (req, res) => {
    localOnlyGuard.setLocalOnly(Boolean(req.body?.enabled));
    res.json({
      localOnly: localOnlyGuard.isLocalOnly(),
      remoteRequestsCount: localOnlyGuard.getRemoteRequestCount(),
    });
  });

  router.post('/sync/encrypt', requireScope('admin'), (req, res) => {
    const { payload, passphrase } = req.body || {};
    res.json(encryptSyncBlob(payload, passphrase || 'default-passphrase'));
  });

  router.post('/sync/decrypt', requireScope('admin'), (req, res) => {
    const { blob, passphrase } = req.body || {};
    res.json({ payload: decryptSyncBlob(blob, passphrase || 'default-passphrase') });
  });

  router.post('/artifacts/publish', requireScope('artifacts'), (req, res) => {
    const page = publishedArtifactStore.publish(req.body);
    res.json({ page, url: `/published/${page.id}` });
  });

  // Export endpoint for `bax export`
  router.get('/export/:conversationId', requireScope('conversations'), (req, res) => {
    res.json({
      conversationId: req.params.conversationId,
      exportedAt: new Date().toISOString(),
      format: 'json',
    });
  });

  // TDD helper endpoint
  router.post('/tdd/run', requireScope('tools'), async (req, res) => {
    const { testCode = '', initialImplementation = '' } = req.body || {};
    const summary = await executeTDDLoop({
      testCode,
      initialImplementation,
      runHarness: async (_t, impl) => ({
        passed: impl.includes('PASS_IMPL'),
        exitCode: impl.includes('PASS_IMPL') ? 0 : 1,
        stdout: impl.includes('PASS_IMPL') ? 'ok 1 - all assertions passed' : 'not ok 1 - assertion failed',
        stderr: '',
        durationMs: 12,
      }),
      iterateImplementation: async ({ currentCode }) => `${currentCode}\n// PASS_IMPL`,
    });
    res.json(summary);
  });

  return router;
}
