/**
 * Black Apex OS — Section 24.6 Secrets Vault
 *
 * - Named secrets stored encrypted with APP_SECRET (AES-256-GCM), listed in settings,
 *   never rendered back in full after save.
 * - Referenced in prompts as {{secret:NAME}}; resolved at sandbox runtime into env vars,
 *   never injected into LLM context or transcript.
 * - Optional per-secret scope: 'sandbox_only' | 'outbound_http' with host pattern.
 * - Vault access is logged per use with the conversation id.
 */

import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { getEnv } from './env';

export type SecretScope = 'sandbox_only' | 'outbound_http';

export interface VaultEntryRecord {
  name: string;
  encryptedValue: string;
  iv: string;
  authTag: string;
  scope: SecretScope;
  hostPattern?: string;
  maskedPreview: string;
  createdAt: string;
  updatedAt: string;
}

export interface VaultAuditLog {
  id: string;
  secretName: string;
  conversationId: string;
  context: 'sandbox_env' | 'outbound_http';
  timestamp: string;
}

interface VaultData {
  secrets: Record<string, VaultEntryRecord>;
  auditLogs: VaultAuditLog[];
}

function getVaultKey(): Buffer {
  const env = getEnv();
  return crypto.scryptSync(env.APP_SECRET || 'black-apex-vault-default-secret', 'apex-vault-salt', 32);
}

export function encryptVaultSecret(plainValue: string): { encryptedValue: string; iv: string; authTag: string } {
  const key = getVaultKey();
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  let encrypted = cipher.update(plainValue, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  return { encryptedValue: encrypted, iv: iv.toString('hex'), authTag };
}

export function decryptVaultSecret(encryptedValue: string, ivHex: string, authTagHex: string): string {
  const key = getVaultKey();
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(authTagHex, 'hex'));
  let decrypted = decipher.update(encryptedValue, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

class SecretsVault {
  private filePath: string;
  private data: VaultData = { secrets: {}, auditLogs: [] };

  constructor() {
    const env = getEnv();
    const dataDir = path.resolve(process.cwd(), env.STORAGE_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    this.filePath = path.join(dataDir, 'vault.json');
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(this.filePath)) {
        this.data = JSON.parse(fs.readFileSync(this.filePath, 'utf-8'));
      }
    } catch {
      this.data = { secrets: {}, auditLogs: [] };
    }
  }

  private persist() {
    try {
      fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch {}
  }

  public setSecret(
    name: string,
    plainValue: string,
    scope: SecretScope = 'sandbox_only',
    hostPattern?: string
  ): Omit<VaultEntryRecord, 'encryptedValue' | 'iv' | 'authTag'> {
    const cleanName = name.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_');
    const { encryptedValue, iv, authTag } = encryptVaultSecret(plainValue);
    const maskedPreview =
      plainValue.length > 6
        ? `${plainValue.slice(0, 2)}••••••${plainValue.slice(-2)}`
        : '••••••••';

    const now = new Date().toISOString();
    const entry: VaultEntryRecord = {
      name: cleanName,
      encryptedValue,
      iv,
      authTag,
      scope,
      hostPattern,
      maskedPreview,
      createdAt: this.data.secrets[cleanName]?.createdAt || now,
      updatedAt: now,
    };

    this.data.secrets[cleanName] = entry;
    this.persist();

    return {
      name: entry.name,
      scope: entry.scope,
      hostPattern: entry.hostPattern,
      maskedPreview: entry.maskedPreview,
      createdAt: entry.createdAt,
      updatedAt: entry.updatedAt,
    };
  }

  public listSecrets(): Omit<VaultEntryRecord, 'encryptedValue' | 'iv' | 'authTag'>[] {
    return Object.values(this.data.secrets).map((s) => ({
      name: s.name,
      scope: s.scope,
      hostPattern: s.hostPattern,
      maskedPreview: s.maskedPreview,
      createdAt: s.createdAt,
      updatedAt: s.updatedAt,
    }));
  }

  public deleteSecret(name: string): boolean {
    const cleanName = name.trim().toUpperCase();
    if (this.data.secrets[cleanName]) {
      delete this.data.secrets[cleanName];
      this.persist();
      return true;
    }
    return false;
  }

  /**
   * Resolves {{secret:NAME}} references into sandbox environment variables
   * while keeping {{secret:NAME}} placeholders intact in context/transcript.
   * Logs every access with conversationId.
   */
  public resolveForSandbox(
    codeOrPrompt: string,
    conversationId: string
  ): { envVars: Record<string, string>; sanitizedCode: string; resolvedNames: string[] } {
    const envVars: Record<string, string> = {};
    const resolvedNames: string[] = [];

    const sanitizedCode = codeOrPrompt.replace(/\{\{secret:([A-Za-z0-9_]+)\}\}/g, (_match, rawName) => {
      const name = rawName.toUpperCase();
      const entry = this.data.secrets[name];
      if (entry) {
        try {
          const decrypted = decryptVaultSecret(entry.encryptedValue, entry.iv, entry.authTag);
          envVars[name] = decrypted;
          resolvedNames.push(name);
          this.logAccess(name, conversationId, 'sandbox_env');
        } catch {}
      }
      // Replace {{secret:NAME}} in executed code with process.env.NAME / os.environ["NAME"] value from env
      return envVars[name] ?? '';
    });

    return { envVars, sanitizedCode, resolvedNames };
  }

  /**
   * Resolves outbound HTTP header secrets for matching host patterns
   */
  public resolveForHost(urlStr: string, conversationId: string): Record<string, string> {
    const headers: Record<string, string> = {};
    try {
      const u = new URL(urlStr);
      for (const entry of Object.values(this.data.secrets)) {
        if (entry.scope === 'outbound_http' && entry.hostPattern) {
          if (u.hostname === entry.hostPattern || u.hostname.endsWith('.' + entry.hostPattern)) {
            const val = decryptVaultSecret(entry.encryptedValue, entry.iv, entry.authTag);
            headers[`X-Vault-${entry.name}`] = val;
            this.logAccess(entry.name, conversationId, 'outbound_http');
          }
        }
      }
    } catch {}
    return headers;
  }

  private logAccess(secretName: string, conversationId: string, context: 'sandbox_env' | 'outbound_http') {
    this.data.auditLogs.push({
      id: `audit-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      secretName,
      conversationId,
      context,
      timestamp: new Date().toISOString(),
    });
    this.persist();
  }

  public getAuditLogs(conversationId?: string): VaultAuditLog[] {
    if (conversationId) {
      return this.data.auditLogs.filter((l) => l.conversationId === conversationId);
    }
    return this.data.auditLogs;
  }
}

let vaultInstance: SecretsVault | null = null;

export { SecretsVault };

export function getSecretsVault(): SecretsVault {
  if (!vaultInstance) {
    vaultInstance = new SecretsVault();
  }
  return vaultInstance;
}

export const secretsVault = getSecretsVault();
