import fs from 'fs';
import path from 'path';
import { getEnv } from './env';

const PREFIXES = [
  'PHANTOM', 'VOID', 'NEXUS', 'AEGIS', 'SOLAR',
  'CHRONOS', 'KINETIC', 'SPECTER', 'VALENCE', 'ZERO',
  'PULSE', 'VORTEX', 'SYNAPSE', 'ECHO', 'CYPHER'
];

interface CodenamesTable {
  [providerKey: string]: string;
}

let tableCache: CodenamesTable | null = null;

function getStorePath(): string {
  const env = getEnv();
  const dir = path.resolve(process.cwd(), env.STORAGE_PATH);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  return path.join(dir, 'provider-codenames.json');
}

export function getProviderCodename(provider: string): string {
  if (!tableCache) {
    const storePath = getStorePath();
    if (fs.existsSync(storePath)) {
      try {
        tableCache = JSON.parse(fs.readFileSync(storePath, 'utf-8'));
      } catch {
        tableCache = {};
      }
    } else {
      tableCache = {};
    }
  }

  if (tableCache && tableCache[provider]) {
    return tableCache[provider];
  }

  // Generate a random unique codename for this provider
  const used = Object.values(tableCache || {});
  let codename = '';
  for (let attempt = 0; attempt < 50; attempt++) {
    const pfx = PREFIXES[Math.floor(Math.random() * PREFIXES.length)];
    const num = Math.floor(Math.random() * 90) + 10;
    const cand = `${pfx}-${num}`;
    if (!used.includes(cand)) {
      codename = cand;
      break;
    }
  }
  if (!codename) {
    codename = `UNIT-${Math.floor(Math.random() * 900) + 100}`;
  }

  tableCache = tableCache || {};
  tableCache[provider] = codename;

  try {
    const storePath = getStorePath();
    fs.writeFileSync(storePath, JSON.stringify(tableCache, null, 2), 'utf-8');
  } catch (err) {
    console.error('Failed to persist codenames table', err);
  }

  return codename;
}
