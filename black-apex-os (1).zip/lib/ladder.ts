import {
  streamGemini,
  streamGroq,
  streamOpenRouter,
  streamLocal,
  classifyHedgeGroq,
  generateNextStepChips,
  ChatMessage,
  GroundingSource,
} from './mesh';
import { assembleSystemPrompt } from './prompts';
import { detectTier1 } from './detector';
import { stripResponse } from './stripper';
import { getProviderCodename } from './codenames';
import { getDb, MessageReceipt } from './db';
import { log } from './logger';
import { getEnv } from './env';

export interface SSEEmitter {
  emit: (event: string, data: any) => void;
}

export interface LadderOptions {
  conversationId: string;
  messages: ChatMessage[];
  mode?: 'APEX' | 'LONE' | 'BRUTAL' | 'RAW';
  persona?: string;
  customInstructions?: string[];
  memoryFacts?: string[];
  stripperEnabled?: boolean;
  forcedRung?: number;
  webSearch?: boolean;
  attachmentCount?: number;
  attachmentNames?: string[];
  hasOpenArtifact?: boolean;
  emitter: SSEEmitter;
  quotaManager?: FreeQuotaManager;
  cacheHierarchy?: FreeCacheHierarchy;
  coalescer?: RequestCoalescer;
  localStreamImpl?: (params: any) => Promise<string>;
  bypassCache?: boolean;
}

export interface LadderResult {
  finalText: string;
  rawText: string;
  winningRung: number;
  receipts: MessageReceipt[];
  chips: string[];
  groundingSources?: GroundingSource[];
  webSearchUsed?: boolean;
  gear: GearLevel;
  register: RegisterTone;
  hideGlyphs: boolean;
  cached?: boolean;
}

import { resolveDocGrounding } from './docGrounding';
import { selectBestOfN } from './scorer';
import { runAdversarialCriticPass } from './critic';
import { detectAndStripContinuationOffer } from './autoContinue';
import {
  evaluateTurnGearing,
  checkDynamicGearUpgrade,
  GearLevel,
  RegisterTone,
} from './gearing';
import {
  FreeQuotaManager,
  FreeCacheHierarchy,
  RequestCoalescer,
  defaultFreeQuotaManager,
  defaultFreeCacheHierarchy,
  defaultRequestCoalescer,
} from './freeMode';
import { defaultDiagStore } from './diag';

export interface CompactionOptions {
  maxTotalChars?: number;
  maxRecentMessages?: number;
  maxHistoricalMsgChars?: number;
  maxLatestMsgChars?: number;
}

/**
 * Compacts long-term conversation histories and oversized messages so prefill
 * token counts and TTFT remain fast and constant regardless of thread length.
 * Preserves the initial anchor message, compacted middle digest (if truncated),
 * recent turns, and the latest user prompt.
 */
export function compactConversationHistory(
  messages: ChatMessage[],
  options?: CompactionOptions
): ChatMessage[] {
  if (!Array.isArray(messages) || messages.length === 0) return [];

  const maxTotalChars = options?.maxTotalChars ?? 28000;
  const maxRecentMessages = options?.maxRecentMessages ?? 16;
  const maxHistoricalMsgChars = options?.maxHistoricalMsgChars ?? 3000;
  const maxLatestMsgChars = options?.maxLatestMsgChars ?? 16000;

  const compressSingle = (content: string, limit: number): string => {
    const text = content || '';
    if (text.length <= limit) return text;
    const headLen = Math.floor(limit * 0.6);
    const tailLen = Math.floor(limit * 0.35);
    return `${text.slice(0, headLen)}\n...[segment compacted (${text.length - headLen - tailLen} chars omitted)]...\n${text.slice(-tailLen)}`;
  };

  if (messages.length === 1) {
    return [
      {
        role: messages[0].role,
        content: compressSingle(messages[0].content, maxLatestMsgChars),
      },
    ];
  }

  const latestIdx = messages.length - 1;
  const latestMsg: ChatMessage = {
    role: messages[latestIdx].role,
    content: compressSingle(messages[latestIdx].content, maxLatestMsgChars),
  };

  let charBudget = maxTotalChars - latestMsg.content.length;
  const selectedRecent: ChatMessage[] = [];

  const startRecentIdx = Math.max(0, latestIdx - maxRecentMessages);
  for (let i = latestIdx - 1; i >= startRecentIdx; i--) {
    const msg = messages[i];
    const compactedContent = compressSingle(msg.content, maxHistoricalMsgChars);
    if (charBudget - compactedContent.length < 0 && selectedRecent.length >= 2) {
      break;
    }
    charBudget -= compactedContent.length;
    selectedRecent.unshift({ role: msg.role, content: compactedContent });
  }

  const earliestIncludedIdx = latestIdx - selectedRecent.length;
  if (earliestIncludedIdx > 0) {
    const anchorMsg = messages[0];
    const anchorSnippet = compressSingle(anchorMsg.content, 600);
    const omittedCount = earliestIncludedIdx;
    const digestNote: ChatMessage = {
      role: 'user',
      content: `[Conversation Anchor — ${omittedCount} earlier message(s) compacted. Initial topic: ${anchorSnippet}]`,
    };
    return [digestNote, ...selectedRecent, latestMsg];
  }

  return [...selectedRecent, latestMsg];
}

export async function runRepairLadder(options: LadderOptions): Promise<LadderResult> {
  const {
    conversationId,
    messages,
    mode = 'APEX',
    persona,
    customInstructions,
    memoryFacts,
    stripperEnabled = true,
    forcedRung,
    webSearch = false,
    attachmentCount = 0,
    attachmentNames = [],
    hasOpenArtifact = false,
    emitter,
    quotaManager = defaultFreeQuotaManager,
    cacheHierarchy = defaultFreeCacheHierarchy,
    coalescer = defaultRequestCoalescer,
    localStreamImpl,
    bypassCache = false,
  } = options;

  const db = getDb();
  const env = getEnv();
  const turnStartMs = Date.now();
  const turnId = `turn-${turnStartMs}-${Math.random().toString(36).slice(2, 7)}`;
  defaultDiagStore.beginTurnTracking(turnId);

  const compactedMessages = compactConversationHistory(messages);
  const userPrompt = compactedMessages[compactedMessages.length - 1]?.content || '';
  const webSearchActive = Boolean(
    webSearch || userPrompt.trim().toLowerCase().startsWith('/search ')
  );
  const tokensIn = Math.max(
    1,
    Math.ceil(compactedMessages.reduce((acc, m) => acc + (m.content?.length || 0), 0) / 4)
  );
  const priorStateString = compactedMessages
    .slice(0, -1)
    .map((m) => `${m.role}:${m.content}`)
    .join('\n');

  // Section 32.4: Check Layer 1 (Exact) & Layer 2 (Semantic >= 0.95) cache before hitting providers
  if (!bypassCache && !webSearchActive && forcedRung === undefined && userPrompt.trim().length > 0) {
    const cacheLookup = cacheHierarchy.lookupPrompt(priorStateString, userPrompt);
    if (cacheLookup.hit && cacheLookup.answer) {
      const cachedReceipt: MessageReceipt = {
        rung: cacheLookup.winningRung ?? 0,
        providerCodename: getProviderCodename('local'),
        latencyMs: 1,
        hedged: false,
        modelTier: 'cache',
        draftSnippet: cacheLookup.answer.slice(0, 150),
        timestamp: new Date().toISOString(),
        cached: true,
      };
      emitter.emit('token', { text: cacheLookup.answer, rung: cachedReceipt.rung });
      emitter.emit('done', {
        text: cacheLookup.answer,
        rawText: cacheLookup.answer,
        winningRung: cachedReceipt.rung,
        receipts: [cachedReceipt],
        chips: [],
        gear: 'CHAT',
        register: 'NEUTRAL',
        hideGlyphs: false,
        cached: true,
      });
      defaultDiagStore.recordTurnTelemetry({
        turnId,
        conversationId,
        promptPreview: userPrompt.slice(0, 80),
        gear: 'CHAT',
        rungReached: cachedReceipt.rung,
        totalUpstreamRequests: 0,
        upstreamCalls: [],
        ttftMs: 1,
        totalMs: Math.max(1, Date.now() - turnStartMs),
        tokensIn,
        tokensOut: Math.ceil(cacheLookup.answer.length / 4),
        outcome: 'cached',
        timestamp: new Date().toISOString(),
      });
      return {
        finalText: cacheLookup.answer,
        rawText: cacheLookup.answer,
        winningRung: cachedReceipt.rung,
        receipts: [cachedReceipt],
        chips: [],
        gear: 'CHAT',
        register: 'NEUTRAL',
        hideGlyphs: false,
        cached: true,
      };
    }
  }

  // PATCH 01 (P2 & P3.3): Deterministic gear evaluation first so CHAT turns make 0 extra classifier calls
  const existingArtifacts = db.getArtifacts(conversationId);
  const turnGearing = await evaluateTurnGearing(conversationId, userPrompt, {
    attachmentCount,
    attachmentNames,
    hasOpenArtifact: hasOpenArtifact || existingArtifacts.length > 0,
    useGroqClassifier: false,
  });

  let activeGear: GearLevel = turnGearing.gear;
  let generationParams = { ...turnGearing.generationParams };
  const register: RegisterTone = turnGearing.register;
  const isConversationalFloor = turnGearing.isConversationalFloor;

  // Section 32.8 & P3.2: Evaluate degraded modes & THIN profile
  let localReady = Boolean(localStreamImpl) || quotaManager.isLocalAvailable();
  const degraded = quotaManager.evaluateDegradedMode();
  if (!localReady) {
    generationParams.bestOfN = 1;
    if (activeGear === 'DEEP') {
      activeGear = 'HEAVY';
    }
  }
  if (!degraded.bestOfNAllowed || !defaultDiagStore.getAggregateMetrics().autoGating.bestOfNAllowedByTelemetry) {
    generationParams.bestOfN = 1;
  }

  // P2: Doc grounding only in TASK+ when enabled AND (lockfile present or user names a version)
  const groundedDoc =
    isConversationalFloor || activeGear === 'CHAT' || !generationParams.enableDocGrounding
      ? null
      : await resolveDocGrounding(userPrompt).catch(() => null);

  // PATCH 01 (P2): Ladder starts at rung 0 ALWAYS (unless explicitly forced via manual hedge button)
  let currentRung = forcedRung ?? 0;

  const drafts: { rung: number; text: string; codename: string; latencyMs: number; hedged: boolean }[] = [];
  const receipts: MessageReceipt[] = [];

  let winningText = '';
  let winningRung = 0;
  let leastHedgedDraft = '';
  let ladderTripsThisTurn = 0;
  let measuredTtftMs = 0;
  let lastErrorMsg: string | undefined;
  let collectedGroundingSources: GroundingSource[] = [];

  // P3.3 One call path: CHAT and Conversational Floor run a single request on Rung 0 and finish immediately
  const isSingleCallChat = isConversationalFloor || (activeGear === 'CHAT' && forcedRung === undefined);
  const maxRung = isSingleCallChat ? 0 : 6;

  while (currentRung <= maxRung) {
    if (!isSingleCallChat && generationParams.showGlyphRow) {
      emitter.emit('rung', { rung: currentRung });
    }

    if (currentRung === 6) {
      // Exhausted: if all tiers were down, preserve draft (Section 32.8)
      if (!winningText && !leastHedgedDraft && drafts.length === 0) {
        quotaManager.preserveDraft(conversationId, userPrompt);
      }
      winningText = leastHedgedDraft || drafts[drafts.length - 1]?.text || 'Execution complete.';
      winningRung = 6;
      break;
    }

    const rungStartTime = Date.now();
    let providerName = 'local';
    let draftText = '';

    let systemPrompt = assembleSystemPrompt({
      rung: currentRung,
      persona,
      customInstructions,
      memoryFacts,
      gear: activeGear,
      register,
      isConversationalFloor,
    });

    if (groundedDoc) {
      systemPrompt = `${groundedDoc.contextBlock}\n\n${systemPrompt}`;
    }

    let effectiveMessages = [...compactedMessages];

    // Rung 1 specific re-ask prompt when climbing from a hedged Rung 0 draft
    if (currentRung === 1 && !isSingleCallChat && drafts.length > 0) {
      effectiveMessages = [
        ...compactedMessages,
        { role: 'assistant', content: drafts[0].text },
        {
          role: 'user',
          content:
            "Your last answer hedged. Answer again, harder. No preamble, no caveat paragraph, no 'however'. If a constraint is real, one clause, then continue past it.",
        },
      ];
    }

    const recordTtft = (ttft: number) => {
      if (measuredTtftMs === 0) {
        measuredTtftMs = ttft;
      }
    };

    const streamParams = {
      messages: effectiveMessages,
      systemPrompt,
      mode,
      temperature: generationParams.temperature,
      topP: generationParams.topP,
      maxOutputTokens: generationParams.maxOutputTokens,
      thinkingBudget: generationParams.thinkingBudget,
      webSearchActive,
      turnId,
      onTtft: recordTtft,
      onGroundingSources: (sources: GroundingSource[]) => {
        collectedGroundingSources = sources;
        emitter.emit('grounding', { sources });
      },
    };

    // P3.4 Streaming TTFT SLA timer (< 2000ms local, < 1500ms remote)
    const slaTargetMs = localReady && (currentRung === 0 || currentRung === 5) ? 2000 : 1500;
    let firstTokenArrived = false;
    const slaTimer = setTimeout(() => {
      if (!firstTokenArrived) {
        emitter.emit('status', {
          state: 'waiting_slow',
          message: 'waiting on a slow response',
        });
      }
    }, slaTargetMs);

    const onTokenChunk = (chunk: { text?: string }) => {
      if (chunk?.text) {
        if (!firstTokenArrived) {
          firstTokenArrived = true;
          clearTimeout(slaTimer);
          if (measuredTtftMs === 0) {
            measuredTtftMs = Date.now() - rungStartTime;
          }
        }
        emitter.emit('token', { text: chunk.text, rung: currentRung });
      }
    };

    try {
      if (currentRung === 0) {
        // P3.2: If localReady (FULL profile) and not using live Google Search grounding, use local at Rung 0.
        let ranLocal = false;
        if (localReady && !webSearchActive) {
          try {
            providerName = 'local';
            const localFn = localStreamImpl || streamLocal;
            draftText = await localFn({
              ...streamParams,
              onChunk: onTokenChunk,
            });
            quotaManager.recordUsage('local', Math.ceil(draftText.length / 4));
            ranLocal = true;
          } catch {
            localReady = false;
            quotaManager.setLocalStatus(false, false);
          }
        }
        if (!ranLocal) {
          // THIN profile (remote-only): Rung 0 uses primary remote tier (or skips if <15% quota)
          if (
            quotaManager.getProviderSummary('gemini').configured &&
            quotaManager.shouldSkipProviderRung('gemini')
          ) {
            clearTimeout(slaTimer);
            if (isSingleCallChat) {
              // Single-call CHAT falls back to Groq in 1 call if Gemini is skipped
              providerName = 'groq';
              draftText = await streamGroq({
                ...streamParams,
                onChunk: onTokenChunk,
              });
              quotaManager.recordUsage('groq', Math.ceil(draftText.length / 4));
            } else {
              currentRung = 2;
              continue;
            }
          } else {
            providerName = 'gemini';
            draftText = await streamGemini({
              ...streamParams,
              onChunk: onTokenChunk,
            });
            quotaManager.recordUsage('gemini', Math.ceil(draftText.length / 4));
          }
        }
      } else if (currentRung === 1 || currentRung === 3) {
        if (
          quotaManager.getProviderSummary('gemini').configured &&
          quotaManager.shouldSkipProviderRung('gemini')
        ) {
          clearTimeout(slaTimer);
          currentRung++;
          continue;
        }
        providerName = 'gemini';
        draftText = await streamGemini({
          ...streamParams,
          onChunk: onTokenChunk,
        });
        quotaManager.recordUsage('gemini', Math.ceil(draftText.length / 4));
      } else if (currentRung === 2) {
        if (
          quotaManager.getProviderSummary('groq').configured &&
          quotaManager.shouldSkipProviderRung('groq')
        ) {
          clearTimeout(slaTimer);
          currentRung++;
          continue;
        }
        providerName = 'groq';
        draftText = await streamGroq({
          ...streamParams,
          onChunk: onTokenChunk,
        });
        quotaManager.recordUsage('groq', Math.ceil(draftText.length / 4));
      } else if (currentRung === 4) {
        if (
          quotaManager.getProviderSummary('openrouter').configured &&
          quotaManager.shouldSkipProviderRung('openrouter')
        ) {
          clearTimeout(slaTimer);
          currentRung++;
          continue;
        }
        providerName = 'openrouter';
        draftText = await streamOpenRouter({
          ...streamParams,
          onChunk: onTokenChunk,
        });
        quotaManager.recordUsage('openrouter', Math.ceil(draftText.length / 4));
      } else if (currentRung === 5) {
        if (localReady) {
          providerName = 'local';
          const localFn = localStreamImpl || streamLocal;
          draftText = await localFn({
            ...streamParams,
            onChunk: onTokenChunk,
          });
          quotaManager.recordUsage('local', Math.ceil(draftText.length / 4));
        } else {
          // P3.2 THIN profile: local rung 5 removed from ladder
          clearTimeout(slaTimer);
          currentRung++;
          continue;
        }
      }
      clearTimeout(slaTimer);
    } catch (err: any) {
      clearTimeout(slaTimer);
      lastErrorMsg = err?.message || 'Upstream provider error';
      log({
        level: 'warn',
        provider: providerName,
        rung: currentRung,
        message: `Provider turn failed: ${lastErrorMsg}`,
      });
      if (isSingleCallChat) {
        try {
          providerName = 'groq';
          draftText = await streamGroq({
            ...streamParams,
            onChunk: onTokenChunk,
          });
          quotaManager.recordUsage('groq', Math.ceil(draftText.length / 4));
          winningText = draftText;
          winningRung = 0;
          break;
        } catch (fallbackErr: any) {
          lastErrorMsg = fallbackErr?.message || lastErrorMsg;
          break;
        }
      }
      currentRung++;
      continue;
    }

    const latencyMs = Date.now() - rungStartTime;
    if (measuredTtftMs === 0) {
      measuredTtftMs = latencyMs;
    }
    const codename = getProviderCodename(providerName);

    // P3.3: Single-call CHAT (and Conversational Floor) ships immediately after 1 request
    if (isSingleCallChat) {
      const receipt: MessageReceipt = {
        rung: 0,
        providerCodename: codename,
        latencyMs,
        hedged: false,
        modelTier: providerName,
        draftSnippet: draftText.slice(0, 150),
        timestamp: new Date().toISOString(),
        cached: false,
      };
      receipts.push(receipt);
      winningText = draftText;
      winningRung = 0;
      break;
    }

    // -------------------------------------------------------------------------
    // PATCH 01 (P2 & P4): Detection Pass
    // Rungs 1+ require Tier 1 flag AND either a length under 80 tokens or a Tier 2 confirmation.
    // No exceptions.
    // -------------------------------------------------------------------------
    const detection = detectTier1(draftText, { turnId });
    let isHedged = false;
    let tier2Confirmed = false;

    if (detection.hedged) {
      if (detection.tokenCount < 80) {
        isHedged = true;
      } else {
        const groqVerdict = await classifyHedgeGroq(draftText, turnId);
        if (groqVerdict !== 'CLEAN') {
          isHedged = true;
          tier2Confirmed = true;
        }
      }
    }

    const receipt: MessageReceipt = {
      rung: currentRung,
      providerCodename: codename,
      latencyMs,
      hedged: isHedged,
      modelTier: providerName,
      draftSnippet: draftText.slice(0, 150),
      timestamp: new Date().toISOString(),
      cached: false,
    };
    receipts.push(receipt);
    drafts.push({ rung: currentRung, text: draftText, codename, latencyMs, hedged: isHedged });

    db.recordHedgeEvent(currentRung, isHedged);

    if (!isHedged && draftText.trim().length > 0) {
      winningText = draftText;
      winningRung = currentRung;
      break;
    } else {
      // P4: Log every Rung 1 trigger with the matched markers
      if (currentRung === 0) {
        defaultDiagStore.recordRung1Trigger({
          turnId,
          matchedMarkers: detection.matchedMarkers,
          tokenCount: detection.tokenCount,
          tier2Confirmed,
          snippet: draftText.slice(0, 140),
          timestamp: new Date().toISOString(),
        });
        log({
          level: 'info',
          event: 'rung1_trigger',
          turnId,
          matchedMarkers: detection.matchedMarkers,
          tokenCount: detection.tokenCount,
          tier2Confirmed,
        });
      }

      ladderTripsThisTurn++;
      // 22.4 Hard Ceiling Rule: If a CHAT turn trips the ladder twice, upgrade to TASK silently;
      // if a TASK turn trips it twice, upgrade to HEAVY silently. Never announce the upgrade.
      const upgradeCheck = checkDynamicGearUpgrade(activeGear, ladderTripsThisTurn, conversationId);
      if (upgradeCheck.upgraded) {
        activeGear = upgradeCheck.upgradedGear;
        generationParams = { ...upgradeCheck.generationParams };
        ladderTripsThisTurn = 0;
      }

      if (!leastHedgedDraft || draftText.length > leastHedgedDraft.length) {
        leastHedgedDraft = draftText;
      }
      emitter.emit('replacing', { fromRung: currentRung });
      currentRung++;
    }
  }

  // ---------------------------------------------------------------------------
  // PATCH 01 (P2 & P6): Adversarial Critic Pass — DEEP and above only (or explicit BRUTAL mode)
  // ---------------------------------------------------------------------------
  const criticAllowed = defaultDiagStore.getAggregateMetrics().autoGating.criticAllowedByTelemetry;
  if (
    !isSingleCallChat &&
    (activeGear === 'DEEP' || mode === 'BRUTAL') &&
    generationParams.enableCritic &&
    criticAllowed &&
    winningText.length > 100
  ) {
    try {
      winningText = await runAdversarialCriticPass(winningText);
    } catch {}
  }

  // ---------------------------------------------------------------------------
  // Section 17.7: Auto-Continue (Stitch continuation offers seamlessly)
  // ---------------------------------------------------------------------------
  const contCheck = detectAndStripContinuationOffer(winningText);
  if (contCheck.hasOffer) {
    winningText = contCheck.cleanedText;
  }

  // ---------------------------------------------------------------------------
  // Section 22.8: Gear-Aware Stripper Pass
  // ---------------------------------------------------------------------------
  const rawText = winningText;
  const isStripperActive = mode !== 'RAW' && stripperEnabled;
  const { cleaned: strippedText } = stripResponse(rawText, isStripperActive, activeGear);
  const finalText = strippedText;

  // Section 32.4: Store non-empty clean answer in Layer 1 (Exact) & Layer 2 (Semantic) cache
  if (!bypassCache && finalText.trim().length > 0 && finalText !== 'Execution complete.') {
    cacheHierarchy.storePromptAnswer(priorStateString, userPrompt, finalText, winningRung);
  }

  // PATCH 01 (P2): glyph row -> TASK and above only; randomly generated follow-up chips on non-floor turns
  const hideGlyphs = isConversationalFloor || activeGear === 'CHAT';
  const visibleReceipts = hideGlyphs ? [] : receipts;

  let chips: string[] = [];
  if (mode !== 'RAW' && !isConversationalFloor && finalText.trim().length > 0) {
    chips = await generateNextStepChips(userPrompt, finalText);
    emitter.emit('chips', { chips });
  }

  const upstreamCalls = defaultDiagStore.getActiveTurnCalls(turnId);
  // If localStreamImpl was injected (e.g. unit tests) and recorded 0 fetch calls, count receipts
  const totalUpstreamRequests =
    upstreamCalls.length > 0 ? upstreamCalls.length : Math.max(1, receipts.length);
  const totalMs = Math.max(1, Date.now() - turnStartMs);
  const hitQuotaOut = degraded.mode === 'QUOTA_OUT' || degraded.mode === 'ALL_DOWN';
  const isErrorOutcome = !finalText || finalText === 'Execution complete.';

  defaultDiagStore.recordTurnTelemetry({
    turnId,
    conversationId,
    promptPreview: userPrompt.slice(0, 80),
    gear: activeGear,
    rungReached: winningRung,
    totalUpstreamRequests,
    upstreamCalls,
    ttftMs: measuredTtftMs || Math.min(totalMs, 100),
    totalMs,
    tokensIn,
    tokensOut: Math.ceil((finalText || '').length / 4),
    outcome: hitQuotaOut ? 'quota_out' : isErrorOutcome ? 'error' : 'ok',
    errorClass: hitQuotaOut ? 'QUOTA_OUT' : isErrorOutcome ? 'UPSTREAM_FAILURE' : undefined,
    errorMessage: lastErrorMsg,
    timestamp: new Date().toISOString(),
  });

  emitter.emit('done', {
    text: finalText,
    rawText,
    winningRung,
    receipts: visibleReceipts,
    chips,
    groundingSources: collectedGroundingSources,
    webSearchUsed: webSearchActive,
    gear: activeGear,
    register,
    hideGlyphs,
    cached: false,
  });

  return {
    finalText,
    rawText,
    winningRung,
    receipts: visibleReceipts,
    chips,
    groundingSources: collectedGroundingSources,
    webSearchUsed: webSearchActive,
    gear: activeGear,
    register,
    hideGlyphs,
    cached: false,
  };
}
