/**
 * Black Apex OS — PATCH 01 (P1): Live Diagnostics & Telemetry Store (/diag)
 *
 * Captures and reports live:
 * 1. Boot state: env validation result, DB, storage, local model reachable or not (THIN vs FULL profile),
 *    each provider key reachable or not (with specific disable reason on failure).
 * 2. Per-turn telemetry for the last 100 turns: gear, rungReached, totalUpstreamRequests, upstreamLog,
 *    ttftMs, totalMs, tokensIn, tokensOut, outcome, errorClass.
 * 3. Aggregate: mean requests per turn by gear, mean TTFT by gear, p95 total latency,
 *    error rate by class, quota burned today by provider, turns that hit quota-out.
 * 4. Detector stats: how often Tier 1 fires, how often Tier 2 confirms,
 *    false-positive rate on the last 50 clean answers, and Rung 1 trigger log with matched markers.
 */

import { getEnv } from './env';
import { getDb } from './db';
import { getStorage } from './storage';
import { defaultFreeQuotaManager, FreeProviderId } from './freeMode';
import { GearLevel } from './gearing';

export interface ProviderBootStatus {
  provider: FreeProviderId;
  configured: boolean;
  reachable: boolean;
  resolvedModel: string;
  disabled: boolean;
  disableReason: string | null;
  checkedAtIso: string;
}

export interface BootDiagState {
  envValidation: {
    valid: boolean;
    warnings: string[];
  };
  db: {
    ok: boolean;
    engine: string;
    path: string;
  };
  storage: {
    ok: boolean;
    engine: string;
    path: string;
  };
  profile: 'FULL' | 'THIN';
  profileNotice: string;
  localModel: {
    configured: boolean;
    reachable: boolean;
    selectedTag: string | null;
    availableTags: string[];
    reason: string;
  };
  providers: Record<FreeProviderId, ProviderBootStatus>;
}

export interface UpstreamCallRecord {
  provider: string;
  url: string;
  purpose: 'generation' | 'tier2_classifier' | 'gear_classifier' | 'chips' | 'critic' | 'doc_grounding';
  status: number;
  durationMs: number;
  timestamp: string;
}

export interface TurnTelemetryRecord {
  turnId: string;
  conversationId: string;
  promptPreview: string;
  gear: GearLevel;
  rungReached: number;
  totalUpstreamRequests: number;
  upstreamCalls: UpstreamCallRecord[];
  ttftMs: number;
  totalMs: number;
  tokensIn: number;
  tokensOut: number;
  outcome: 'ok' | 'error' | 'quota_out' | 'cached';
  errorClass?: string;
  errorMessage?: string;
  timestamp: string;
}

export interface Rung1TriggerLogEntry {
  turnId?: string;
  matchedMarkers: string[];
  tokenCount: number;
  tier2Confirmed: boolean;
  snippet: string;
  timestamp: string;
}

export interface DetectorStatsSnapshot {
  tier1Evaluations: number;
  tier1Fires: number;
  tier1FireRatePercent: number;
  tier2Evaluations: number;
  tier2Confirmations: number;
  tier2ConfirmRatePercent: number;
  cleanEvaluatedLast50Count: number;
  cleanFalsePositivesLast50: number;
  falsePositiveRateLast50Percent: number;
  rung1Triggers: Rung1TriggerLogEntry[];
}

export interface DiagAggregateMetrics {
  meanRequestsPerTurnByGear: Record<GearLevel, number>;
  meanTtftMsByGear: Record<GearLevel, number>;
  p95TotalLatencyMs: number;
  errorRateByClass: Record<string, { count: number; ratePercent: number }>;
  quotaBurnedTodayByProvider: Record<
    FreeProviderId,
    { requestsUsedToday: number; tokensUsedToday: number; remainingPercent: number }
  >;
  turnsThatHitQuotaOut: number;
  autoGating: {
    bestOfNAllowedByTelemetry: boolean;
    synthesisAllowedByTelemetry: boolean;
    criticAllowedByTelemetry: boolean;
    reason: string;
  };
}

export interface FullDiagReport {
  generatedAt: string;
  boot: BootDiagState;
  perTurnLast100: TurnTelemetryRecord[];
  aggregate: DiagAggregateMetrics;
  detector: DetectorStatsSnapshot;
}

export class DiagStore {
  private turns: TurnTelemetryRecord[] = [];
  private activeTurnCalls = new Map<string, UpstreamCallRecord[]>();

  private tier1Evaluations = 0;
  private tier1Fires = 0;
  private tier2Evaluations = 0;
  private tier2Confirmations = 0;
  // Ring buffer of last 50 clean-labeled evaluations: true = false positive (flagged on clean), false = correctly clean
  private last50CleanOutcomes: boolean[] = [];
  private rung1Triggers: Rung1TriggerLogEntry[] = [];

  private providerBootMap: Record<FreeProviderId, ProviderBootStatus> = {
    local: {
      provider: 'local',
      configured: false,
      reachable: false,
      resolvedModel: '',
      disabled: true,
      disableReason: 'Local Ollama not probed yet',
      checkedAtIso: new Date().toISOString(),
    },
    gemini: {
      provider: 'gemini',
      configured: false,
      reachable: false,
      resolvedModel: '',
      disabled: false,
      disableReason: null,
      checkedAtIso: new Date().toISOString(),
    },
    groq: {
      provider: 'groq',
      configured: false,
      reachable: false,
      resolvedModel: '',
      disabled: false,
      disableReason: null,
      checkedAtIso: new Date().toISOString(),
    },
    openrouter: {
      provider: 'openrouter',
      configured: false,
      reachable: false,
      resolvedModel: '',
      disabled: false,
      disableReason: null,
      checkedAtIso: new Date().toISOString(),
    },
  };

  private localBootDetail: BootDiagState['localModel'] = {
    configured: false,
    reachable: false,
    selectedTag: null,
    availableTags: [],
    reason: 'Local Ollama not configured — running THIN profile (remote-only).',
  };

  public setProviderBootStatus(status: ProviderBootStatus): void {
    this.providerBootMap[status.provider] = status;
  }

  public getProviderBootStatus(provider: FreeProviderId): ProviderBootStatus {
    return this.providerBootMap[provider];
  }

  public setLocalBootDetail(detail: BootDiagState['localModel']): void {
    this.localBootDetail = detail;
  }

  public getLocalBootDetail(): BootDiagState['localModel'] {
    return this.localBootDetail;
  }

  public isThinProfile(): boolean {
    return !this.localBootDetail.reachable;
  }

  public beginTurnTracking(turnId: string): void {
    this.activeTurnCalls.set(turnId, []);
  }

  public recordUpstreamCall(turnId: string | undefined, call: UpstreamCallRecord): void {
    if (!turnId) return;
    const list = this.activeTurnCalls.get(turnId) || [];
    list.push(call);
    this.activeTurnCalls.set(turnId, list);
  }

  public getActiveTurnCalls(turnId: string): UpstreamCallRecord[] {
    return this.activeTurnCalls.get(turnId) || [];
  }

  public recordTurnTelemetry(record: TurnTelemetryRecord): void {
    this.activeTurnCalls.delete(record.turnId);
    this.turns.push(record);
    if (this.turns.length > 100) {
      this.turns.shift();
    }
  }

  public recordTier1Result(params: {
    hedged: boolean;
    matchedMarkers: string[];
    tokenCount: number;
    snippet: string;
    isKnownCleanSample?: boolean;
    turnId?: string;
  }): void {
    this.tier1Evaluations += 1;
    if (params.hedged) {
      this.tier1Fires += 1;
    }
    if (params.isKnownCleanSample) {
      this.last50CleanOutcomes.push(params.hedged);
      if (this.last50CleanOutcomes.length > 50) {
        this.last50CleanOutcomes.shift();
      }
    }
  }

  public recordTier2Result(confirmed: boolean): void {
    this.tier2Evaluations += 1;
    if (confirmed) {
      this.tier2Confirmations += 1;
    }
  }

  public recordRung1Trigger(entry: Rung1TriggerLogEntry): void {
    this.rung1Triggers.push(entry);
    if (this.rung1Triggers.length > 100) {
      this.rung1Triggers.shift();
    }
  }

  public recordCleanAnswerEvaluation(flaggedAsHedge: boolean): void {
    this.last50CleanOutcomes.push(flaggedAsHedge);
    if (this.last50CleanOutcomes.length > 50) {
      this.last50CleanOutcomes.shift();
    }
  }

  public resetDetectorStatsForBenchmark(): void {
    this.tier1Evaluations = 0;
    this.tier1Fires = 0;
    this.tier2Evaluations = 0;
    this.tier2Confirmations = 0;
    this.last50CleanOutcomes = [];
    this.rung1Triggers = [];
  }

  public getBootDiagState(): BootDiagState {
    const env = getEnv();
    const warnings: string[] = [];
    if (!env.GEMINI_API_KEY) warnings.push('GEMINI_API_KEY missing');
    if (!env.GROQ_API_KEY) warnings.push('GROQ_API_KEY missing');
    if (!env.OPENROUTER_API_KEY) warnings.push('OPENROUTER_API_KEY missing');

    let dbOk = false;
    try {
      const db = getDb();
      dbOk = Array.isArray(db.getConversations());
    } catch {
      dbOk = false;
    }

    let storageOk = false;
    try {
      const st = getStorage();
      storageOk = Boolean(st);
    } catch {
      storageOk = false;
    }

    const thin = !this.localBootDetail.reachable;

    return {
      envValidation: {
        valid: warnings.length < 3,
        warnings,
      },
      db: {
        ok: dbOk,
        engine: 'durable-json-wal',
        path: env.DATABASE_PATH,
      },
      storage: {
        ok: storageOk,
        engine: 'local-fs',
        path: env.STORAGE_PATH,
      },
      profile: thin ? 'THIN' : 'FULL',
      profileNotice: thin
        ? 'THIN profile active — local model not reachable, running remote-only.'
        : `FULL profile active — local model (${this.localBootDetail.selectedTag || 'llama3'}) reachable at Rung 0.`,
      localModel: this.localBootDetail,
      providers: { ...this.providerBootMap },
    };
  }

  public getAggregateMetrics(): DiagAggregateMetrics {
    const gears: GearLevel[] = ['CHAT', 'TASK', 'HEAVY', 'DEEP'];
    const meanRequestsPerTurnByGear: Record<GearLevel, number> = {
      CHAT: 0,
      TASK: 0,
      HEAVY: 0,
      DEEP: 0,
    };
    const meanTtftMsByGear: Record<GearLevel, number> = {
      CHAT: 0,
      TASK: 0,
      HEAVY: 0,
      DEEP: 0,
    };

    for (const g of gears) {
      const matching = this.turns.filter((t) => t.gear === g && t.outcome !== 'cached');
      if (matching.length > 0) {
        const sumReq = matching.reduce((acc, t) => acc + t.totalUpstreamRequests, 0);
        const sumTtft = matching.reduce((acc, t) => acc + t.ttftMs, 0);
        meanRequestsPerTurnByGear[g] = Number((sumReq / matching.length).toFixed(2));
        meanTtftMsByGear[g] = Math.round(sumTtft / matching.length);
      }
    }

    // p95 total latency
    const sortedTotals = this.turns
      .map((t) => t.totalMs)
      .filter((n) => n >= 0)
      .sort((a, b) => a - b);
    let p95TotalLatencyMs = 0;
    if (sortedTotals.length > 0) {
      const idx = Math.min(
        sortedTotals.length - 1,
        Math.max(0, Math.ceil(sortedTotals.length * 0.95) - 1)
      );
      p95TotalLatencyMs = sortedTotals[idx];
    }

    // Error rate by class
    const totalTurns = Math.max(1, this.turns.length);
    const classCounts: Record<string, number> = {};
    for (const t of this.turns) {
      if (t.outcome === 'error' || t.outcome === 'quota_out') {
        const cls = t.errorClass || t.outcome;
        classCounts[cls] = (classCounts[cls] || 0) + 1;
      }
    }
    const errorRateByClass: Record<string, { count: number; ratePercent: number }> = {};
    for (const [cls, count] of Object.entries(classCounts)) {
      errorRateByClass[cls] = {
        count,
        ratePercent: Number(((count / totalTurns) * 100).toFixed(2)),
      };
    }

    // Quota burned today by provider
    const providers: FreeProviderId[] = ['local', 'groq', 'gemini', 'openrouter'];
    const quotaBurnedTodayByProvider = {} as DiagAggregateMetrics['quotaBurnedTodayByProvider'];
    for (const p of providers) {
      const s = defaultFreeQuotaManager.getProviderSummary(p);
      quotaBurnedTodayByProvider[p] = {
        requestsUsedToday: s.requestsUsedToday,
        tokensUsedToday: s.tokensUsedToday,
        remainingPercent: s.remainingPercent,
      };
    }

    const turnsThatHitQuotaOut = this.turns.filter((t) => t.outcome === 'quota_out').length;

    // P6 Re-enable gate: if mean requests per CHAT turn > 1.5 or quota-out occurred, auto-disable
    const chatMean = meanRequestsPerTurnByGear.CHAT;
    const withinBudget = chatMean <= 1.5 && turnsThatHitQuotaOut === 0;

    return {
      meanRequestsPerTurnByGear,
      meanTtftMsByGear,
      p95TotalLatencyMs,
      errorRateByClass,
      quotaBurnedTodayByProvider,
      turnsThatHitQuotaOut,
      autoGating: {
        bestOfNAllowedByTelemetry: withinBudget,
        synthesisAllowedByTelemetry: withinBudget,
        criticAllowedByTelemetry: withinBudget,
        reason: withinBudget
          ? 'Within telemetry budget (mean CHAT reqs <= 1.5, 0 quota-out turns).'
          : `Auto-disabled: mean CHAT reqs=${chatMean}, quotaOutTurns=${turnsThatHitQuotaOut}.`,
      },
    };
  }

  public getDetectorStats(): DetectorStatsSnapshot {
    const cleanCount = this.last50CleanOutcomes.length;
    const fpCount = this.last50CleanOutcomes.filter(Boolean).length;
    return {
      tier1Evaluations: this.tier1Evaluations,
      tier1Fires: this.tier1Fires,
      tier1FireRatePercent:
        this.tier1Evaluations > 0
          ? Number(((this.tier1Fires / this.tier1Evaluations) * 100).toFixed(2))
          : 0,
      tier2Evaluations: this.tier2Evaluations,
      tier2Confirmations: this.tier2Confirmations,
      tier2ConfirmRatePercent:
        this.tier2Evaluations > 0
          ? Number(((this.tier2Confirmations / this.tier2Evaluations) * 100).toFixed(2))
          : 0,
      cleanEvaluatedLast50Count: cleanCount,
      cleanFalsePositivesLast50: fpCount,
      falsePositiveRateLast50Percent:
        cleanCount > 0 ? Number(((fpCount / cleanCount) * 100).toFixed(2)) : 0,
      rung1Triggers: [...this.rung1Triggers],
    };
  }

  public getFullReport(): FullDiagReport {
    return {
      generatedAt: new Date().toISOString(),
      boot: this.getBootDiagState(),
      perTurnLast100: [...this.turns],
      aggregate: this.getAggregateMetrics(),
      detector: this.getDetectorStats(),
    };
  }
}

export const defaultDiagStore = new DiagStore();
