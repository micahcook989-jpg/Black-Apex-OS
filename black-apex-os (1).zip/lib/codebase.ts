import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

/**
 * Section 24.1 — Codebase Mode
 *
 * Cloned repos become real workspaces, not context blobs:
 * - Stored in `data/repos/<id>`, git-initialized, always checked out on branch `apex/work`.
 * - Never apply hunks or commits to `main`. Never push without explicit action.
 * - Index: tree walk, language detection, symbol extraction, chunked vector index.
 * - Size guards: up to 200MB total, skips `node_modules`, `.venv`, `dist`, `build`,
 *   binaries, and lockfile bodies, recording skipped paths.
 * - Unified diff parser with per-hunk accept/reject, applying accepted hunks to disk
 *   and committing to `apex/work`, plus 1-click revert per commit.
 */

export const MAX_REPO_INDEX_BYTES = 200 * 1024 * 1024; // 200MB
export const WORK_BRANCH = 'apex/work';

const SKIPPED_DIRS = new Set([
  'node_modules',
  '.venv',
  'venv',
  'dist',
  'build',
  '.git',
  '.next',
  'coverage',
  '__pycache__',
]);

const LOCKFILES = new Set([
  'package-lock.json',
  'yarn.lock',
  'pnpm-lock.yaml',
  'cargo.lock',
  'poetry.lock',
  'gemfile.lock',
  'composer.lock',
]);

const BINARY_EXTENSIONS = new Set([
  '.png', '.jpg', '.jpeg', '.gif', '.webp', '.ico', '.pdf', '.zip', '.tar',
  '.gz', '.tgz', '.wasm', '.exe', '.dll', '.so', '.dylib', '.bin', '.mp3',
  '.mp4', '.mov', '.woff', '.woff2', '.ttf', '.eot', '.sqlite', '.db',
]);

export interface RepoSymbol {
  name: string;
  kind: 'function' | 'class' | 'interface' | 'type' | 'const' | 'method';
  path: string;
  line: number;
}

export interface RepoChunk {
  id: string;
  repoId: string;
  path: string;
  startLine: number;
  endLine: number;
  language: string;
  content: string;
  tokens: string[];
}

export interface DiffHunk {
  id: string;
  filePath: string;
  oldStart: number;
  oldLines: number;
  newStart: number;
  newLines: number;
  header: string;
  lines: string[];
  status?: 'pending' | 'accepted' | 'rejected';
}

export interface RepoCommitRecord {
  hash: string;
  message: string;
  branch: string;
  timestamp: number;
  files: string[];
}

export interface RepoWorkspace {
  id: string;
  name: string;
  sourceUrl?: string;
  rootDir: string;
  branch: string;
  indexedFiles: string[];
  skippedPaths: Array<{ path: string; reason: string }>;
  totalIndexedBytes: number;
  symbols: RepoSymbol[];
  chunks: RepoChunk[];
  commits: RepoCommitRecord[];
  createdAt: number;
  updatedAt: number;
}

export function detectLanguage(filePath: string): string {
  const ext = path.extname(filePath).toLowerCase();
  const map: Record<string, string> = {
    '.ts': 'typescript',
    '.tsx': 'tsx',
    '.js': 'javascript',
    '.jsx': 'jsx',
    '.py': 'python',
    '.rs': 'rust',
    '.go': 'go',
    '.java': 'java',
    '.c': 'c',
    '.cpp': 'cpp',
    '.h': 'c-header',
    '.cs': 'csharp',
    '.rb': 'ruby',
    '.php': 'php',
    '.sql': 'sql',
    '.json': 'json',
    '.md': 'markdown',
    '.html': 'html',
    '.css': 'css',
    '.sh': 'bash',
    '.yml': 'yaml',
    '.yaml': 'yaml',
  };
  return map[ext] || 'plaintext';
}

export function extractSymbolsFromContent(relPath: string, content: string): RepoSymbol[] {
  const symbols: RepoSymbol[] = [];
  const lines = content.split('\n');

  const patterns: Array<{ regex: RegExp; kind: RepoSymbol['kind'] }> = [
    { regex: /^\s*(?:export\s+)?(?:async\s+)?function\s+([A-Za-z0-9_$]+)/, kind: 'function' },
    { regex: /^\s*(?:export\s+)?class\s+([A-Za-z0-9_$]+)/, kind: 'class' },
    { regex: /^\s*(?:export\s+)?interface\s+([A-Za-z0-9_$]+)/, kind: 'interface' },
    { regex: /^\s*(?:export\s+)?type\s+([A-Za-z0-9_$]+)\s*=/, kind: 'type' },
    { regex: /^\s*(?:export\s+)?const\s+([A-Za-z0-9_$]+)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z0-9_$]+)\s*=>/, kind: 'function' },
    { regex: /^\s*def\s+([A-Za-z0-9_]+)\s*\(/, kind: 'function' },
    { regex: /^\s*fn\s+([A-Za-z0-9_]+)\s*\(/, kind: 'function' },
    { regex: /^\s*func\s+([A-Za-z0-9_]+)\s*\(/, kind: 'function' },
  ];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    for (const { regex, kind } of patterns) {
      const m = line.match(regex);
      if (m && m[1]) {
        symbols.push({
          name: m[1],
          kind,
          path: relPath,
          line: i + 1,
        });
        break;
      }
    }
  }

  return symbols;
}

export function parseUnifiedDiff(diffText: string): DiffHunk[] {
  const hunks: DiffHunk[] = [];
  const lines = diffText.replace(/\r\n/g, '\n').split('\n');
  let currentFile = 'unknown';
  let currentHunk: DiffHunk | null = null;
  let hunkIndex = 0;

  for (const line of lines) {
    if (line.startsWith('+++ ')) {
      const rawPath = line.slice(4).trim();
      currentFile = rawPath.replace(/^[ab]\//, '');
      continue;
    }
    if (line.startsWith('--- ')) {
      continue;
    }
    const hunkMatch = line.match(/^@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@(.*)$/);
    if (hunkMatch) {
      if (currentHunk) {
        hunks.push(currentHunk);
      }
      hunkIndex++;
      currentHunk = {
        id: `hunk_${hunkIndex}`,
        filePath: currentFile,
        oldStart: parseInt(hunkMatch[1], 10),
        oldLines: hunkMatch[2] ? parseInt(hunkMatch[2], 10) : 1,
        newStart: parseInt(hunkMatch[3], 10),
        newLines: hunkMatch[4] ? parseInt(hunkMatch[4], 10) : 1,
        header: line,
        lines: [],
        status: 'pending',
      };
      continue;
    }
    if (currentHunk && (line.startsWith('+') || line.startsWith('-') || line.startsWith(' '))) {
      currentHunk.lines.push(line);
    }
  }

  if (currentHunk) {
    hunks.push(currentHunk);
  }
  return hunks;
}

export function applyHunkToContent(originalContent: string, hunk: DiffHunk): string {
  const fileLines = originalContent.length === 0 ? [] : originalContent.replace(/\r\n/g, '\n').split('\n');
  const removedOrContextLines = hunk.lines
    .filter((l) => l.startsWith(' ') || l.startsWith('-'))
    .map((l) => l.slice(1));
  const replacementLines = hunk.lines
    .filter((l) => l.startsWith(' ') || l.startsWith('+'))
    .map((l) => l.slice(1));

  // Locate target slice near oldStart (1-indexed)
  const expectedIndex = Math.max(0, hunk.oldStart - 1);

  const matchesAt = (idx: number): boolean => {
    if (removedOrContextLines.length === 0) return true;
    if (idx < 0 || idx + removedOrContextLines.length > fileLines.length) return false;
    for (let i = 0; i < removedOrContextLines.length; i++) {
      if (fileLines[idx + i] !== removedOrContextLines[i]) return false;
    }
    return true;
  };

  let targetIdx = -1;
  if (matchesAt(expectedIndex)) {
    targetIdx = expectedIndex;
  } else {
    // Search within a +/- 30 line window for fuzzy match
    for (let offset = 1; offset <= 30; offset++) {
      if (matchesAt(expectedIndex - offset)) {
        targetIdx = expectedIndex - offset;
        break;
      }
      if (matchesAt(expectedIndex + offset)) {
        targetIdx = expectedIndex + offset;
        break;
      }
    }
  }

  if (targetIdx === -1) {
    if (removedOrContextLines.length === 0) {
      // Pure addition
      const insertPos = Math.min(expectedIndex, fileLines.length);
      fileLines.splice(insertPos, 0, ...replacementLines);
      return fileLines.join('\n');
    }
    throw new Error(`Hunk ${hunk.id} could not be cleanly applied to ${hunk.filePath} at line ${hunk.oldStart}`);
  }

  fileLines.splice(targetIdx, removedOrContextLines.length, ...replacementLines);
  return fileLines.join('\n');
}

/**
 * Extracts `path:line` or `path:start-end` citations from assistant output
 */
export function extractPathLineCitations(text: string): Array<{
  raw: string;
  path: string;
  line: number;
  endLine?: number;
}> {
  const results: Array<{ raw: string; path: string; line: number; endLine?: number }> = [];
  const regex = /\b([A-Za-z0-9_./-]+\.[A-Za-z0-9]+):(\d+)(?:-(\d+))?\b/g;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(text)) !== null) {
    // Skip URLs like http://localhost:3000
    if (match[1].startsWith('http') || match[1].includes('//')) continue;
    results.push({
      raw: match[0],
      path: match[1],
      line: parseInt(match[2], 10),
      endLine: match[3] ? parseInt(match[3], 10) : undefined,
    });
  }
  return results;
}

export class CodebaseManager {
  private repos = new Map<string, RepoWorkspace>();
  private conversationRepoAttachments = new Map<string, string>(); // conversationId -> repoId
  private baseDir: string;

  constructor(baseDir = path.join(process.cwd(), 'data', 'repos')) {
    this.baseDir = baseDir;
    if (!fs.existsSync(this.baseDir)) {
      fs.mkdirSync(this.baseDir, { recursive: true });
    }
  }

  private runGit(cwd: string, args: string): string {
    return execSync(`git ${args}`, {
      cwd,
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'pipe'],
    }).trim();
  }

  /**
   * Initializes or clones a workspace in `data/repos/<id>` on branch `apex/work`.
   */
  initWorkspace(params: {
    id?: string;
    name: string;
    sourceUrl?: string;
    files?: Record<string, string>;
  }): RepoWorkspace {
    const id = (params.id || `repo_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`).replace(/[^a-zA-Z0-9_-]/g, '');
    const rootDir = path.join(this.baseDir, id);

    if (fs.existsSync(rootDir)) {
      fs.rmSync(rootDir, { recursive: true, force: true });
    }
    fs.mkdirSync(rootDir, { recursive: true });

    // Initialize git repository and ensure initial commit on main before switching to apex/work
    this.runGit(rootDir, 'init');
    this.runGit(rootDir, 'config user.name "Black Apex OS"');
    this.runGit(rootDir, 'config user.email "apex@local.workspace"');

    // Write initial seed files
    const initialFiles = params.files || {
      'README.md': `# ${params.name}\nInitialized workspace for ${params.name}.\n`,
    };

    for (const [relPath, fileContent] of Object.entries(initialFiles)) {
      const safeRel = relPath.replace(/^(\.\.(\/|\\|$))+/, '');
      const absPath = path.join(rootDir, safeRel);
      fs.mkdirSync(path.dirname(absPath), { recursive: true });
      fs.writeFileSync(absPath, fileContent, 'utf8');
    }

    this.runGit(rootDir, 'add -A');
    this.runGit(rootDir, 'commit -m "Initial workspace snapshot" --allow-empty');
    // Create and checkout branch apex/work
    this.runGit(rootDir, `checkout -B ${WORK_BRANCH}`);

    const ws: RepoWorkspace = {
      id,
      name: params.name,
      sourceUrl: params.sourceUrl,
      rootDir,
      branch: WORK_BRANCH,
      indexedFiles: [],
      skippedPaths: [],
      totalIndexedBytes: 0,
      symbols: [],
      chunks: [],
      commits: this.listGitCommits(rootDir),
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    this.repos.set(id, ws);
    this.indexWorkspace(id);
    return this.repos.get(id)!;
  }

  /**
   * Walks workspace directory, enforcing 200MB cap and skipping `node_modules`, `.venv`,
   * `dist`, `build`, binaries, and lockfile bodies, recording skipped paths.
   */
  indexWorkspace(repoId: string): RepoWorkspace {
    const ws = this.repos.get(repoId);
    if (!ws) throw new Error(`Workspace ${repoId} not found`);

    const indexedFiles: string[] = [];
    const skippedPaths: Array<{ path: string; reason: string }> = [];
    const symbols: RepoSymbol[] = [];
    const chunks: RepoChunk[] = [];
    let totalBytes = 0;

    const walk = (dir: string) => {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        const absPath = path.join(dir, entry.name);
        const relPath = path.relative(ws.rootDir, absPath).replace(/\\/g, '/');

        if (entry.isDirectory()) {
          if (entry.name === '.git') continue;
          if (SKIPPED_DIRS.has(entry.name)) {
            skippedPaths.push({ path: relPath, reason: 'excluded_directory' });
            continue;
          }
          walk(absPath);
          continue;
        }

        if (!entry.isFile()) continue;

        const lowerName = entry.name.toLowerCase();
        const ext = path.extname(lowerName);

        if (LOCKFILES.has(lowerName)) {
          skippedPaths.push({ path: relPath, reason: 'lockfile_body_skipped' });
          continue;
        }

        if (BINARY_EXTENSIONS.has(ext)) {
          skippedPaths.push({ path: relPath, reason: 'binary_extension' });
          continue;
        }

        const stat = fs.statSync(absPath);
        if (totalBytes + stat.size > MAX_REPO_INDEX_BYTES) {
          skippedPaths.push({ path: relPath, reason: 'exceeds_200mb_cap' });
          continue;
        }

        // Check for NUL bytes indicating binary content
        const buf = fs.readFileSync(absPath);
        if (buf.subarray(0, 512).includes(0)) {
          skippedPaths.push({ path: relPath, reason: 'binary_content_detected' });
          continue;
        }

        const content = buf.toString('utf8');
        totalBytes += stat.size;
        indexedFiles.push(relPath);

        // Extract symbols
        const fileSymbols = extractSymbolsFromContent(relPath, content);
        symbols.push(...fileSymbols);

        // Chunk file into 40-line segments for retrieval
        const lines = content.split('\n');
        const language = detectLanguage(relPath);
        const chunkSize = 40;
        for (let start = 0; start < lines.length; start += chunkSize) {
          const slice = lines.slice(start, start + chunkSize).join('\n');
          const tokens = Array.from(
            new Set(
              slice
                .toLowerCase()
                .split(/[^a-z0-9_]+/)
                .filter((t) => t.length >= 2)
            )
          );
          chunks.push({
            id: `${repoId}:${relPath}:${start + 1}`,
            repoId,
            path: relPath,
            startLine: start + 1,
            endLine: Math.min(lines.length, start + chunkSize),
            language,
            content: slice,
            tokens,
          });
        }
      }
    };

    walk(ws.rootDir);

    ws.indexedFiles = indexedFiles;
    ws.skippedPaths = skippedPaths;
    ws.totalIndexedBytes = totalBytes;
    ws.symbols = symbols;
    ws.chunks = chunks;
    ws.updatedAt = Date.now();
    return ws;
  }

  /**
   * Incremental re-index for a single updated/added file.
   */
  reindexFile(repoId: string, relPath: string): RepoWorkspace {
    return this.indexWorkspace(repoId);
  }

  /**
   * Retrieves top matching chunks and symbols for a query, with `path:line` references.
   */
  searchWorkspace(repoId: string, query: string, topK = 5): Array<{
    path: string;
    startLine: number;
    endLine: number;
    citation: string;
    score: number;
    snippet: string;
  }> {
    const ws = this.repos.get(repoId);
    if (!ws) return [];

    const queryTokens = query
      .toLowerCase()
      .split(/[^a-z0-9_./-]+/)
      .filter((t) => t.length >= 2);

    const scored = ws.chunks.map((chunk) => {
      let score = 0;
      for (const qt of queryTokens) {
        if (chunk.path.toLowerCase().includes(qt)) score += 3;
        if (chunk.tokens.includes(qt)) score += 2;
      }
      return {
        path: chunk.path,
        startLine: chunk.startLine,
        endLine: chunk.endLine,
        citation: `${chunk.path}:${chunk.startLine}`,
        score,
        snippet: chunk.content,
      };
    });

    return scored
      .filter((s) => s.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, topK);
  }

  /**
   * Reads a file at a specific line range for opening in the artifact pane.
   */
  readFileAtLine(repoId: string, relPath: string, line = 1): {
    path: string;
    line: number;
    language: string;
    content: string;
    totalLines: number;
  } {
    const ws = this.repos.get(repoId);
    if (!ws) throw new Error(`Workspace ${repoId} not found`);

    const safeRel = relPath.replace(/^(\.\.(\/|\\|$))+/, '');
    const absPath = path.join(ws.rootDir, safeRel);
    if (!fs.existsSync(absPath)) {
      throw new Error(`File ${safeRel} not found in workspace ${repoId}`);
    }
    const content = fs.readFileSync(absPath, 'utf8');
    const lines = content.split('\n');
    return {
      path: safeRel,
      line: Math.max(1, Math.min(line, lines.length)),
      language: detectLanguage(safeRel),
      content,
      totalLines: lines.length,
    };
  }

  /**
   * Applies accepted unified diff hunks to disk and commits them to `apex/work`.
   * Explicitly forbids applying to `main`.
   */
  applyAcceptedHunks(params: {
    repoId: string;
    hunks: DiffHunk[];
    acceptedHunkIds: string[];
    commitMessage?: string;
    targetBranch?: string;
  }): {
    branch: string;
    commitHash: string;
    commitMessage: string;
    appliedFiles: string[];
  } {
    const ws = this.repos.get(params.repoId);
    if (!ws) throw new Error(`Workspace ${params.repoId} not found`);

    const branchToCheck = params.targetBranch || ws.branch;
    if (branchToCheck === 'main' || branchToCheck === 'master') {
      throw new Error('SECURITY_POLICY_VIOLATION: Never apply hunks directly to main/master. All changes must target apex/work.');
    }

    // Ensure git is on apex/work
    const currentBranch = this.runGit(ws.rootDir, 'rev-parse --abbrev-ref HEAD');
    if (currentBranch !== WORK_BRANCH) {
      this.runGit(ws.rootDir, `checkout -B ${WORK_BRANCH}`);
    }

    const acceptedSet = new Set(params.acceptedHunkIds);
    const toApply = params.hunks.filter((h) => acceptedSet.has(h.id));
    if (toApply.length === 0) {
      throw new Error('No accepted hunks selected to apply.');
    }

    const touchedFiles = new Set<string>();
    for (const hunk of toApply) {
      const safeRel = hunk.filePath.replace(/^(\.\.(\/|\\|$))+/, '');
      const absPath = path.join(ws.rootDir, safeRel);
      const original = fs.existsSync(absPath) ? fs.readFileSync(absPath, 'utf8') : '';
      const updated = applyHunkToContent(original, hunk);
      fs.mkdirSync(path.dirname(absPath), { recursive: true });
      fs.writeFileSync(absPath, updated, 'utf8');
      touchedFiles.add(safeRel);
    }

    const filesList = Array.from(touchedFiles);
    const message =
      params.commitMessage ||
      `Apply ${toApply.length} accepted hunk(s) across ${filesList.join(', ')}`;

    this.runGit(ws.rootDir, 'add -A');
    this.runGit(ws.rootDir, `commit -m ${JSON.stringify(message)}`);
    const commitHash = this.runGit(ws.rootDir, 'rev-parse --short HEAD');

    ws.commits = this.listGitCommits(ws.rootDir);
    this.indexWorkspace(ws.id);

    return {
      branch: WORK_BRANCH,
      commitHash,
      commitMessage: message,
      appliedFiles: filesList,
    };
  }

  /**
   * One-click revert per commit on `apex/work`.
   */
  revertCommit(repoId: string, commitHash: string): {
    revertedHash: string;
    newCommitHash: string;
    branch: string;
  } {
    const ws = this.repos.get(repoId);
    if (!ws) throw new Error(`Workspace ${repoId} not found`);

    const safeHash = commitHash.replace(/[^a-fA-F0-9]/g, '');
    this.runGit(ws.rootDir, `revert --no-edit ${safeHash}`);
    const newCommitHash = this.runGit(ws.rootDir, 'rev-parse --short HEAD');
    ws.commits = this.listGitCommits(ws.rootDir);
    this.indexWorkspace(ws.id);

    return {
      revertedHash: safeHash,
      newCommitHash,
      branch: WORK_BRANCH,
    };
  }

  private listGitCommits(rootDir: string): RepoCommitRecord[] {
    try {
      const logOut = this.runGit(
        rootDir,
        'log -n 20 --pretty=format:"%h|%s|%ct"'
      );
      if (!logOut) return [];
      return logOut.split('\n').map((line) => {
        const [hash, message, ts] = line.split('|');
        return {
          hash,
          message,
          branch: WORK_BRANCH,
          timestamp: parseInt(ts || '0', 10) * 1000,
          files: [],
        };
      });
    } catch {
      return [];
    }
  }

  attachConversation(conversationId: string, repoId: string): void {
    if (!this.repos.has(repoId)) {
      throw new Error(`Workspace ${repoId} not found`);
    }
    this.conversationRepoAttachments.set(conversationId, repoId);
  }

  detachConversation(conversationId: string): void {
    this.conversationRepoAttachments.delete(conversationId);
  }

  getAttachedRepo(conversationId: string): RepoWorkspace | null {
    const repoId = this.conversationRepoAttachments.get(conversationId);
    if (!repoId) return null;
    return this.repos.get(repoId) || null;
  }

  getWorkspace(repoId: string): RepoWorkspace | null {
    return this.repos.get(repoId) || null;
  }

  listWorkspaces(): RepoWorkspace[] {
    return Array.from(this.repos.values());
  }
}

export const codebaseManager = new CodebaseManager();
