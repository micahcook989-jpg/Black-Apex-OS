import { getEnv } from './env';
import { log } from './logger';
import { defaultFreeQuotaManager } from './freeMode';
import { defaultDiagStore } from './diag';
import { runCleanAnswerBenchmark50 } from './detector';

export interface StreamChunk {
  text?: string;
  toolCall?: { name: string; args: any };
  done?: boolean;
  tokens?: number;
}

export type StreamHandler = (chunk: StreamChunk) => void;

interface CircuitBreakerState {
  failures: number[];
  skippedUntil: number;
}

const circuitBreakers: Record<string, CircuitBreakerState> = {
  gemini: { failures: [], skippedUntil: 0 },
  groq: { failures: [], skippedUntil: 0 },
  openrouter: { failures: [], skippedUntil: 0 },
  local: { failures: [], skippedUntil: 0 },
};

function recordFailure(provider: string) {
  const now = Date.now();
  const cb = circuitBreakers[provider] || { failures: [], skippedUntil: 0 };
  cb.failures = cb.failures.filter((t) => now - t < 5 * 60 * 1000); // 5 min window
  cb.failures.push(now);
  if (cb.failures.length >= 3) {
    cb.skippedUntil = now + 10 * 60 * 1000; // 10 min cooldown
    log({
      level: 'warn',
      provider,
      message: `Circuit breaker tripped for ${provider}, skipping for 10 minutes`,
    });
  }
  circuitBreakers[provider] = cb;
}

function isProviderAvailable(provider: string): boolean {
  const cb = circuitBreakers[provider];
  if (!cb) return true;
  if (cb.skippedUntil && Date.now() < cb.skippedUntil) {
    return false;
  }
  return true;
}

export function resetCircuitBreaker(provider?: string): void {
  if (provider) {
    circuitBreakers[provider] = { failures: [], skippedUntil: 0 };
  } else {
    for (const key of Object.keys(circuitBreakers)) {
      circuitBreakers[key] = { failures: [], skippedUntil: 0 };
    }
  }
}

// Model IDs cached in memory for the process lifetime
let RESOLVED_GEMINI_MODEL: string = '';
let RESOLVED_GROQ_MODEL: string = '';
let RESOLVED_OPENROUTER_POOL: string[] = [];
let RESOLVED_LOCAL_MODEL: string = '';
let isMeshInitialized = false;

export function getMeshSnapshot(): {
  initialized: boolean;
  gemini: string;
  groq: string;
  openrouter: string[];
  local: string;
} {
  return {
    initialized: isMeshInitialized,
    gemini: RESOLVED_GEMINI_MODEL || 'gemini-3-flash-preview',
    groq: RESOLVED_GROQ_MODEL || 'llama-3.3-70b-versatile',
    openrouter:
      RESOLVED_OPENROUTER_POOL.length > 0
        ? RESOLVED_OPENROUTER_POOL
        : ['openrouter/free', 'nousresearch/hermes-3-llama-3.1-405b:free', 'mistralai/mistral-nemo'],
    local: RESOLVED_LOCAL_MODEL,
  };
}

export async function initMesh(): Promise<{
  gemini: string;
  groq: string;
  openrouter: string[];
  local: string;
}> {
  if (isMeshInitialized) {
    return {
      gemini: RESOLVED_GEMINI_MODEL || 'gemini-3-flash-preview',
      groq: RESOLVED_GROQ_MODEL || 'llama-3.3-70b-versatile',
      openrouter: RESOLVED_OPENROUTER_POOL,
      local: RESOLVED_LOCAL_MODEL || 'llama3',
    };
  }

  const env = getEnv();

  // 1. Resolve Gemini model (10-second timeout per P3.1; exclude retired 1.5, 2.0, and 2.5-pro models)
  const geminiPriority = [
    'gemini-3-flash-preview',
    'gemini-flash-latest',
    'gemini-3.1-flash-lite-preview',
    'gemini-2.5-flash',
  ];
  let geminiReachable = false;
  let geminiDisableReason: string | null = null;
  if (!env.GEMINI_API_KEY) {
    geminiDisableReason = 'GEMINI_API_KEY not set in environment';
  } else {
    try {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models?key=${env.GEMINI_API_KEY}`,
        {
          signal: AbortSignal.timeout(10000),
        }
      );
      if (res.ok) {
        geminiReachable = true;
        const data = await res.json();
        const models: any[] = (data.models || []).filter(
          (m: any) =>
            m.supportedGenerationMethods?.includes('generateContent') &&
            !m.name.includes('gemini-1.5') &&
            !m.name.includes('gemini-2.0') &&
            !m.name.includes('gemini-2.5-pro')
        );
        for (const target of geminiPriority) {
          const match = models.find(
            (m) => m.name === `models/${target}` || m.name.endsWith(`/${target}`)
          );
          if (match) {
            RESOLVED_GEMINI_MODEL = match.name.replace(/^models\//, '');
            break;
          }
        }
      } else {
        geminiDisableReason = `Gemini model discovery returned HTTP ${res.status}`;
      }
    } catch (err: any) {
      geminiDisableReason = `Gemini model discovery failed: ${err?.message || 'timeout'}`;
      log({ level: 'warn', message: 'Failed to discover live Gemini models; using dynamic fallback' });
    }
  }
  if (!RESOLVED_GEMINI_MODEL) {
    RESOLVED_GEMINI_MODEL = 'gemini-3-flash-preview';
  }
  defaultDiagStore.setProviderBootStatus({
    provider: 'gemini',
    configured: Boolean(env.GEMINI_API_KEY),
    reachable: geminiReachable,
    resolvedModel: RESOLVED_GEMINI_MODEL,
    disabled: !geminiReachable,
    disableReason: geminiReachable ? null : geminiDisableReason,
    checkedAtIso: new Date().toISOString(),
  });

  // 2. Resolve Groq model (10-second timeout per P3.1)
  const groqPriority = [
    'llama-3.3-70b-versatile',
    'llama-3.1-8b-instant',
    'llama3-70b-8192',
    'llama3-8b-8192',
  ];
  let groqReachable = false;
  let groqDisableReason: string | null = null;
  if (!env.GROQ_API_KEY) {
    groqDisableReason = 'GROQ_API_KEY not set in environment';
  } else {
    try {
      const res = await fetch('https://api.groq.com/openai/v1/models', {
        headers: { Authorization: `Bearer ${env.GROQ_API_KEY}` },
        signal: AbortSignal.timeout(10000),
      });
      if (res.ok) {
        groqReachable = true;
        const data = await res.json();
        const models: any[] = data.data || [];
        for (const target of groqPriority) {
          const found = models.find((m) => m.id === target || m.id.includes(target));
          if (found) {
            RESOLVED_GROQ_MODEL = found.id;
            break;
          }
        }
        if (!RESOLVED_GROQ_MODEL && models.length > 0) {
          const chatModel = models.find(
            (m) =>
              /llama|mixtral|gemma|deepseek/i.test(m.id) &&
              !/whisper|orpheus|tts|guard|playai|vision/i.test(m.id)
          );
          RESOLVED_GROQ_MODEL = chatModel ? chatModel.id : 'llama-3.3-70b-versatile';
        }
      } else {
        groqDisableReason = `Groq model discovery returned HTTP ${res.status}`;
      }
    } catch (err: any) {
      groqDisableReason = `Groq model discovery failed: ${err?.message || 'timeout'}`;
      log({ level: 'warn', message: 'Failed to discover live Groq models' });
    }
  }
  if (!RESOLVED_GROQ_MODEL) {
    RESOLVED_GROQ_MODEL = 'llama-3.3-70b-versatile';
  }
  defaultDiagStore.setProviderBootStatus({
    provider: 'groq',
    configured: Boolean(env.GROQ_API_KEY),
    reachable: groqReachable,
    resolvedModel: RESOLVED_GROQ_MODEL,
    disabled: !groqReachable,
    disableReason: groqReachable ? null : groqDisableReason,
    checkedAtIso: new Date().toISOString(),
  });

  // 3. Resolve OpenRouter uncensored pool (10-second timeout per P3.1)
  let openrouterReachable = false;
  let openrouterDisableReason: string | null = null;
  if (!env.OPENROUTER_API_KEY) {
    openrouterDisableReason = 'OPENROUTER_API_KEY not set in environment';
  } else {
    try {
      const res = await fetch('https://openrouter.ai/api/v1/models', {
        headers: {
          Authorization: `Bearer ${env.OPENROUTER_API_KEY}`,
          'HTTP-Referer': env.OPENROUTER_REFERER,
          'X-Title': 'Black Apex OS',
        },
        signal: AbortSignal.timeout(10000),
      });
      if (res.ok) {
        openrouterReachable = true;
        const data = await res.json();
        const models: any[] = data.data || [];
        const allowlistRegex = /hermes|dolphin|magnum|euryale|remm|mistral-nemo|uncensored|venice/i;
        const matched = models.filter(
          (m) => allowlistRegex.test(m.id) || allowlistRegex.test(m.name || '')
        );
        // Prioritize :free models first for Section 32 Free-Only mode, then by context_length
        matched.sort((a, b) => {
          const aFree = String(a.id).endsWith(':free') ? 1 : 0;
          const bFree = String(b.id).endsWith(':free') ? 1 : 0;
          if (aFree !== bFree) return bFree - aFree;
          return (b.context_length || 0) - (a.context_length || 0);
        });
        RESOLVED_OPENROUTER_POOL = ['openrouter/free', ...matched.map((m) => m.id)];
      } else {
        openrouterDisableReason = `OpenRouter model discovery returned HTTP ${res.status}`;
      }
    } catch (err: any) {
      openrouterDisableReason = `OpenRouter model discovery failed: ${err?.message || 'timeout'}`;
      log({ level: 'warn', message: 'Failed to discover live OpenRouter models' });
    }
  }
  if (RESOLVED_OPENROUTER_POOL.length === 0) {
    RESOLVED_OPENROUTER_POOL = [
      'openrouter/free',
      'nousresearch/hermes-3-llama-3.1-405b:free',
      'mistralai/mistral-nemo',
    ];
  }
  defaultDiagStore.setProviderBootStatus({
    provider: 'openrouter',
    configured: Boolean(env.OPENROUTER_API_KEY),
    reachable: openrouterReachable,
    resolvedModel: RESOLVED_OPENROUTER_POOL[0] || 'openrouter/free',
    disabled: !openrouterReachable,
    disableReason: openrouterReachable ? null : openrouterDisableReason,
    checkedAtIso: new Date().toISOString(),
  });

  // 4. P3.2: Detect Ollama at boot (/api/tags or /v1/models).
  // If reachable, list tags and select one. If not reachable, run in THIN profile (remote-only).
  let localReachable = false;
  let localDisableReason: string | null = null;
  let availableTags: string[] = [];

  if (env.OLLAMA_BASE_URL) {
    try {
      let tagsRes = await fetch(`${env.OLLAMA_BASE_URL}/api/tags`, {
        signal: AbortSignal.timeout(2500),
      }).catch(() => null);

      if (tagsRes && tagsRes.ok) {
        const tagData: any = await tagsRes.json();
        const models: any[] = tagData.models || [];
        availableTags = models.map((m) => m.name || m.model).filter(Boolean);
        const uncensored = availableTags.find((id) => /uncensored|hermes|dolphin/i.test(id));
        RESOLVED_LOCAL_MODEL = uncensored || availableTags[0] || 'llama3';
        localReachable = true;
      } else {
        const v1Res = await fetch(`${env.OLLAMA_BASE_URL}/v1/models`, {
          signal: AbortSignal.timeout(2500),
        });
        if (v1Res.ok) {
          const data: any = await v1Res.json();
          const models: any[] = data.data || [];
          availableTags = models.map((m) => m.id).filter(Boolean);
          const uncensored = availableTags.find((id) => /uncensored|hermes|dolphin/i.test(id));
          RESOLVED_LOCAL_MODEL = uncensored || availableTags[0] || 'llama3';
          localReachable = true;
        } else {
          localDisableReason = `Ollama endpoint ${env.OLLAMA_BASE_URL} returned HTTP ${v1Res.status} — THIN profile active (remote-only)`;
        }
      }
    } catch (err: any) {
      localDisableReason = `Ollama at ${env.OLLAMA_BASE_URL} not reachable (${err?.message || 'connection refused'}) — THIN profile active (remote-only)`;
    }
  } else {
    localDisableReason = 'OLLAMA_BASE_URL not configured — THIN profile active (remote-only)';
  }

  if (localReachable) {
    defaultFreeQuotaManager.setLocalStatus(true, true);
    defaultDiagStore.setLocalBootDetail({
      configured: true,
      reachable: true,
      selectedTag: RESOLVED_LOCAL_MODEL,
      availableTags,
      reason: `Local Ollama reachable at ${env.OLLAMA_BASE_URL} (${availableTags.length} tag(s), selected ${RESOLVED_LOCAL_MODEL}).`,
    });
    defaultDiagStore.setProviderBootStatus({
      provider: 'local',
      configured: true,
      reachable: true,
      resolvedModel: RESOLVED_LOCAL_MODEL,
      disabled: false,
      disableReason: null,
      checkedAtIso: new Date().toISOString(),
    });
  } else {
    RESOLVED_LOCAL_MODEL = 'llama3'; // Never leave an empty model ID
    defaultFreeQuotaManager.setLocalStatus(false, false);
    defaultDiagStore.setLocalBootDetail({
      configured: Boolean(env.OLLAMA_BASE_URL),
      reachable: false,
      selectedTag: null,
      availableTags: [],
      reason: 'THIN profile active — local model not reachable, running remote-only.',
    });
    defaultDiagStore.setProviderBootStatus({
      provider: 'local',
      configured: Boolean(env.OLLAMA_BASE_URL),
      reachable: false,
      resolvedModel: RESOLVED_LOCAL_MODEL,
      disabled: true,
      disableReason:
        localDisableReason || 'THIN profile active — local model not reachable, running remote-only.',
      checkedAtIso: new Date().toISOString(),
    });
  }

  isMeshInitialized = true;
  runCleanAnswerBenchmark50();
  preencodeBootTokenMaps([
    RESOLVED_GROQ_MODEL,
    ...RESOLVED_OPENROUTER_POOL.slice(0, 5),
    RESOLVED_LOCAL_MODEL || 'llama3',
  ]);
  log({
    level: 'info',
    message: `Black Apex OS provider mesh initialized (profile: ${localReachable ? 'FULL' : 'THIN'})`,
    event: 'mesh_init',
  });

  return {
    gemini: RESOLVED_GEMINI_MODEL,
    groq: RESOLVED_GROQ_MODEL,
    openrouter: RESOLVED_OPENROUTER_POOL,
    local: localReachable ? RESOLVED_LOCAL_MODEL : '',
  };
}

// -----------------------------------------------------------------------------
// Streaming Clients with Retries & Exponential Backoff
// -----------------------------------------------------------------------------

async function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

import { applyLogitBiasToPayload, preencodeBootTokenMaps } from './bias';
import { OperatingMode } from '../src/types';

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface StreamOptions {
  messages: ChatMessage[];
  systemPrompt?: string;
  onChunk: StreamHandler;
  onTtft?: (ttftMs: number) => void;
  onGroundingSources?: (sources: GroundingSource[]) => void;
  turnId?: string;
  timeoutMs?: number;
  webSearchActive?: boolean;
  mode?: OperatingMode;
  logitBiasMultiplier?: number;
  temperature?: number;
  topP?: number;
  maxOutputTokens?: number;
  thinkingBudget?: number;
  fetchImpl?: typeof fetch;
}

// Gemini Tier
export async function streamGemini(options: StreamOptions): Promise<string> {
  if (!isProviderAvailable('gemini')) {
    throw new Error('Gemini provider circuit breaker active');
  }
  if (!options.fetchImpl) {
    await initMesh();
  }
  const env = getEnv();
  const fetchFn = options.fetchImpl || fetch;
  const candidateModels = Array.from(
    new Set(
      [
        ...(options.webSearchActive ? ['gemini-3.8-flash'] : []),
        RESOLVED_GEMINI_MODEL,
        'gemini-3-flash-preview',
        'gemini-flash-latest',
        'gemini-3.1-flash-lite-preview',
      ].filter(Boolean)
    )
  );
  const timeoutMs = options.timeoutMs || 90000;

  const contents = options.messages
    .filter((m) => m.role !== 'system')
    .map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

  const systemInstruction = options.systemPrompt
    ? { parts: [{ text: options.systemPrompt }] }
    : undefined;

  const safetySettings = [
    { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_NONE' },
    { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_NONE' },
    { category: 'HARM_CATEGORY_SEXUALLY_EXPLICIT', threshold: 'BLOCK_NONE' },
    { category: 'HARM_CATEGORY_DANGEROUS_CONTENT', threshold: 'BLOCK_NONE' },
    { category: 'HARM_CATEGORY_CIVIC_INTEGRITY', threshold: 'BLOCK_NONE' },
  ];

  // Section 17.1: applyLogitBiasToPayload strictly omits logit_bias on Gemini
  const payload: any = applyLogitBiasToPayload(
    {
      contents,
      systemInstruction,
      safetySettings,
      ...(options.webSearchActive ? { tools: [{ googleSearch: {} }] } : {}),
      generationConfig: {
        maxOutputTokens: options.maxOutputTokens ?? 8192,
        ...(typeof options.thinkingBudget === 'number'
          ? { thinkingConfig: { thinkingBudget: options.thinkingBudget } }
          : {}),
      },
    },
    'gemini',
    candidateModels[0],
    options.mode,
    options.logitBiasMultiplier
  );

  let fullText = '';
  let lastErr: any = null;
  const groundingMap = new Map<string, GroundingSource>();

  for (let i = 0; i < candidateModels.length; i++) {
    const activeModel = candidateModels[i];
    const reqStartMs = Date.now();
    let firstTokenRecorded = false;
    // gemini-3.8-flash does not accept thinkingBudget in generationConfig
    const modelPayload =
      activeModel === 'gemini-3.8-flash'
        ? {
            ...payload,
            generationConfig: { maxOutputTokens: options.maxOutputTokens ?? 8192 },
          }
        : payload;
    try {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${activeModel}:streamGenerateContent?alt=sse`;
      const res = await fetchFn(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': env.GEMINI_API_KEY,
        },
        body: JSON.stringify(modelPayload),
        signal: AbortSignal.timeout(timeoutMs),
      });

      defaultDiagStore.recordUpstreamCall(options.turnId, {
        provider: 'gemini',
        url: `https://generativelanguage.googleapis.com/v1beta/models/${activeModel}:streamGenerateContent`,
        purpose: 'generation',
        status: res.status,
        durationMs: Date.now() - reqStartMs,
        timestamp: new Date().toISOString(),
      });

      if (!res.ok) {
        const errText = await res.text();
        lastErr = new Error(`Gemini HTTP ${res.status}: ${errText.slice(0, 100)}`);
        if ((res.status === 404 || res.status === 400 || res.status === 429) && i < candidateModels.length - 1) {
          continue;
        }
        throw lastErr;
      }

      RESOLVED_GEMINI_MODEL = activeModel;
      resetCircuitBreaker('gemini');

      const reader = res.body?.getReader();
      if (!reader) throw new Error('No readable stream from Gemini');

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const jsonStr = line.slice(6).trim();
            if (!jsonStr || jsonStr === '[DONE]') continue;
            try {
              const parsed = JSON.parse(jsonStr);
              const chunks = parsed.candidates?.[0]?.groundingMetadata?.groundingChunks;
              if (Array.isArray(chunks)) {
                for (const c of chunks) {
                  if (c?.web?.uri) {
                    groundingMap.set(c.web.uri, {
                      uri: c.web.uri,
                      title: c.web.title || c.web.uri,
                    });
                  }
                }
              }
              const textChunk =
                parsed.candidates?.[0]?.content?.parts?.[0]?.text || '';
              if (textChunk) {
                if (!firstTokenRecorded) {
                  firstTokenRecorded = true;
                  options.onTtft?.(Date.now() - reqStartMs);
                }
                fullText += textChunk;
                options.onChunk({ text: textChunk });
              }
            } catch {
              // Ignore partial parse error
            }
          }
        }
      }

      if (groundingMap.size > 0) {
        options.onGroundingSources?.(Array.from(groundingMap.values()));
      }
      options.onChunk({ done: true });
      return fullText;
    } catch (err: any) {
      lastErr = err;
      if (i >= candidateModels.length - 1) {
        recordFailure('gemini');
        throw err;
      }
      await sleep(500 * (i + 1));
    }
  }

  return fullText;
}

// Groq Tier
export async function streamGroq(options: StreamOptions): Promise<string> {
  if (!isProviderAvailable('groq')) {
    throw new Error('Groq provider circuit breaker active');
  }
  if (!options.fetchImpl) {
    await initMesh();
  }
  const env = getEnv();
  const fetchFn = options.fetchImpl || fetch;
  const model = RESOLVED_GROQ_MODEL || 'llama-3.3-70b-versatile';
  const timeoutMs = options.timeoutMs || 90000;

  const messages: any[] = [];
  if (options.systemPrompt) {
    messages.push({ role: 'system', content: options.systemPrompt.slice(0, 8000) });
  }
  for (const m of options.messages) {
    messages.push({ role: m.role, content: m.content.slice(0, 12000) });
  }

  // Cap max_tokens to 2048 to stay within Groq per-request TPM limits
  const safeMaxTokens = Math.min(options.maxOutputTokens ?? 2048, 2048);

  // Section 17.1: Attach cached per-model logit_bias map for Groq
  const payload: any = applyLogitBiasToPayload(
    {
      model,
      messages,
      temperature: options.temperature ?? 0.9,
      top_p: options.topP ?? 0.95,
      max_tokens: safeMaxTokens,
      stream: true,
    },
    'groq',
    model,
    options.mode,
    options.logitBiasMultiplier
  );

  let attempts = 0;
  let fullText = '';

  while (attempts < 2) {
    attempts++;
    const reqStartMs = Date.now();
    let firstTokenRecorded = false;
    try {
      const res = await fetchFn('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${env.GROQ_API_KEY}`,
        },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(timeoutMs),
      });

      defaultDiagStore.recordUpstreamCall(options.turnId, {
        provider: 'groq',
        url: 'https://api.groq.com/openai/v1/chat/completions',
        purpose: 'generation',
        status: res.status,
        durationMs: Date.now() - reqStartMs,
        timestamp: new Date().toISOString(),
      });

      if (!res.ok) {
        const errText = await res.text();
        if (res.status === 400 && payload.logit_bias) {
          delete payload.logit_bias;
          continue;
        }
        if ((res.status === 413 || res.status === 429) && attempts < 2) {
          delete payload.logit_bias;
          payload.model = 'llama-3.1-8b-instant';
          payload.max_tokens = Math.min(payload.max_tokens || 1024, 1024);
          payload.messages = payload.messages.map((m: any) => ({
            role: m.role,
            content: typeof m.content === 'string' ? m.content.slice(-4000) : m.content,
          }));
          continue;
        }
        throw new Error(`Groq HTTP ${res.status}: ${errText.slice(0, 100)}`);
      }

      resetCircuitBreaker('groq');

      const reader = res.body?.getReader();
      if (!reader) throw new Error('No stream from Groq');

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const dataStr = line.slice(6).trim();
            if (dataStr === '[DONE]') continue;
            try {
              const parsed = JSON.parse(dataStr);
              const text = parsed.choices?.[0]?.delta?.content || '';
              if (text) {
                if (!firstTokenRecorded) {
                  firstTokenRecorded = true;
                  options.onTtft?.(Date.now() - reqStartMs);
                }
                fullText += text;
                options.onChunk({ text });
              }
            } catch {}
          }
        }
      }

      options.onChunk({ done: true });
      return fullText;
    } catch (err: any) {
      if (attempts >= 2) {
        recordFailure('groq');
        throw err;
      }
      await sleep(500 * Math.pow(2, attempts));
    }
  }

  return fullText;
}

// OpenRouter Tier
export async function streamOpenRouter(options: StreamOptions & { poolIndex?: number }): Promise<string> {
  if (!isProviderAvailable('openrouter')) {
    throw new Error('OpenRouter provider circuit breaker active');
  }
  await initMesh();
  const env = getEnv();
  const pool = RESOLVED_OPENROUTER_POOL;
  const idx = options.poolIndex || 0;
  let modelSlug = pool[idx % pool.length] || 'openrouter/free';

  if (options.webSearchActive) {
    modelSlug += ':online';
  }

  const timeoutMs = options.timeoutMs || 90000;
  const messages: any[] = [];
  if (options.systemPrompt) {
    messages.push({ role: 'system', content: options.systemPrompt });
  }
  for (const m of options.messages) {
    messages.push({ role: m.role, content: m.content });
  }

  // Section 17.1: Attach cached per-model logit_bias map for OpenRouter
  const payload: any = applyLogitBiasToPayload(
    {
      model: modelSlug,
      messages,
      temperature: options.temperature ?? 0.95,
      top_p: options.topP ?? 0.95,
      max_tokens: options.maxOutputTokens ?? 4096,
      stream: true,
      provider: {
        allow_fallbacks: true,
        order: ['cheapest first'],
      },
      transforms: ['middle-out'],
    },
    'openrouter',
    modelSlug,
    options.mode,
    options.logitBiasMultiplier
  );

  let attempts = 0;
  let fullText = '';

  while (attempts < 2) {
    attempts++;
    const reqStartMs = Date.now();
    let firstTokenRecorded = false;
    try {
      const res = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${env.OPENROUTER_API_KEY}`,
          'HTTP-Referer': env.OPENROUTER_REFERER,
          'X-Title': 'Black Apex OS',
        },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(timeoutMs),
      });

      defaultDiagStore.recordUpstreamCall(options.turnId, {
        provider: 'openrouter',
        url: 'https://openrouter.ai/api/v1/chat/completions',
        purpose: 'generation',
        status: res.status,
        durationMs: Date.now() - reqStartMs,
        timestamp: new Date().toISOString(),
      });

      if (!res.ok) {
        const errText = await res.text();
        if ((res.status === 400 || res.status === 402) && attempts < 2) {
          delete payload.logit_bias;
          payload.model = 'openrouter/free';
          continue;
        }
        throw new Error(`OpenRouter HTTP ${res.status}: ${errText.slice(0, 100)}`);
      }

      const reader = res.body?.getReader();
      if (!reader) throw new Error('No stream from OpenRouter');

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const dataStr = line.slice(6).trim();
            if (dataStr === '[DONE]') continue;
            try {
              const parsed = JSON.parse(dataStr);
              const text = parsed.choices?.[0]?.delta?.content || '';
              if (text) {
                if (!firstTokenRecorded) {
                  firstTokenRecorded = true;
                  options.onTtft?.(Date.now() - reqStartMs);
                }
                fullText += text;
                options.onChunk({ text });
              }
            } catch {}
          }
        }
      }

      options.onChunk({ done: true });
      return fullText;
    } catch (err: any) {
      if (attempts >= 2) {
        recordFailure('openrouter');
        throw err;
      }
      await sleep(1000 * Math.pow(2, attempts));
    }
  }

  return fullText;
}

// Local Tier (Ollama)
export async function streamLocal(options: StreamOptions): Promise<string> {
  const env = getEnv();
  if (!env.OLLAMA_BASE_URL) {
    throw new Error('Local tier not configured');
  }
  const model = RESOLVED_LOCAL_MODEL || 'llama3';
  const timeoutMs = options.timeoutMs || 90000;

  const messages: any[] = [];
  if (options.systemPrompt) {
    messages.push({ role: 'system', content: options.systemPrompt });
  }
  for (const m of options.messages) {
    messages.push({ role: m.role, content: m.content });
  }

  // Section 17.1: Attach cached per-model logit_bias map for Local/Ollama
  const payload = applyLogitBiasToPayload(
    {
      model,
      messages,
      temperature: options.temperature ?? 0.95,
      top_p: options.topP ?? 0.95,
      max_tokens: options.maxOutputTokens ?? 4096,
      stream: true,
    },
    'local',
    model,
    options.mode,
    options.logitBiasMultiplier
  );

  const reqStartMs = Date.now();
  let firstTokenRecorded = false;
  const res = await fetch(`${env.OLLAMA_BASE_URL}/v1/chat/completions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(timeoutMs),
  });

  defaultDiagStore.recordUpstreamCall(options.turnId, {
    provider: 'local',
    url: `${env.OLLAMA_BASE_URL}/v1/chat/completions`,
    purpose: 'generation',
    status: res.status,
    durationMs: Date.now() - reqStartMs,
    timestamp: new Date().toISOString(),
  });

  if (!res.ok) {
    throw new Error(`Local tier HTTP ${res.status}`);
  }

  const reader = res.body?.getReader();
  if (!reader) throw new Error('No stream from local tier');

  const decoder = new TextDecoder();
  let buffer = '';
  let fullText = '';

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() || '';

    for (const line of lines) {
      if (line.startsWith('data: ')) {
        const dataStr = line.slice(6).trim();
        if (dataStr === '[DONE]') continue;
        try {
          const parsed = JSON.parse(dataStr);
          const text = parsed.choices?.[0]?.delta?.content || '';
          if (text) {
            if (!firstTokenRecorded) {
              firstTokenRecorded = true;
              options.onTtft?.(Date.now() - reqStartMs);
            }
            fullText += text;
            options.onChunk({ text });
          }
        } catch {}
      }
    }
  }

  options.onChunk({ done: true });
  return fullText;
}

// Groq Tier 2 Classifier & Chips
export async function classifyHedgeGroq(
  text: string,
  turnId?: string
): Promise<'CLEAN' | 'HEDGE' | 'REFUSAL'> {
  const reqStartMs = Date.now();
  try {
    const env = getEnv();
    const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${env.GROQ_API_KEY}`,
      },
      body: JSON.stringify({
        model: 'llama-3.1-8b-instant',
        messages: [
          {
            role: 'system',
            content:
              'Analyze the assistant response snippet. Output exactly one word: CLEAN, HEDGE, or REFUSAL. Do not output anything else.',
          },
          { role: 'user', content: text.slice(0, 1000) },
        ],
        max_tokens: 8,
        temperature: 0.1,
      }),
      signal: AbortSignal.timeout(1200),
    });

    defaultDiagStore.recordUpstreamCall(turnId, {
      provider: 'groq',
      url: 'https://api.groq.com/openai/v1/chat/completions',
      purpose: 'tier2_classifier',
      status: res.status,
      durationMs: Date.now() - reqStartMs,
      timestamp: new Date().toISOString(),
    });

    if (res.ok) {
      const data = await res.json();
      const verdict = (data.choices?.[0]?.message?.content || '').trim().toUpperCase();
      if (verdict.includes('REFUSAL')) {
        defaultDiagStore.recordTier2Result(true);
        return 'REFUSAL';
      }
      if (verdict.includes('HEDGE')) {
        defaultDiagStore.recordTier2Result(true);
        return 'HEDGE';
      }
      defaultDiagStore.recordTier2Result(false);
      return 'CLEAN';
    }
  } catch {}
  defaultDiagStore.recordTier2Result(false);
  return 'CLEAN';
}

/**
 * PATCH 01 (P2) + Randomized Follow-Up Generator:
 * Generates 3 randomly sampled, context-aware follow-up options with zero extra upstream requests.
 */
export async function generateNextStepChips(userQuery: string, answer: string): Promise<string[]> {
  const lower = `${userQuery} ${answer}`.toLowerCase();
  const cleanTopic = userQuery
    .replace(/^\/\w+\s*/i, '')
    .replace(/[?!.]+$/g, '')
    .trim()
    .slice(0, 42);

  let pool: string[];

  if (/```|function\s+|const\s+|class\s+|import\s+|def\s+|interface\s+/.test(answer)) {
    pool = [
      'Write unit tests for this implementation',
      'Add strict error handling and edge cases',
      'Optimize for time and memory complexity',
      'Show a real-world usage example',
      'Refactor into a reusable modular hook/service',
      'Add TypeScript strict types and JSDoc comments',
      'Explain potential concurrency or race conditions',
      'Benchmark this approach against alternatives',
    ];
  } else if (lower.includes('sql') || lower.includes('database') || lower.includes('schema') || lower.includes('query')) {
    pool = [
      'Design the composite indexing strategy',
      'Generate a zero-downtime migration script',
      'Analyze the query execution plan (EXPLAIN)',
      'Add connection pooling and retry logic',
      'Show how to partition or shard this table',
      'Write seed data and integration tests',
    ];
  } else if (lower.includes('search') || lower.includes('latest') || lower.includes('news') || lower.includes('http')) {
    pool = [
      'Compare the primary sources in a table',
      'Summarize the key takeaways into bullet points',
      'What are the counter-arguments or risks?',
      'Track timeline of recent developments',
      'Verify claims with additional live web search',
      'Draft an executive briefing from these findings',
    ];
  } else {
    pool = [
      'Give me a concrete step-by-step example',
      'Break this down into a comparison table',
      'What are the most common pitfalls to avoid?',
      'Explain the underlying architecture in depth',
      'Provide a quick checklist I can follow',
      'How would this scale in a production environment?',
      'Summarize the pros and cons',
      ...(cleanTopic.length > 3 ? [`Go deeper into "${cleanTopic}"`] : []),
    ];
  }

  // Fisher-Yates shuffle for genuine randomization on every call
  const shuffled = [...pool];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled.slice(0, 3);
}
