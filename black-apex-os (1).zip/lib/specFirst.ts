import { GearLevel } from './gearing';

/**
 * Section 24.14 — Spec-First Threshold
 *
 * When a task is expected to produce >800 tokens of output, touch >3 files,
 * or run in DEEP gear, the assistant first produces and persists an editable
 * specification + todo checklist before executing the main implementation.
 * The spec persists across turns and branches.
 */

export interface SpecTodoItem {
  id: string;
  title: string;
  fileTarget?: string;
  completed: boolean;
}

export interface TaskSpec {
  id: string;
  conversationId: string;
  branchId: string;
  objective: string;
  constraints: string[];
  filesTouched: string[];
  estimatedTokens: number;
  gear: GearLevel;
  todos: SpecTodoItem[];
  approved: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface SpecThresholdInput {
  prompt: string;
  gear: GearLevel;
  estimatedOutputTokens?: number;
  targetFileCount?: number;
}

export function shouldTriggerSpecFirst(input: SpecThresholdInput): {
  triggered: boolean;
  reason?: 'deep_gear' | 'expected_tokens_over_800' | 'files_over_3';
  estimatedTokens: number;
  estimatedFiles: number;
} {
  const text = (input.prompt || '').trim();
  const lower = text.toLowerCase();

  // Estimate target file count from prompt if not explicitly supplied
  const explicitFileMentions = (text.match(/\b[\w./-]+\.(ts|tsx|js|jsx|py|rs|go|sql|json|html|css|md)\b/gi) || []);
  const uniqueFiles = new Set(explicitFileMentions.map((f) => f.toLowerCase()));
  const multiFileSignal = /\b(across\s+\d+\s+files|multiple\s+files|full\s+stack|frontend\s+and\s+backend|client\s+and\s+server)\b/i.test(lower);
  const estimatedFiles = input.targetFileCount ?? (uniqueFiles.size || (multiFileSignal ? 4 : 1));

  // Estimate output tokens from prompt complexity
  let estimatedTokens = input.estimatedOutputTokens ?? 250;
  if (!input.estimatedOutputTokens) {
    if (/\b(complete|entire|from\s+scratch|production-ready|full\s+implementation|end-to-end|architecture|comprehensive)\b/i.test(lower)) {
      estimatedTokens = 1200;
    } else if (estimatedFiles > 3) {
      estimatedTokens = 1000;
    } else if (text.length > 400) {
      estimatedTokens = 850;
    }
  }

  if (input.gear === 'DEEP') {
    return {
      triggered: true,
      reason: 'deep_gear',
      estimatedTokens: Math.max(estimatedTokens, 900),
      estimatedFiles,
    };
  }

  if (estimatedTokens > 800) {
    return {
      triggered: true,
      reason: 'expected_tokens_over_800',
      estimatedTokens,
      estimatedFiles,
    };
  }

  if (estimatedFiles > 3) {
    return {
      triggered: true,
      reason: 'files_over_3',
      estimatedTokens,
      estimatedFiles,
    };
  }

  return {
    triggered: false,
    estimatedTokens,
    estimatedFiles,
  };
}

export class SpecStore {
  private specs = new Map<string, TaskSpec>();

  private makeKey(conversationId: string, branchId = 'main'): string {
    return `${conversationId}:${branchId}`;
  }

  createSpec(params: {
    conversationId: string;
    branchId?: string;
    prompt: string;
    gear: GearLevel;
    filesTouched?: string[];
    estimatedTokens?: number;
    todos?: Array<{ title: string; fileTarget?: string }>;
  }): TaskSpec {
    const branchId = params.branchId || 'main';
    const key = this.makeKey(params.conversationId, branchId);
    const now = Date.now();

    const defaultTodos = params.todos && params.todos.length > 0
      ? params.todos
      : [
          { title: 'Analyze requirements and edge cases' },
          { title: 'Implement core module logic and interfaces' },
          { title: 'Write and execute verification tests' },
        ];

    const spec: TaskSpec = {
      id: `spec_${now}_${Math.random().toString(36).slice(2, 7)}`,
      conversationId: params.conversationId,
      branchId,
      objective: params.prompt.slice(0, 280),
      constraints: [
        'Preserve existing contracts and backwards compatibility',
        'Verify with deterministic tests before completion',
      ],
      filesTouched: params.filesTouched || [],
      estimatedTokens: params.estimatedTokens ?? 900,
      gear: params.gear,
      todos: defaultTodos.map((t, idx) => ({
        id: `todo_${idx + 1}`,
        title: t.title,
        fileTarget: t.fileTarget,
        completed: false,
      })),
      approved: true,
      createdAt: now,
      updatedAt: now,
    };

    this.specs.set(key, spec);
    return spec;
  }

  getSpec(conversationId: string, branchId = 'main'): TaskSpec | null {
    return this.specs.get(this.makeKey(conversationId, branchId)) || null;
  }

  updateSpec(
    conversationId: string,
    updates: Partial<Pick<TaskSpec, 'objective' | 'constraints' | 'filesTouched' | 'approved' | 'todos'>>,
    branchId = 'main'
  ): TaskSpec | null {
    const key = this.makeKey(conversationId, branchId);
    const existing = this.specs.get(key);
    if (!existing) return null;

    const updated: TaskSpec = {
      ...existing,
      ...updates,
      updatedAt: Date.now(),
    };
    this.specs.set(key, updated);
    return updated;
  }

  toggleTodo(conversationId: string, todoId: string, completed: boolean, branchId = 'main'): TaskSpec | null {
    const existing = this.getSpec(conversationId, branchId);
    if (!existing) return null;
    const todos = existing.todos.map((t) => (t.id === todoId ? { ...t, completed } : t));
    return this.updateSpec(conversationId, { todos }, branchId);
  }

  cloneForBranch(conversationId: string, fromBranch: string, toBranch: string): TaskSpec | null {
    const source = this.getSpec(conversationId, fromBranch);
    if (!source) return null;
    const cloned: TaskSpec = {
      ...source,
      branchId: toBranch,
      todos: source.todos.map((t) => ({ ...t })),
      constraints: [...source.constraints],
      filesTouched: [...source.filesTouched],
      updatedAt: Date.now(),
    };
    this.specs.set(this.makeKey(conversationId, toBranch), cloned);
    return cloned;
  }
}

export const specStore = new SpecStore();
