import { getDb, Conversation, Message } from './db';

export interface ImportReport {
  success: boolean;
  importedConversations: number;
  importedMessages: number;
  skipped: number;
  errors: string[];
}

/**
 * Parses and maps ChatGPT export format (conversations.json) into Black Apex OS schema
 */
export function importChatGPTConversations(jsonData: any[]): ImportReport {
  const db = getDb();
  const report: ImportReport = {
    success: true,
    importedConversations: 0,
    importedMessages: 0,
    skipped: 0,
    errors: [],
  };

  if (!Array.isArray(jsonData)) {
    return { ...report, success: false, errors: ['Input is not a JSON array of conversations'] };
  }

  for (const item of jsonData) {
    try {
      const convId = `chatgpt-${item.id || item.conversation_id || Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const title = item.title || 'Imported ChatGPT Session';
      const createdAt = item.create_time ? new Date(item.create_time * 1000).toISOString() : new Date().toISOString();
      const updatedAt = item.update_time ? new Date(item.update_time * 1000).toISOString() : createdAt;

      const conversation: Conversation = {
        id: convId,
        title: `[Imported] ${title}`,
        folderId: 'imported',
        pinned: false,
        createdAt,
        updatedAt,
      };

      db.saveConversation(conversation);
      report.importedConversations++;

      // ChatGPT mapping uses a mapping dict with nodes or messages array
      if (item.mapping && typeof item.mapping === 'object') {
        const nodes = Object.values(item.mapping) as any[];
        // Sort by create_time if available
        nodes.sort((a, b) => (a?.message?.create_time || 0) - (b?.message?.create_time || 0));

        for (const node of nodes) {
          const msgObj = node.message;
          if (!msgObj || !msgObj.content || !msgObj.author) continue;

          const role = msgObj.author.role;
          if (role !== 'user' && role !== 'assistant' && role !== 'system') continue;

          let text = '';
          if (Array.isArray(msgObj.content.parts)) {
            text = msgObj.content.parts.filter((p: any) => typeof p === 'string').join('\n');
          } else if (typeof msgObj.content.text === 'string') {
            text = msgObj.content.text;
          }

          if (!text.trim()) continue;

          const msg: Message = {
            id: `msg-${msgObj.id || Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
            conversationId: convId,
            role,
            content: text,
            createdAt: msgObj.create_time ? new Date(msgObj.create_time * 1000).toISOString() : createdAt,
            updatedAt: msgObj.create_time ? new Date(msgObj.create_time * 1000).toISOString() : createdAt,
          };

          db.saveMessage(msg);
          report.importedMessages++;
        }
      }
    } catch (err: any) {
      report.skipped++;
      report.errors.push(err.message || 'Error processing conversation node');
    }
  }

  return report;
}

/**
 * Parses and maps Claude export format (conversations.json or array) into Black Apex OS schema
 */
export function importClaudeConversations(jsonData: any[]): ImportReport {
  const db = getDb();
  const report: ImportReport = {
    success: true,
    importedConversations: 0,
    importedMessages: 0,
    skipped: 0,
    errors: [],
  };

  if (!Array.isArray(jsonData)) {
    return { ...report, success: false, errors: ['Input is not a JSON array of Claude conversations'] };
  }

  for (const item of jsonData) {
    try {
      const convId = `claude-${item.uuid || item.id || Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const title = item.name || item.title || 'Imported Claude Session';
      const createdAt = item.created_at || new Date().toISOString();
      const updatedAt = item.updated_at || createdAt;

      const conversation: Conversation = {
        id: convId,
        title: `[Imported] ${title}`,
        folderId: 'imported',
        pinned: false,
        createdAt,
        updatedAt,
      };

      db.saveConversation(conversation);
      report.importedConversations++;

      const chatMessages = item.chat_messages || item.messages || [];
      for (const m of chatMessages) {
        const role = m.sender === 'human' || m.role === 'user' ? 'user' : 'assistant';
        const text = m.text || m.content || '';
        if (!text.trim()) continue;

        const msg: Message = {
          id: `msg-${m.uuid || Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          conversationId: convId,
          role,
          content: text,
          createdAt: m.created_at || createdAt,
          updatedAt: m.created_at || createdAt,
        };

        db.saveMessage(msg);
        report.importedMessages++;
      }
    } catch (err: any) {
      report.skipped++;
      report.errors.push(err.message || 'Error processing Claude conversation item');
    }
  }

  return report;
}
