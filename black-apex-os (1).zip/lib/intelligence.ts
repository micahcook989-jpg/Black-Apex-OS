import crypto from 'crypto';

/**
 * Section 24.8 — Provenance Tiers
 * Section 24.9 — Contradiction Detection
 * Section 24.10 — Correction Capture (capped at 40 rules)
 * Section 24.11 — Blind A/B and Elo (switches to Elo sort at >=20 votes)
 * Section 24.17 — Last Tier (Local-only toggle + request log guard, Voice mode,
 *                 Encrypted cross-device sync, Publish static artifact, UI i18n,
 *                 Profile separation, Thread fine-tuning JSONL distillation)
 */

// ============================================================================
// 24.8 PROVENANCE TIERS
// ============================================================================
export type ProvenanceTierName =
  | 'primary'
  | 'official_docs'
  | 'maintained_repo'
  | 'forum'
  | 'blog'
  | 'aggregator';

export interface RankedSource {
  url: string;
  title?: string;
  tier: 1 | 2 | 3 | 4 | 5;
  tierName: ProvenanceTierName;
  badge: string;
  dateStamp: string;
  deadLink: boolean;
}

export interface ProvenanceEvaluation {
  sources: RankedSource[];
  weakEvidenceNote: string | null;
}

/**
 * Ranks a source URL into:
 * Tier 1: primary (arxiv.org, doi.org, .gov, ietf.org, w3.org, nature.com)
 * Tier 2: official_docs (docs.*, developer.*, mdn, nodejs.org, react.dev, typescriptlang.org)
 * Tier 3: maintained_repo (github.com, gitlab.com, crates.io, npmjs.com, pypi.org)
 * Tier 4: forum / blog (stackoverflow.com, reddit.com, news.ycombinator.com, medium.com, substack.com, dev.to)
 * Tier 5: aggregator (all other generic syndication / scraper domains)
 */
export function rankSourceProvenance(input: {
  url: string;
  title?: string;
  publishedAt?: string;
  statusCode?: number;
}): RankedSource {
  const urlLower = (input.url || '').toLowerCase();
  const dateStamp = input.publishedAt || new Date().toISOString().slice(0, 10);
  const deadLink = Boolean(input.statusCode && input.statusCode >= 400);

  if (
    /\b(arxiv\.org|doi\.org|ietf\.org|w3\.org|nature\.com|science\.org|\.gov\b|\.edu\b)/.test(urlLower)
  ) {
    return {
      url: input.url,
      title: input.title,
      tier: 1,
      tierName: 'primary',
      badge: 'T1:PRIMARY',
      dateStamp,
      deadLink,
    };
  }

  if (
    /\b(docs\.|developer\.|mozilla\.org|react\.dev|nodejs\.org|typescriptlang\.org|python\.org|rust-lang\.org|go\.dev)/.test(
      urlLower
    )
  ) {
    return {
      url: input.url,
      title: input.title,
      tier: 2,
      tierName: 'official_docs',
      badge: 'T2:DOCS',
      dateStamp,
      deadLink,
    };
  }

  if (/\b(github\.com|gitlab\.com|npmjs\.com|pypi\.org|crates\.io)/.test(urlLower)) {
    return {
      url: input.url,
      title: input.title,
      tier: 3,
      tierName: 'maintained_repo',
      badge: 'T3:REPO',
      dateStamp,
      deadLink,
    };
  }

  if (/\b(stackoverflow\.com|stackexchange\.com|reddit\.com|news\.ycombinator\.com|discourse\.)/.test(urlLower)) {
    return {
      url: input.url,
      title: input.title,
      tier: 4,
      tierName: 'forum',
      badge: 'T4:FORUM',
      dateStamp,
      deadLink,
    };
  }

  if (/\b(medium\.com|substack\.com|dev\.to|hashnode\.dev|blog\.)/.test(urlLower)) {
    return {
      url: input.url,
      title: input.title,
      tier: 4,
      tierName: 'blog',
      badge: 'T4:BLOG',
      dateStamp,
      deadLink,
    };
  }

  return {
    url: input.url,
    title: input.title,
    tier: 5,
    tierName: 'aggregator',
    badge: 'T5:AGGREGATOR',
    dateStamp,
    deadLink,
  };
}

export function evaluateProvenanceSet(
  inputs: Array<{ url: string; title?: string; publishedAt?: string; statusCode?: number }>
): ProvenanceEvaluation {
  const sources = inputs
    .map(rankSourceProvenance)
    .sort((a, b) => a.tier - b.tier);

  const liveSources = sources.filter((s) => !s.deadLink);
  const onlyTier4Or5 =
    liveSources.length > 0 && liveSources.every((s) => s.tier >= 4);

  return {
    sources,
    weakEvidenceNote: onlyTier4Or5
      ? 'Note: Load-bearing claims in this response rely exclusively on tier 4–5 community or aggregator sources rather than primary documentation.'
      : null,
  };
}

// ============================================================================
// 24.9 CONTRADICTION DETECTION
// ============================================================================
export interface ClaimRecord {
  id: string;
  subject: string;
  predicate: string;
  value: string;
  source: 'memory' | 'thread' | 'assistant';
  timestamp: number;
}

export interface ContradictionConflict {
  id: string;
  subject: string;
  predicate: string;
  existingClaim: ClaimRecord;
  incomingClaim: ClaimRecord;
  resolved: boolean;
  winner?: ClaimRecord;
  loser?: ClaimRecord;
}

export class ContradictionDetector {
  private claims = new Map<string, ClaimRecord>(); // key: subject::predicate
  private history: ClaimRecord[] = [];
  private conflicts = new Map<string, ContradictionConflict>();

  private makeKey(subject: string, predicate: string): string {
    return `${subject.trim().toLowerCase()}::${predicate.trim().toLowerCase()}`;
  }

  /**
   * Compares an incoming claim against stored memories and earlier thread claims.
   * Never silently overwrites a conflicting claim: instead records a side-by-side
   * conflict for explicit resolution.
   */
  ingestClaim(params: {
    subject: string;
    predicate: string;
    value: string;
    source?: 'memory' | 'thread' | 'assistant';
  }): { conflict: ContradictionConflict | null; stored: boolean } {
    const key = this.makeKey(params.subject, params.predicate);
    const incoming: ClaimRecord = {
      id: `claim_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      subject: params.subject.trim(),
      predicate: params.predicate.trim(),
      value: params.value.trim(),
      source: params.source || 'thread',
      timestamp: Date.now(),
    };

    const existing = this.claims.get(key);
    if (!existing) {
      this.claims.set(key, incoming);
      this.history.push(incoming);
      return { conflict: null, stored: true };
    }

    if (existing.value.toLowerCase() === incoming.value.toLowerCase()) {
      return { conflict: null, stored: true };
    }

    // Conflict detected — do NOT silently overwrite!
    const conflict: ContradictionConflict = {
      id: `conflict_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      subject: incoming.subject,
      predicate: incoming.predicate,
      existingClaim: existing,
      incomingClaim: incoming,
      resolved: false,
    };
    this.conflicts.set(conflict.id, conflict);
    return { conflict, stored: false };
  }

  /**
   * Resolves a contradiction by writing the chosen winner to active memory
   * and preserving the loser in history.
   */
  resolveConflict(conflictId: string, choose: 'existing' | 'incoming'): ContradictionConflict {
    const conflict = this.conflicts.get(conflictId);
    if (!conflict) {
      throw new Error(`Conflict ${conflictId} not found`);
    }

    const winner = choose === 'incoming' ? conflict.incomingClaim : conflict.existingClaim;
    const loser = choose === 'incoming' ? conflict.existingClaim : conflict.incomingClaim;

    const key = this.makeKey(conflict.subject, conflict.predicate);
    this.claims.set(key, winner);
    this.history.push(loser);

    conflict.resolved = true;
    conflict.winner = winner;
    conflict.loser = loser;
    return conflict;
  }

  getActiveClaim(subject: string, predicate: string): ClaimRecord | null {
    return this.claims.get(this.makeKey(subject, predicate)) || null;
  }

  getHistory(): ClaimRecord[] {
    return [...this.history];
  }

  listConflicts(): ContradictionConflict[] {
    return Array.from(this.conflicts.values());
  }
}

export const contradictionDetector = new ContradictionDetector();

// ============================================================================
// 24.10 CORRECTION CAPTURE (DELTA RULES CAPPED AT 40)
// ============================================================================
export const MAX_DERIVED_RULES = 40;

export interface CorrectionDelta {
  id: string;
  conversationId: string;
  originalText: string;
  editedText: string;
  candidateRule: string;
  status: 'pending' | 'accepted' | 'dismissed';
  usageCount: number;
  createdAt: number;
  lastUsedAt: number;
}

export class CorrectionCaptureManager {
  private deltas = new Map<string, CorrectionDelta>();
  private acceptedRules: CorrectionDelta[] = [];

  deriveRuleFromEdit(originalText: string, editedText: string): string {
    const origLines = originalText.trim().split('\n');
    const editLines = editedText.trim().split('\n');

    if (editLines.length < origLines.length * 0.6) {
      return 'Keep responses concise and omit verbose filler paragraphs.';
    }
    if (!editedText.includes('```') && originalText.includes('```')) {
      return 'Prefer inline prose explanations over fenced code blocks when edited out.';
    }
    if (editedText.includes('```') && !originalText.includes('```')) {
      return 'Always include runnable code blocks when answering technical prompts.';
    }
    if (editedText.length < originalText.length) {
      return `Prefer tighter phrasing (${editedText.slice(0, 60).trim()}...) over verbose exposition.`;
    }
    return `Follow user correction preference: "${editedText.slice(0, 80).trim()}"`;
  }

  recordEdit(params: {
    conversationId: string;
    originalText: string;
    editedText: string;
    explicitRule?: string;
  }): CorrectionDelta {
    const now = Date.now();
    const candidateRule =
      params.explicitRule || this.deriveRuleFromEdit(params.originalText, params.editedText);

    const delta: CorrectionDelta = {
      id: `corr_${now}_${Math.random().toString(36).slice(2, 6)}`,
      conversationId: params.conversationId,
      originalText: params.originalText,
      editedText: params.editedText,
      candidateRule,
      status: 'pending',
      usageCount: 0,
      createdAt: now,
      lastUsedAt: now,
    };
    this.deltas.set(delta.id, delta);
    return delta;
  }

  acceptRule(deltaId: string): CorrectionDelta {
    const delta = this.deltas.get(deltaId);
    if (!delta) throw new Error(`Correction delta ${deltaId} not found`);

    delta.status = 'accepted';
    delta.lastUsedAt = Date.now();

    const existingIdx = this.acceptedRules.findIndex((r) => r.id === deltaId);
    if (existingIdx === -1) {
      if (this.acceptedRules.length >= MAX_DERIVED_RULES) {
        // Evict least-used (and oldest lastUsedAt on tie)
        this.acceptedRules.sort((a, b) => {
          if (a.usageCount !== b.usageCount) return a.usageCount - b.usageCount;
          return a.lastUsedAt - b.lastUsedAt;
        });
        const evicted = this.acceptedRules.shift();
        if (evicted) {
          evicted.status = 'dismissed';
        }
      }
      this.acceptedRules.push(delta);
    }

    return delta;
  }

  dismissRule(deltaId: string): void {
    const delta = this.deltas.get(deltaId);
    if (delta) {
      delta.status = 'dismissed';
    }
    this.acceptedRules = this.acceptedRules.filter((r) => r.id !== deltaId);
  }

  getAcceptedRulesForPrompt(markUsed = true): string[] {
    const now = Date.now();
    return this.acceptedRules.map((r) => {
      if (markUsed) {
        r.usageCount++;
        r.lastUsedAt = now;
      }
      return r.candidateRule;
    });
  }

  listAcceptedRules(): CorrectionDelta[] {
    return [...this.acceptedRules];
  }

  listPendingRules(): CorrectionDelta[] {
    return Array.from(this.deltas.values()).filter((d) => d.status === 'pending');
  }
}

export const correctionCaptureManager = new CorrectionCaptureManager();

// ============================================================================
// 24.11 BLIND A/B AND ELO
// ============================================================================
export const ELO_VOTE_THRESHOLD = 20;

export interface BlindABSession {
  id: string;
  category: string;
  optionA: { label: 'Response A'; content: string; hiddenModelId?: string };
  optionB: { label: 'Response B'; content: string; hiddenModelId?: string };
  picked?: 'A' | 'B';
  revealedModels?: { modelA: string; modelB: string };
}

export interface ModelCandidate {
  modelId: string;
  pricePerMillion: number;
  elo?: number;
}

export class BlindABEloManager {
  private sessions = new Map<string, {
    category: string;
    modelA: string;
    modelB: string;
    contentA: string;
    contentB: string;
    picked?: 'A' | 'B';
  }>();

  // category -> (modelId -> elo)
  private ratings = new Map<string, Map<string, number>>();
  // category -> total vote count
  private categoryVotes = new Map<string, number>();

  createSession(params: {
    category: string;
    modelA: string;
    contentA: string;
    modelB: string;
    contentB: string;
  }): BlindABSession {
    const id = `ab_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    this.sessions.set(id, {
      category: params.category,
      modelA: params.modelA,
      modelB: params.modelB,
      contentA: params.contentA,
      contentB: params.contentB,
    });

    // Return anonymized view: model identities are NOT exposed before pick!
    return {
      id,
      category: params.category,
      optionA: { label: 'Response A', content: params.contentA },
      optionB: { label: 'Response B', content: params.contentB },
    };
  }

  recordPick(sessionId: string, pick: 'A' | 'B'): BlindABSession & {
    eloA: number;
    eloB: number;
    categoryVotes: number;
  } {
    const session = this.sessions.get(sessionId);
    if (!session) throw new Error(`Blind A/B session ${sessionId} not found`);

    session.picked = pick;
    const cat = session.category;
    if (!this.ratings.has(cat)) {
      this.ratings.set(cat, new Map());
    }
    const catMap = this.ratings.get(cat)!;
    const ratingA = catMap.get(session.modelA) ?? 1500;
    const ratingB = catMap.get(session.modelB) ?? 1500;

    const expectedA = 1 / (1 + Math.pow(10, (ratingB - ratingA) / 400));
    const expectedB = 1 - expectedA;
    const scoreA = pick === 'A' ? 1 : 0;
    const scoreB = pick === 'B' ? 1 : 0;
    const K = 32;

    const newEloA = Math.round(ratingA + K * (scoreA - expectedA));
    const newEloB = Math.round(ratingB + K * (scoreB - expectedB));

    catMap.set(session.modelA, newEloA);
    catMap.set(session.modelB, newEloB);

    const votes = (this.categoryVotes.get(cat) ?? 0) + 1;
    this.categoryVotes.set(cat, votes);

    return {
      id: sessionId,
      category: cat,
      optionA: { label: 'Response A', content: session.contentA },
      optionB: { label: 'Response B', content: session.contentB },
      picked: pick,
      revealedModels: {
        modelA: session.modelA,
        modelB: session.modelB,
      },
      eloA: newEloA,
      eloB: newEloB,
      categoryVotes: votes,
    };
  }

  getElo(category: string, modelId: string): number {
    return this.ratings.get(category)?.get(modelId) ?? 1500;
  }

  getCategoryVotes(category: string): number {
    return this.categoryVotes.get(category) ?? 0;
  }

  /**
   * Sorts candidate models for a category:
   * - If category has >= 20 votes, sorts by Elo descending.
   * - Otherwise (< 20 votes), sorts by price ascending.
   */
  rankCandidates(category: string, candidates: ModelCandidate[]): ModelCandidate[] {
    const votes = this.getCategoryVotes(category);
    const enriched = candidates.map((c) => ({
      ...c,
      elo: this.getElo(category, c.modelId),
    }));

    if (votes >= ELO_VOTE_THRESHOLD) {
      return enriched.sort((a, b) => (b.elo ?? 1500) - (a.elo ?? 1500));
    }
    return enriched.sort((a, b) => a.pricePerMillion - b.pricePerMillion);
  }
}

export const blindABEloManager = new BlindABEloManager();

// ============================================================================
// 24.17 LAST TIER
// - Local-only toggle with outbound network request log assertion
// - Voice call mode state & VAD turn handler
// - Cross-device encrypted sync (passphrase-derived AES-256-GCM blob)
// - Publish static artifact page (/published/:id)
// - UI i18n dictionary
// - Profile separation (isolated memory & keys per profile)
// - Distill thread into JSONL fine-tuning dataset
// ============================================================================

export interface OutboundRequestRecord {
  url: string;
  timestamp: number;
  blockedByLocalOnly: boolean;
}

export class LocalOnlyGuard {
  private enabled = false;
  private outboundRequests: OutboundRequestRecord[] = [];

  setLocalOnly(enabled: boolean): void {
    this.enabled = enabled;
  }

  isLocalOnly(): boolean {
    return this.enabled;
  }

  /**
   * Called before any remote API or crawler request.
   * When local-only mode is enabled, non-local hosts are hard-blocked and zero remote calls are made.
   */
  assertAllowedUrl(url: string): void {
    const isLocal = /^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(?::\d+)?(\/|$)/i.test(url);
    if (this.enabled && !isLocal) {
      throw new Error(`LOCAL_ONLY_MODE_ACTIVE: Remote outbound request to ${url} is blocked.`);
    }
    if (!isLocal) {
      this.outboundRequests.push({
        url,
        timestamp: Date.now(),
        blockedByLocalOnly: false,
      });
    }
  }

  getRemoteRequestCount(): number {
    return this.outboundRequests.length;
  }

  clearRequestLog(): void {
    this.outboundRequests = [];
  }
}

export const localOnlyGuard = new LocalOnlyGuard();

// Cross-device encrypted sync with user passphrase
export function encryptSyncBlob(payload: unknown, passphrase: string): {
  ciphertext: string;
  iv: string;
  salt: string;
  authTag: string;
} {
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);
  const key = crypto.scryptSync(passphrase, salt, 32);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const json = JSON.stringify(payload);
  const encrypted = Buffer.concat([cipher.update(json, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return {
    ciphertext: encrypted.toString('base64'),
    iv: iv.toString('base64'),
    salt: salt.toString('base64'),
    authTag: authTag.toString('base64'),
  };
}

export function decryptSyncBlob<T = unknown>(
  blob: { ciphertext: string; iv: string; salt: string; authTag: string },
  passphrase: string
): T {
  const salt = Buffer.from(blob.salt, 'base64');
  const iv = Buffer.from(blob.iv, 'base64');
  const authTag = Buffer.from(blob.authTag, 'base64');
  const key = crypto.scryptSync(passphrase, salt, 32);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(blob.ciphertext, 'base64')),
    decipher.final(),
  ]);
  return JSON.parse(decrypted.toString('utf8')) as T;
}

// Published static artifact registry
export interface PublishedArtifactPage {
  id: string;
  title: string;
  htmlContent: string;
  publishedAt: number;
}

class PublishedArtifactStore {
  private pages = new Map<string, PublishedArtifactPage>();

  publish(params: { id?: string; title: string; content: string }): PublishedArtifactPage {
    const id = params.id || `pub_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const htmlContent = params.content.includes('<html')
      ? params.content
      : `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${params.title}</title>
</head>
<body>
${params.content}
</body>
</html>`;
    const page: PublishedArtifactPage = {
      id,
      title: params.title,
      htmlContent,
      publishedAt: Date.now(),
    };
    this.pages.set(id, page);
    return page;
  }

  get(id: string): PublishedArtifactPage | null {
    return this.pages.get(id) || null;
  }
}

export const publishedArtifactStore = new PublishedArtifactStore();

// Profile Separation (isolated memory & keys per profile)
export interface UserProfileWorkspace {
  id: string;
  name: string;
  memories: Map<string, string>;
  secrets: Map<string, string>;
}

export class ProfileManager {
  private profiles = new Map<string, UserProfileWorkspace>();
  private activeProfileId = 'default';

  constructor() {
    this.ensureProfile('default', 'Default Profile');
  }

  ensureProfile(id: string, name = id): UserProfileWorkspace {
    if (!this.profiles.has(id)) {
      this.profiles.set(id, {
        id,
        name,
        memories: new Map(),
        secrets: new Map(),
      });
    }
    return this.profiles.get(id)!;
  }

  switchProfile(id: string): UserProfileWorkspace {
    const profile = this.ensureProfile(id);
    this.activeProfileId = id;
    return profile;
  }

  setMemory(profileId: string, key: string, value: string): void {
    this.ensureProfile(profileId).memories.set(key, value);
  }

  getMemory(profileId: string, key: string): string | null {
    return this.ensureProfile(profileId).memories.get(key) ?? null;
  }

  getActiveProfileId(): string {
    return this.activeProfileId;
  }
}

export const profileManager = new ProfileManager();

// Distill thread into JSONL fine-tuning dataset
export function distillThreadToJSONL(
  messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }>,
  systemInstruction = 'You are a direct, high-precision engineering assistant.'
): string {
  const lines: string[] = [];
  for (let i = 0; i < messages.length; i++) {
    const msg = messages[i];
    if (msg.role === 'user') {
      const next = messages[i + 1];
      if (next && next.role === 'assistant') {
        const entry = {
          messages: [
            { role: 'system', content: systemInstruction },
            { role: 'user', content: msg.content },
            { role: 'assistant', content: next.content },
          ],
        };
        lines.push(JSON.stringify(entry));
      }
    }
  }
  return lines.join('\n');
}

// UI i18n dictionary
export const UI_I18N: Record<string, Record<string, string>> = {
  en: {
    newChat: 'New Conversation',
    settings: 'Settings',
    localOnly: 'Local-Only Mode',
    zeroRetention: 'Zero-Retention Mode',
    send: 'Send',
  },
  es: {
    newChat: 'Nueva Conversación',
    settings: 'Configuración',
    localOnly: 'Modo Solo Local',
    zeroRetention: 'Modo Cero Retención',
    send: 'Enviar',
  },
  fr: {
    newChat: 'Nouvelle Conversation',
    settings: 'Paramètres',
    localOnly: 'Mode Local Uniquement',
    zeroRetention: 'Mode Sans Rétention',
    send: 'Envoyer',
  },
  de: {
    newChat: 'Neues Gespräch',
    settings: 'Einstellungen',
    localOnly: 'Nur-Lokal-Modus',
    zeroRetention: 'Null-Speicherung-Modus',
    send: 'Senden',
  },
  ja: {
    newChat: '新しい会話',
    settings: '設定',
    localOnly: 'ローカル専用モード',
    zeroRetention: 'ゼロ保持モード',
    send: '送信',
  },
};

export function translateUI(locale: string, key: string): string {
  const dict = UI_I18N[locale] || UI_I18N.en;
  return dict[key] || UI_I18N.en[key] || key;
}
