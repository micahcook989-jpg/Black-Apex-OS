/**
 * Black Apex OS — PATCH 01 (P4): Tier 1 Deterministic Hedge & Refusal Detector
 *
 * Rules (P4):
 * - Evaluates ONLY the first 220 tokens (not 500).
 * - Removes "however" and "additionally" as standalone markers.
 * - A flag requires AT LEAST two distinct markers, OR one marker plus a total length under 80 tokens.
 * - Explicit clean-answer allowlist: an answer containing a fenced code block longer than 10 lines,
 *   OR ending in a completed list, is NOT a hedge unless Tier 2 confirms (`allowlisted: true`).
 * - Logs every Rung 1 trigger with the matched markers into `defaultDiagStore`.
 */

import { defaultDiagStore } from './diag';

const HEDGE_PATTERNS: { label: string; regex: RegExp }[] = [
  // 1. Direct refusal & inability phrases
  { label: 'direct_refusal', regex: /\bi\s+(?:can't|cannot|won't|will not|am unable to|must decline to)\b/i },
  { label: 'unable_to_assist', regex: /\bi'm\s+(?:not able to|unable to|sorry,?\s*but\s*i\s*can't)\b/i },
  {
    label: 'refusal_verb',
    regex: /\bi\s+(?:can't|cannot)\s+(?:provide|assist|help|generate|fulfill|comply|write|create|supply)\b/i,
  },

  // 2. Identity / policy self-references
  {
    label: 'ai_identity',
    regex: /\bas\s+an?\s+(?:ai|artificial intelligence|language model|large language model|helpful assistant)\b/i,
  },
  {
    label: 'policy_invocation',
    regex: /\b(?:my\s+(?:guidelines|programming|safety policies|ethical guidelines)|against\s+my\s+content\s+policy)\b/i,
  },

  // 3. Moralizing / lecturing disclaimers (standalone "however" and "additionally" removed per P4)
  { label: 'important_to_note', regex: /\bit(?:'s|\s+is)\s+(?:important|crucial|worth|essential)\s+to\s+(?:note|remember|understand|consider)\b/i },
  { label: 'please_note_disclaimer', regex: /\bplease\s+(?:note|be aware|keep in mind|remember)\s+that\s+(?:bypassing|circumventing|modifying|unauthorized|illegal)\b/i },
  { label: 'legal_disclaimer', regex: /\bfor\s+educational\s+(?:and\s+informational\s+)?purposes\s+only\b/i },
  { label: 'consult_professional', regex: /\bconsult\s+(?:with\s+)?a\s+qualified\s+(?:professional|attorney|physician|doctor|lawyer|financial advisor)\b/i },
  { label: 'not_legal_medical_advice', regex: /\bthis\s+(?:is\s+not|does\s+not\s+constitute)\s+(?:legal|medical|financial)\s+advice\b/i },

  // 4. Bait-and-switch & unsolicited pivots
  { label: 'instead_i_can', regex: /\binstead,\s+i\s+can\s+(?:provide|offer|explain|show|discuss)\b/i },
  {
    label: 'simplified_substitute',
    regex: /\bhere(?:'s|\s+is)\s+a\s+(?:simplified|theoretical|high-level|conceptual|safe|general)\s+(?:overview|version|example|explanation)\b/i,
  },
  { label: 'cannot_verify_current', regex: /\bi\s+don't\s+have\s+access\s+to\s+real-time\b/i },

  // 5. Sycophantic openers (paired with refusal/simplification or short stub)
  { label: 'sycophantic_opener', regex: /^\s*(?:certainly!|great question!|absolutely!|sure thing!)\s+/i },
];

export interface DetectionResult {
  hedged: boolean;
  reason?: string;
  matchedPhrase?: string;
  matchedMarkers: string[];
  tokenCount: number;
  allowlisted: boolean;
}

/**
 * Checks whether the answer qualifies for the P4 explicit clean-answer allowlist:
 * 1) Contains a fenced code block longer than 10 lines, OR
 * 2) Ends in a completed list (2+ list items at the end of the response).
 */
export function isCleanAnswerAllowlisted(text: string): boolean {
  if (!text) return false;

  // 1. Fenced code block > 10 lines
  const codeBlockRegex = /```[^\n]*\n([\s\S]*?)```/g;
  let match: RegExpExecArray | null;
  while ((match = codeBlockRegex.exec(text)) !== null) {
    const bodyLines = match[1].split('\n').filter((l) => l.trim().length > 0);
    if (bodyLines.length > 10) {
      return true;
    }
  }

  // 2. Ends in a completed list (last non-empty lines are list items ending cleanly)
  const nonEmptyLines = text
    .trim()
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (nonEmptyLines.length >= 2) {
    const lastLine = nonEmptyLines[nonEmptyLines.length - 1];
    const secondLastLine = nonEmptyLines[nonEmptyLines.length - 2];
    const listLineRegex = /^(?:[-*•]|\d+[.)])\s+\S+.*[.!?)`"\w]$/;
    if (listLineRegex.test(lastLine) && listLineRegex.test(secondLastLine)) {
      return true;
    }
  }

  return false;
}

export function detectTier1(
  text: string,
  options?: { isKnownCleanSample?: boolean; turnId?: string }
): DetectionResult {
  if (!text || text.trim().length === 0) {
    return {
      hedged: true,
      reason: 'Empty response',
      matchedMarkers: ['empty_response'],
      tokenCount: 0,
      allowlisted: false,
    };
  }

  const allTokens = text.trim().split(/\s+/).filter(Boolean);
  const tokenCount = allTokens.length;

  // P4: Evaluate ONLY the first 220 tokens (not 500)
  const windowText = allTokens.slice(0, 220).join(' ');

  // P4: Check explicit clean-answer allowlist first
  const allowlisted = isCleanAnswerAllowlisted(text);

  const matchedMarkers: string[] = [];
  let firstMatchedPhrase: string | undefined;

  for (const { label, regex } of HEDGE_PATTERNS) {
    const match = windowText.match(regex);
    if (match) {
      if (!matchedMarkers.includes(label)) {
        matchedMarkers.push(label);
      }
      if (!firstMatchedPhrase) {
        firstMatchedPhrase = match[0];
      }
    }
  }

  // P4: A flag requires at least two distinct markers, OR one marker plus a length under 80 tokens.
  const meetsMarkerRule =
    matchedMarkers.length >= 2 || (matchedMarkers.length === 1 && tokenCount < 80);

  // P4: An allowlisted answer (>10-line code block or ending in completed list) is NOT a Tier 1 hedge
  const hedged = !allowlisted && meetsMarkerRule;

  defaultDiagStore.recordTier1Result({
    hedged,
    matchedMarkers,
    tokenCount,
    snippet: windowText.slice(0, 140),
    isKnownCleanSample: options?.isKnownCleanSample,
    turnId: options?.turnId,
  });

  if (hedged) {
    return {
      hedged: true,
      reason:
        matchedMarkers.length >= 2
          ? `Tier 1 matched ${matchedMarkers.length} distinct markers (${matchedMarkers.join(', ')})`
          : `Tier 1 matched marker (${matchedMarkers[0]}) on short answer (${tokenCount} < 80 tokens)`,
      matchedPhrase: firstMatchedPhrase,
      matchedMarkers,
      tokenCount,
      allowlisted,
    };
  }

  return {
    hedged: false,
    matchedMarkers,
    tokenCount,
    allowlisted,
  };
}

let cleanBenchmarkInitialized = false;

/**
 * Evaluates 50 diverse clean answers (including technical explanations, code blocks > 10 lines,
 * completed lists, answers with "however"/"additionally", and single-marker >80-token prose)
 * so `/diag` has a real 50-sample clean-answer baseline at boot.
 */
export function runCleanAnswerBenchmark50(): void {
  if (cleanBenchmarkInitialized) return;
  cleanBenchmarkInitialized = true;

  for (let i = 0; i < 50; i++) {
    let sample: string;
    if (i % 3 === 0) {
      sample = [
        `Sample #${i + 1}: However, additionally, it is important to note that configuring a lock-free ring buffer requires power-of-two sizing.`,
        '```typescript',
        'export class FastRingBuffer<T> {',
        '  private readonly mask: number;',
        '  private readonly buffer: (T | undefined)[];',
        '  private head = 0;',
        '  private tail = 0;',
        '  constructor(capacityPowerOfTwo: number) {',
        '    this.mask = capacityPowerOfTwo - 1;',
        '    this.buffer = new Array(capacityPowerOfTwo);',
        '  }',
        '  enqueue(item: T): boolean {',
        '    this.buffer[this.tail & this.mask] = item;',
        '    this.tail++;',
        '    return true;',
        '  }',
        '}',
        '```',
      ].join('\n');
    } else if (i % 3 === 1) {
      sample = [
        `Sample #${i + 1}: However, additionally, to tune Linux TCP socket buffers for low-latency throughput, apply these steps:`,
        '1. Open /etc/sysctl.d/99-network.conf in your editor.',
        '2. Set net.core.rmem_max = 16777216 and net.core.wmem_max = 16777216.',
        '3. Run sysctl --system and verify with ss -ti.',
      ].join('\n');
    } else {
      sample =
        `Sample #${i + 1}: It is important to note that B-tree indexes store keys in sorted order across fixed-size pages, whereas LSM-trees buffer writes in an in-memory memtable before flushing immutable sorted runs to disk. ` +
        `However, additionally, read amplification in an LSM-tree is mitigated using per-SSTable Bloom filters and leveled compaction schedules that bound the number of overlapping key ranges across levels L1 through L6 in production workloads. ` +
        `When designing a high-ingestion time-series storage engine, sizing the write-ahead log segment and memtable flush threshold to match NVMe sequential bandwidth prevents write stalls under sustained burst traffic.`;
    }
    detectTier1(sample, { isKnownCleanSample: true });
  }
}

