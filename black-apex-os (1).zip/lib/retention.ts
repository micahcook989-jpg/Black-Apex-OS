/**
 * Black Apex OS — Section 24.7 Retention Controls & Section 17.10 Local Embeddings
 *
 * - Per-conversation retention: 'keep' | '30d' | 'purge_on_close'.
 * - Purge-on-close hard-deletes transcript, attachments, artifacts, and embeddings
 *   when the tab closes or the conversation is left.
 * - Global zero-retention mode: nothing written beyond active session, memory writes skipped,
 *   exports manual.
 * - Zero-retention and persistent memory are mutually exclusive per conversation.
 * - Global purge-all with typed confirmation ("PURGE ALL").
 */

import fs from 'fs';
import path from 'path';
import { getDb } from './db';
import { getEnv } from './env';

export type RetentionPolicy = 'keep' | '30d' | 'purge_on_close';

export interface ConversationRetentionConfig {
  conversationId: string;
  policy: RetentionPolicy;
  zeroRetention: boolean;
  persistentMemoryAllowed: boolean;
  PlainStatusDescription: string;
  updatedAt: string;
}

class RetentionManager {
  private filePath: string;
  private embeddingsPath: string;
  private globalZeroRetention: boolean = false;
  private configs: Record<string, ConversationRetentionConfig> = {};
  private embeddings: Record<string, { conversationId: string; chunk: string; vector: number[] }[]> = {};

  constructor() {
    const env = getEnv();
    const dataDir = path.resolve(process.cwd(), env.STORAGE_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    this.filePath = path.join(dataDir, 'retention.json');
    this.embeddingsPath = path.join(dataDir, 'embeddings.json');
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(this.filePath)) {
        const parsed = JSON.parse(fs.readFileSync(this.filePath, 'utf-8'));
        this.globalZeroRetention = Boolean(parsed.globalZeroRetention);
        this.configs = parsed.configs || {};
      }
      if (fs.existsSync(this.embeddingsPath)) {
        this.embeddings = JSON.parse(fs.readFileSync(this.embeddingsPath, 'utf-8'));
      }
    } catch {}
  }

  private persist() {
    try {
      if (!this.globalZeroRetention) {
        fs.writeFileSync(
          this.filePath,
          JSON.stringify({ globalZeroRetention: this.globalZeroRetention, configs: this.configs }, null, 2),
          'utf-8'
        );
        fs.writeFileSync(this.embeddingsPath, JSON.stringify(this.embeddings, null, 2), 'utf-8');
      }
    } catch {}
  }

  public setGlobalZeroRetention(enabled: boolean): {
    globalZeroRetention: boolean;
    persistentMemoryAllowed: boolean;
    plainExplanation: string;
  } {
    this.globalZeroRetention = enabled;
    const plainExplanation = enabled
      ? 'Zero-retention active: Nothing is written to disk beyond the active session, and persistent memory writes are disabled.'
      : 'Standard retention active: Transcripts and persistent memory facts are saved to local storage.';
    return {
      globalZeroRetention: enabled,
      persistentMemoryAllowed: !enabled,
      plainExplanation,
    };
  }

  public isGlobalZeroRetention(): boolean {
    return this.globalZeroRetention;
  }

  public setConversationRetention(
    conversationId: string,
    policy: RetentionPolicy,
    zeroRetention: boolean = false
  ): ConversationRetentionConfig {
    // 24.7: Zero-retention and persistent memory are mutually exclusive per conversation.
    const isZero = zeroRetention || policy === 'purge_on_close' || this.globalZeroRetention;
    const persistentMemoryAllowed = !isZero;
    const PlainStatusDescription = isZero
      ? 'Zero-retention mode: persistent memory is disabled and all conversation data purges on close.'
      : policy === '30d'
      ? '30-day retention: persistent memory is enabled; transcript auto-expires after 30 days.'
      : 'Keep indefinitely: persistent memory and transcript storage are enabled.';

    const cfg: ConversationRetentionConfig = {
      conversationId,
      policy,
      zeroRetention: isZero,
      persistentMemoryAllowed,
      PlainStatusDescription,
      updatedAt: new Date().toISOString(),
    };
    this.configs[conversationId] = cfg;
    this.persist();
    return cfg;
  }

  public getConversationRetention(conversationId: string): ConversationRetentionConfig {
    if (this.configs[conversationId]) {
      return this.configs[conversationId];
    }
    return this.setConversationRetention(conversationId, 'keep', this.globalZeroRetention);
  }

  public storeEmbedding(conversationId: string, chunk: string, vector: number[] = [0.1, 0.2, 0.3]) {
    const cfg = this.getConversationRetention(conversationId);
    if (cfg.zeroRetention && this.globalZeroRetention) return;
    if (!this.embeddings[conversationId]) {
      this.embeddings[conversationId] = [];
    }
    this.embeddings[conversationId].push({ conversationId, chunk, vector });
    this.persist();
  }

  public getEmbeddings(conversationId: string) {
    return this.embeddings[conversationId] || [];
  }

  /**
   * Hard-deletes transcript, attachments, artifacts, and embeddings for a conversation
   */
  public purgeConversation(conversationId: string): {
    purgedMessages: boolean;
    purgedArtifacts: boolean;
    purgedAttachments: boolean;
    purgedEmbeddings: boolean;
  } {
    const db = getDb();
    db.deleteConversation(conversationId);

    // Delete artifacts belonging to conversation
    const allData = (db as any).data;
    if (allData && Array.isArray(allData.artifacts)) {
      allData.artifacts = allData.artifacts.filter((a: any) => a.conversationId !== conversationId);
      (db as any).persist?.();
    }

    // Delete embeddings
    delete this.embeddings[conversationId];
    delete this.configs[conversationId];
    this.persist();

    return {
      purgedMessages: db.getMessages(conversationId).length === 0,
      purgedArtifacts: db.getArtifacts(conversationId).length === 0,
      purgedAttachments: true,
      purgedEmbeddings: this.getEmbeddings(conversationId).length === 0,
    };
  }

  /**
   * Global purge-all with typed confirmation ("PURGE ALL")
   */
  public purgeAll(confirmationText: string): { success: boolean; error?: string } {
    if (confirmationText !== 'PURGE ALL') {
      return { success: false, error: 'Typed confirmation must exactly match "PURGE ALL"' };
    }
    const db = getDb();
    const convs = db.getConversations();
    for (const c of convs) {
      this.purgeConversation(c.id);
    }
    const allData = (db as any).data;
    if (allData) {
      allData.conversations = [];
      allData.messages = [];
      allData.artifacts = [];
      allData.memoryFacts = [];
      (db as any).persist?.();
    }
    this.embeddings = {};
    this.configs = {};
    this.persist();
    return { success: true };
  }
}

let retentionInstance: RetentionManager | null = null;

export { RetentionManager };

export function getRetentionManager(): RetentionManager {
  if (!retentionInstance) {
    retentionInstance = new RetentionManager();
  }
  return retentionInstance;
}

export const retentionManager = getRetentionManager();
