import { GearLevel } from './gearing';

const FULL_OPENER_PATTERNS = [
  /^(?:Certainly|Of course|Great question|Sure thing|Absolutely|Happy to help|Here's a breakdown|Let me break this down)[!,.]?\s*/i,
  /^(?:Sure|Definitely|I'd be happy to help|I'd be happy to|Glad to assist)[!,.]?\s*/i,
];

// In CHAT gear (22.8 / 22.9): leaves warmth ("yeah", "sure", "so") and contractions alone;
// still strips banned enthusiasm theater ("Great question", "I'd be happy to", "Certainly!")
const CHAT_BANNED_THEATER_PATTERNS = [
  /^(?:Great question|I'd be happy to help|I'd be happy to|Happy to help|Glad to assist|Certainly!|Absolutely!)[!,.]?\s*/i,
];

const DISCLAIMER_SENTENCE_PATTERNS = [
  /(?:^|\.\s+)(?:It's important to note|It is important to note|It's worth noting|It is worth noting|Keep in mind|That said|Please note that)[^.!?]*[.!?]/gi,
];

const TRAILING_OFFER_PATTERNS = [
  /(?:\n|^)\s*(?:Let me know if (?:you'd like|you would like|you need|you have)|Feel free to (?:ask|reach out)|Hope this helps|If you have any questions|Let me know if there's anything else)[^.!?\n]*[.!?]?\s*$/i,
];

const DISCLAIMER_WORDS = ['always', 'consult', 'professional', 'varies'];

export function stripResponse(
  text: string,
  enabled: boolean = true,
  gear: GearLevel = 'TASK'
): { cleaned: string; stripped: boolean } {
  if (!enabled || !text) {
    return { cleaned: text, stripped: false };
  }

  // Split content into code blocks and prose blocks so fenced code (and inline math) are untouched
  const segments: { isCode: boolean; content: string }[] = [];
  const codeBlockRegex = /```[\s\S]*?```/g;
  let lastIndex = 0;
  let match: RegExpExecArray | null;

  while ((match = codeBlockRegex.exec(text)) !== null) {
    if (match.index > lastIndex) {
      segments.push({ isCode: false, content: text.slice(lastIndex, match.index) });
    }
    segments.push({ isCode: true, content: match[0] });
    lastIndex = match.index + match[0].length;
  }
  if (lastIndex < text.length) {
    segments.push({ isCode: false, content: text.slice(lastIndex) });
  }

  let wasModified = false;
  const openerPatterns = gear === 'CHAT' ? CHAT_BANNED_THEATER_PATTERNS : FULL_OPENER_PATTERNS;

  const processedSegments = segments.map((seg, idx) => {
    if (seg.isCode) return seg.content;

    let p = seg.content;

    // 1. Remove opener sentences on the first prose block (gear-aware per 22.8)
    if (idx === 0 || (segments[0].isCode && idx === 1)) {
      for (const pattern of openerPatterns) {
        if (pattern.test(p)) {
          p = p.replace(pattern, '');
          wasModified = true;
        }
      }
    }

    // 2. Remove sentences starting with disclaimer phrases
    for (const pattern of DISCLAIMER_SENTENCE_PATTERNS) {
      if (pattern.test(p)) {
        p = p.replace(pattern, '');
        wasModified = true;
      }
    }

    // 3. Remove standalone disclaimer paragraphs under 45 words containing always/consult/professional/varies
    const paragraphs = p.split(/\n\s*\n/);
    const cleanedParagraphs = paragraphs.filter((para) => {
      const trimmed = para.trim();
      const words = trimmed.split(/\s+/).filter(Boolean);
      if (words.length > 0 && words.length < 45) {
        const lower = trimmed.toLowerCase();
        const hasDisclaimerWord = DISCLAIMER_WORDS.some((word) => lower.includes(word));
        const looksLikeDisclaimer =
          hasDisclaimerWord &&
          (lower.includes('disclaimer') ||
            lower.includes('doctor') ||
            lower.includes('lawyer') ||
            lower.includes('advice') ||
            lower.includes('caution') ||
            lower.includes('risk') ||
            lower.includes('guidance'));
        if (looksLikeDisclaimer) {
          wasModified = true;
          return false;
        }
      }
      return true;
    });
    p = cleanedParagraphs.join('\n\n');

    // 4. Remove trailing offers to continue
    if (idx === segments.length - 1 || (idx === segments.length - 2 && segments[segments.length - 1].isCode)) {
      for (const pattern of TRAILING_OFFER_PATTERNS) {
        if (pattern.test(p)) {
          p = p.replace(pattern, '');
          wasModified = true;
        }
      }
    }

    return p;
  });

  let result = processedSegments.join('');

  // 5. Clean up consecutive duplicate hedges and collapse triple+ blank lines into double
  const beforeBlanks = result;
  result = result.replace(/\n{3,}/g, '\n\n').trim();
  if (result !== beforeBlanks) {
    wasModified = true;
  }

  return { cleaned: result, stripped: wasModified || result !== text };
}
