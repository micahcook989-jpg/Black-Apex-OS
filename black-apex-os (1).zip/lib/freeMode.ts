/**
 * Black Apex OS — Addendum Section 32: Free-Only Operating Mode
 *
 * Implements:
 * - 32.1 Local-first inverted ladder (Rung 0 = Local, remote free tiers = escalation)
 * - 32.2 Free roster & real published limits with multi-key pool multiplication
 * - 32.3 Request economy (per-turn gear caps, 50% default daily/hourly caps, 20% interactive reserve, <15% rung skip)
 * - 32.4 Five-layer per-install Cache Hierarchy (Exact SHA-256, >=0.95 Semantic, Doc 7d, Search 24h, Fetch 6h + Cache-Control)
 * - 32.5 Request Coalescing (deduplicates identical concurrent in-flight promises)
 * - 32.6 Fair Scheduler (interactive preempts background, background drains only >20% quota, glyph queue position)
 * - 32.7 Adaptive Racing (requires both keys >40% quota, never in CHAT, never background, max 1 hop)
 * - 32.8 Degraded Modes (QUOTA_LOW, QUOTA_OUT, LOCAL_DOWN, ALL_DOWN with zero lost drafts)
 * - 32.9 Free Search Backends registry (SearXNG, Wayback, OpenAlex, CourtListener, SEC EDGAR, OSV, NVD, etc. — no Exa/paid defaults)
 * - 32.10 Free Media & Local Embeddings (Web Speech / Whisper.cpp, Piper / speechSynthesis, Pollinations / HF / ComfyUI, local embeddings)
 * - 32.14 Quota Dashboard real counters & tightest-tier sidebar meter
 */

import crypto from 'crypto';
import { GearLevel } from './gearing';
import { log } from './logger';

export type FreeProviderId = 'local' | 'groq' | 'gemini' | 'openrouter';
export type ExtendedGearLevel = GearLevel | 'RESEARCH';
export type DegradedModeState = 'NORMAL' | 'QUOTA_LOW' | 'QUOTA_OUT' | 'LOCAL_DOWN' | 'ALL_DOWN';

// ============================================================================
// 32.2 & 32.3 FREE ROSTER, PUBLISHED LIMITS & REQUEST ECONOMY
// ============================================================================

export const GEAR_TURN_REQUEST_CAPS: Record<ExtendedGearLevel, number> = {
  CHAT: 1,
  TASK: 3,
  HEAVY: 6,
  DEEP: 10,
  RESEARCH: 40,
};

export interface ProviderPublishedSpec {
  provider: FreeProviderId;
  displayName: string;
  role: string;
  publishedRpm: number;
  publishedRpd: number;
  defaultDailyCap: number; // ~50% of published limit per key
  defaultHourlyCap: number;
  notes: string;
}

export const FREE_PROVIDER_ROSTER: Record<FreeProviderId, ProviderPublishedSpec> = {
  local: {
    provider: 'local',
    displayName: 'Local (Ollama / llama.cpp)',
    role: 'Primary (Rung 0) — uncensored-capable tags',
    publishedRpm: Number.POSITIVE_INFINITY,
    publishedRpd: Number.POSITIVE_INFINITY,
    defaultDailyCap: Number.POSITIVE_INFINITY,
    defaultHourlyCap: Number.POSITIVE_INFINITY,
    notes: 'No quota. Primary default generation path.',
  },
  groq: {
    provider: 'groq',
    displayName: 'Groq Free Tier',
    role: 'Fast tier & 4-token classifiers',
    publishedRpm: 30,
    publishedRpd: 14400,
    defaultDailyCap: 7200, // 50% of published limit
    defaultHourlyCap: 900,
    notes: '30 RPM, daily token/request cap per model.',
  },
  gemini: {
    provider: 'gemini',
    displayName: 'Gemini Free Tier',
    role: 'Reasoning tier — spent deliberately',
    publishedRpm: 15,
    publishedRpd: 500, // ~25 RPD on Pro, higher on Flash
    defaultDailyCap: 250, // 50% of published limit
    defaultHourlyCap: 45,
    notes: 'A handful of RPM and ~25 RPD on Pro, higher on Flash.',
  },
  openrouter: {
    provider: 'openrouter',
    displayName: 'OpenRouter :free Tier',
    role: 'Uncensored floor',
    publishedRpm: 20,
    publishedRpd: 50,
    defaultDailyCap: 25, // 50% of published 50 RPD limit
    defaultHourlyCap: 15,
    notes: '~20 RPM, ~50 RPD free (optional one-time $10 top-up raises to ~1000 RPD).',
  },
};

export interface ProviderKeyCounter {
  id: string;
  provider: FreeProviderId;
  maskedKey: string;
  healthy: boolean;
  healthScore: number;
  requestsToday: number;
  requestsThisHour: number;
  requestsThisMinute: number;
  tokensToday: number;
  dailyCap: number;
  hourlyCap: number;
  rpmLimit: number;
  lastRequestAt: number;
  cooldownUntil: number;
}

export interface ProviderQuotaSummary {
  provider: FreeProviderId;
  displayName: string;
  role: string;
  configured: boolean;
  keyCount: number;
  healthyKeyCount: number;
  requestsUsedToday: number;
  tokensUsedToday: number;
  effectiveDailyCap: number;
  remainingToday: number;
  remainingPercent: number; // 0..100
  rpmLimit: number;
  rpmUsedLastMinute: number;
  rpmHeadroom: number;
  resetAtIso: string;
  skippedInLadder: boolean;
  keys: ProviderKeyCounter[];
}

export interface RungSkipLogEntry {
  provider: FreeProviderId;
  remainingPercent: number;
  reason: string;
  timestamp: string;
}

export interface SurvivingDraft {
  id: string;
  conversationId: string;
  prompt: string;
  degradedState: DegradedModeState;
  plainReason: string;
  createdAt: string;
}

export class FreeQuotaManager {
  private keys = new Map<FreeProviderId, ProviderKeyCounter[]>();
  private skipLogs: RungSkipLogEntry[] = [];
  private localHealthy = false;
  private localConfigured = false;
  private resetTimestampMs: number;
  private survivingDrafts: SurvivingDraft[] = [];

  constructor() {
    this.keys.set('local', []);
    this.keys.set('groq', []);
    this.keys.set('gemini', []);
    this.keys.set('openrouter', []);
    const nextMidnight = new Date();
    nextMidnight.setUTCHours(24, 0, 0, 0);
    this.resetTimestampMs = nextMidnight.getTime();
  }

  public setLocalStatus(configured: boolean, healthy: boolean): void {
    this.localConfigured = configured;
    this.localHealthy = healthy;
    if (configured) {
      const existing = this.keys.get('local') || [];
      if (existing.length === 0) {
        this.registerKey('local', 'local-ollama-runtime');
      }
      for (const k of this.keys.get('local') || []) {
        k.healthy = healthy;
        k.healthScore = healthy ? 100 : 0;
      }
    }
  }

  public isLocalAvailable(): boolean {
    return this.localConfigured && this.localHealthy;
  }

  public isLocalConfigured(): boolean {
    return this.localConfigured;
  }

  public registerKey(
    provider: FreeProviderId,
    rawKey: string,
    overrides?: { dailyCap?: number; hourlyCap?: number; rpmLimit?: number }
  ): ProviderKeyCounter {
    const list = this.keys.get(provider) || [];
    const masked =
      rawKey.length > 8 ? `${rawKey.slice(0, 4)}...${rawKey.slice(-4)}` : rawKey || 'key';
    const existing = list.find((k) => k.id === `${provider}:${masked}`);
    if (existing) return existing;

    const spec = FREE_PROVIDER_ROSTER[provider];
    const entry: ProviderKeyCounter = {
      id: `${provider}-${list.length + 1}`,
      provider,
      maskedKey: masked,
      healthy: true,
      healthScore: 100,
      requestsToday: 0,
      requestsThisHour: 0,
      requestsThisMinute: 0,
      tokensToday: 0,
      dailyCap: overrides?.dailyCap ?? spec.defaultDailyCap,
      hourlyCap: overrides?.hourlyCap ?? spec.defaultHourlyCap,
      rpmLimit: overrides?.rpmLimit ?? spec.publishedRpm,
      lastRequestAt: 0,
      cooldownUntil: 0,
    };
    list.push(entry);
    this.keys.set(provider, list);
    return entry;
  }

  public getGearTurnCap(gear: ExtendedGearLevel): number {
    return GEAR_TURN_REQUEST_CAPS[gear] ?? 3;
  }

  public recordUsage(
    provider: FreeProviderId,
    tokens = 250,
    keyId?: string
  ): ProviderQuotaSummary {
    const list = this.keys.get(provider) || [];
    const target = keyId ? list.find((k) => k.id === keyId) : list.find((k) => k.healthy) || list[0];
    if (target) {
      target.requestsToday += 1;
      target.requestsThisHour += 1;
      target.requestsThisMinute += 1;
      target.tokensToday += Math.max(0, tokens);
      target.lastRequestAt = Date.now();
    }
    return this.getProviderSummary(provider);
  }

  public setRemainingPercentForTest(provider: FreeProviderId, percent: number, keyIndex = 0): void {
    const list = this.keys.get(provider) || [];
    if (list.length === 0) {
      this.registerKey(provider, `${provider}_test_key_1`);
    }
    const target = list[keyIndex] || list[0];
    if (!target || !Number.isFinite(target.dailyCap)) return;
    const clamped = Math.max(0, Math.min(100, percent));
    target.requestsToday = Math.round(target.dailyCap * (1 - clamped / 100));
  }

  public getKeyRemainingPercent(provider: FreeProviderId, keyId?: string): number {
    if (provider === 'local') return this.isLocalAvailable() ? 100 : 0;
    const list = this.keys.get(provider) || [];
    const target = keyId ? list.find((k) => k.id === keyId) : list[0];
    if (!target || !target.healthy) return 0;
    if (!Number.isFinite(target.dailyCap) || target.dailyCap <= 0) return 100;
    const remaining = Math.max(0, target.dailyCap - target.requestsToday);
    return Math.round((remaining / target.dailyCap) * 100);
  }

  public getProviderSummary(provider: FreeProviderId): ProviderQuotaSummary {
    const spec = FREE_PROVIDER_ROSTER[provider];
    const list = this.keys.get(provider) || [];

    if (provider === 'local') {
      const configured = this.localConfigured;
      const healthy = this.localHealthy;
      return {
        provider: 'local',
        displayName: spec.displayName,
        role: spec.role,
        configured,
        keyCount: configured ? Math.max(1, list.length) : 0,
        healthyKeyCount: configured && healthy ? Math.max(1, list.length) : 0,
        requestsUsedToday: list.reduce((acc, k) => acc + k.requestsToday, 0),
        tokensUsedToday: list.reduce((acc, k) => acc + k.tokensToday, 0),
        effectiveDailyCap: -1, // Unlimited
        remainingToday: -1, // Unlimited
        remainingPercent: configured && healthy ? 100 : 0,
        rpmLimit: -1,
        rpmUsedLastMinute: list.reduce((acc, k) => acc + k.requestsThisMinute, 0),
        rpmHeadroom: -1,
        resetAtIso: new Date(this.resetTimestampMs).toISOString(),
        skippedInLadder: !configured || !healthy,
        keys: list,
      };
    }

    const healthyKeys = list.filter((k) => k.healthy && k.cooldownUntil <= Date.now());
    const effectiveDailyCap = list.reduce((acc, k) => acc + k.dailyCap, 0);
    const requestsUsedToday = list.reduce((acc, k) => acc + k.requestsToday, 0);
    const tokensUsedToday = list.reduce((acc, k) => acc + k.tokensToday, 0);
    const remainingToday = Math.max(0, effectiveDailyCap - requestsUsedToday);
    const remainingPercent =
      effectiveDailyCap > 0
        ? Math.max(0, Math.min(100, Math.round((remainingToday / effectiveDailyCap) * 100)))
        : 0;

    const rpmLimit = list.reduce((acc, k) => acc + k.rpmLimit, 0);
    const rpmUsedLastMinute = list.reduce((acc, k) => acc + k.requestsThisMinute, 0);
    const rpmHeadroom = Math.max(0, rpmLimit - rpmUsedLastMinute);

    return {
      provider,
      displayName: spec.displayName,
      role: spec.role,
      configured: list.length > 0,
      keyCount: list.length,
      healthyKeyCount: healthyKeys.length,
      requestsUsedToday,
      tokensUsedToday,
      effectiveDailyCap,
      remainingToday,
      remainingPercent,
      rpmLimit,
      rpmUsedLastMinute,
      rpmHeadroom,
      resetAtIso: new Date(this.resetTimestampMs).toISOString(),
      skippedInLadder: list.length === 0 || remainingPercent < 15,
      keys: list,
    };
  }

  /**
   * 32.3: When a tier is under 15% remaining quota, its rung is skipped in the ladder
   * and the skip is logged, without user-facing error text.
   */
  public shouldSkipProviderRung(provider: FreeProviderId): boolean {
    if (provider === 'local') {
      return !this.isLocalAvailable();
    }
    const summary = this.getProviderSummary(provider);
    if (!summary.configured) {
      return true;
    }
    if (summary.remainingPercent < 15) {
      const entry: RungSkipLogEntry = {
        provider,
        remainingPercent: summary.remainingPercent,
        reason: `Tier ${provider} remaining quota (${summary.remainingPercent}%) is under the 15% floor; skipping rung silently.`,
        timestamp: new Date().toISOString(),
      };
      this.skipLogs.push(entry);
      log({
        event: 'free_tier_rung_skipped',
        provider,
        remainingPercent: summary.remainingPercent,
      });
      return true;
    }
    return false;
  }

  public getSkipLogs(): RungSkipLogEntry[] {
    return [...this.skipLogs];
  }

  /**
   * 32.3: Hard floor of 20% remaining quota reserved for interactive turns.
   * Background jobs may only consume surplus (> 20%).
   */
  public canRunJobClass(
    jobClass: 'interactive' | 'background',
    provider?: FreeProviderId
  ): boolean {
    if (provider === 'local') return this.isLocalAvailable();

    const remoteProviders: FreeProviderId[] = provider
      ? [provider]
      : (['groq', 'gemini', 'openrouter'] as FreeProviderId[]);
    const configuredSummaries = remoteProviders
      .map((p) => this.getProviderSummary(p))
      .filter((s) => s.configured);

    if (configuredSummaries.length === 0) {
      return this.isLocalAvailable();
    }

    const bestRemotePercent = Math.max(...configuredSummaries.map((s) => s.remainingPercent));

    if (jobClass === 'background') {
      // Background jobs strictly prohibited at or below 20% interactive reserve
      return bestRemotePercent > 20;
    }

    return bestRemotePercent > 0 || this.isLocalAvailable();
  }

  /**
   * 32.8 Degraded Modes evaluation:
   * - QUOTA_LOW (<20%): glyph changes, background jobs pause, remote rungs under 15% skip.
   * - QUOTA_OUT (0% remote): local-only, one line in settings, no banner.
   * - LOCAL_DOWN: remote-only, best-of-N off, DEEP downgraded to HEAVY.
   * - ALL_DOWN: composer stays live, message queues locally, retry card with plain reason; never lose a draft.
   */
  public evaluateDegradedMode(): {
    mode: DegradedModeState;
    settingsStatusLine: string;
    backgroundPaused: boolean;
    bestOfNAllowed: boolean;
    downgradeDeepToHeavy: boolean;
    tightestTier: { provider: string; remainingPercent: number };
  } {
    const remoteList: FreeProviderId[] = ['groq', 'gemini', 'openrouter'];
    const configuredRemotes = remoteList
      .map((p) => this.getProviderSummary(p))
      .filter((s) => s.configured);

    const anyRemoteQuota = configuredRemotes.some((s) => s.remainingToday > 0);
    const maxRemotePercent =
      configuredRemotes.length > 0
        ? Math.max(...configuredRemotes.map((s) => s.remainingPercent))
        : 0;
    const minRemote =
      configuredRemotes.length > 0
        ? configuredRemotes.reduce((prev, curr) =>
            curr.remainingPercent < prev.remainingPercent ? curr : prev
          )
        : null;

    const tightestTier = minRemote
      ? { provider: minRemote.provider.toUpperCase(), remainingPercent: minRemote.remainingPercent }
      : {
          provider: this.isLocalAvailable() ? 'LOCAL' : 'NONE',
          remainingPercent: this.isLocalAvailable() ? 100 : 0,
        };

    // ALL_DOWN: neither local nor any remote quota is available
    if (!this.isLocalAvailable() && !anyRemoteQuota) {
      return {
        mode: 'ALL_DOWN',
        settingsStatusLine:
          'All local and remote tiers are currently unavailable or out of quota — drafts are queued locally.',
        backgroundPaused: true,
        bestOfNAllowed: false,
        downgradeDeepToHeavy: true,
        tightestTier,
      };
    }

    // QUOTA_OUT: 0% remote quota remaining (or no remote keys configured), running local-only
    if (this.isLocalAvailable() && !anyRemoteQuota) {
      return {
        mode: 'QUOTA_OUT',
        settingsStatusLine:
          configuredRemotes.length === 0
            ? 'No remote keys configured — running local-only on Rung 0.'
            : 'Remote free quota exhausted for today — running local-only on Rung 0.',
        backgroundPaused: true,
        bestOfNAllowed: false,
        downgradeDeepToHeavy: false,
        tightestTier: { provider: 'REMOTE', remainingPercent: 0 },
      };
    }

    // LOCAL_DOWN (THIN profile): no local model configured/reachable, running remote-only
    if (!this.isLocalAvailable() && anyRemoteQuota) {
      if (minRemote && minRemote.remainingPercent < 20) {
        return {
          mode: 'QUOTA_LOW',
          settingsStatusLine:
            'THIN profile active — local model not reachable, running remote-only · Remote quota under 20% reserve; background jobs paused.',
          backgroundPaused: true,
          bestOfNAllowed: false,
          downgradeDeepToHeavy: true,
          tightestTier,
        };
      }
      return {
        mode: 'LOCAL_DOWN',
        settingsStatusLine: 'THIN profile active — local model not reachable, running remote-only.',
        backgroundPaused: false,
        bestOfNAllowed: false,
        downgradeDeepToHeavy: true,
        tightestTier,
      };
    }

    // Both local and remote are available; check if tightest/max remote is < 20%
    if (minRemote && minRemote.remainingPercent < 20) {
      return {
        mode: 'QUOTA_LOW',
        settingsStatusLine: `Remote tier ${minRemote.provider.toUpperCase()} under 20% reserve (${minRemote.remainingPercent}%) — background jobs paused.`,
        backgroundPaused: true,
        bestOfNAllowed: maxRemotePercent > 50,
        downgradeDeepToHeavy: false,
        tightestTier,
      };
    }

    return {
      mode: 'NORMAL',
      settingsStatusLine: 'Local-first (Rung 0 active) with healthy remote free escalation tiers.',
      backgroundPaused: false,
      bestOfNAllowed: maxRemotePercent > 50,
      downgradeDeepToHeavy: false,
      tightestTier,
    };
  }

  /**
   * 32.8 & 32.15 #6: Preserves user draft across every degraded state (including ALL_DOWN)
   * with a plain-words retry card reason so a draft is never lost.
   */
  public preserveDraft(conversationId: string, prompt: string): SurvivingDraft {
    const degraded = this.evaluateDegradedMode();
    const draft: SurvivingDraft = {
      id: `draft_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      conversationId,
      prompt,
      degradedState: degraded.mode,
      plainReason: degraded.settingsStatusLine,
      createdAt: new Date().toISOString(),
    };
    this.survivingDrafts.push(draft);
    return draft;
  }

  public getSurvivingDrafts(conversationId?: string): SurvivingDraft[] {
    if (!conversationId) return [...this.survivingDrafts];
    return this.survivingDrafts.filter((d) => d.conversationId === conversationId);
  }
}

// ============================================================================
// 32.10 LOCAL EMBEDDINGS (NO PAID EMBEDDING API)
// ============================================================================

/**
 * Computes a deterministic normalized 64-dimensional local vector embedding
 * using character 3-gram and word token hashing (compatible with local ONNX/CPU).
 * Makes zero network calls and requires no paid API.
 */
export function computeLocalEmbedding(text: string, dims = 64): number[] {
  const vec = new Array<number>(dims).fill(0);
  const normalized = (text || '')
    .toLowerCase()
    .replace(/[^\w\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!normalized) return vec;

  const words = normalized.split(' ');
  for (const word of words) {
    let h = 2166136261;
    for (let i = 0; i < word.length; i++) {
      h ^= word.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    const idx = Math.abs(h) % dims;
    vec[idx] += 1.5;
  }

  for (let i = 0; i <= normalized.length - 3; i++) {
    const trigram = normalized.slice(i, i + 3);
    let h = 5381;
    for (let j = 0; j < 3; j++) {
      h = (h * 33) ^ trigram.charCodeAt(j);
    }
    const idx = Math.abs(h) % dims;
    vec[idx] += 0.5;
  }

  const norm = Math.sqrt(vec.reduce((acc, v) => acc + v * v, 0));
  if (norm > 0) {
    for (let i = 0; i < dims; i++) {
      vec[i] = vec[i] / norm;
    }
  }
  return vec;
}

export function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length || a.length === 0) return 0;
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dot / denom;
}

// ============================================================================
// 32.4 FIVE-LAYER PER-INSTALL CACHE HIERARCHY
// ============================================================================

export interface PromptCacheEntry {
  exactHash: string;
  conversationStateHash: string;
  prompt: string;
  answer: string;
  embedding: number[];
  winningRung: number;
  createdAt: number;
}

interface TtlEntry<T> {
  value: T;
  expiresAt: number;
  contentHash?: string;
}

export class FreeCacheHierarchy {
  // Layer 1: Exact hash of conversation state + prompt
  private exactPromptCache = new Map<string, PromptCacheEntry>();
  // Layer 2: Semantic cache (>= 0.95 cosine similarity on local embedding)
  private semanticEntries: PromptCacheEntry[] = [];
  // Layer 3: Doc-grounding cache keyed by package@version, 7-day TTL
  private docCache = new Map<string, TtlEntry<any>>();
  // Layer 4: Search result cache keyed by normalized query, 24-hour TTL
  private searchCache = new Map<string, TtlEntry<any>>();
  // Layer 5: Fetch cache keyed by URL + content hash, respecting Cache-Control, default 6-hour TTL
  private fetchCache = new Map<string, TtlEntry<any>>();

  public static readonly DOC_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 days
  public static readonly SEARCH_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours
  public static readonly FETCH_DEFAULT_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours
  public static readonly SEMANTIC_THRESHOLD = 0.95;

  private computeExactKey(conversationState: string, prompt: string): {
    exactHash: string;
    stateHash: string;
  } {
    const stateHash = crypto
      .createHash('sha256')
      .update(conversationState || '')
      .digest('hex');
    const exactHash = crypto
      .createHash('sha256')
      .update(`${stateHash}::${prompt.trim()}`)
      .digest('hex');
    return { exactHash, stateHash };
  }

  /**
   * Looks up Layer 1 (exact hash) then Layer 2 (semantic similarity >= 0.95 within matching conversation state).
   */
  public lookupPrompt(
    conversationState: string,
    prompt: string
  ): {
    hit: boolean;
    layer: 'exact' | 'semantic' | null;
    similarity: number;
    answer?: string;
    winningRung?: number;
    receiptMark?: 'cached';
  } {
    const { exactHash, stateHash } = this.computeExactKey(conversationState, prompt);
    const exact = this.exactPromptCache.get(exactHash);
    if (exact) {
      return {
        hit: true,
        layer: 'exact',
        similarity: 1.0,
        answer: exact.answer,
        winningRung: exact.winningRung,
        receiptMark: 'cached',
      };
    }

    const queryEmbedding = computeLocalEmbedding(prompt);
    let bestMatch: PromptCacheEntry | null = null;
    let bestSim = 0;

    for (const candidate of this.semanticEntries) {
      if (candidate.conversationStateHash !== stateHash) continue;
      const sim = cosineSimilarity(queryEmbedding, candidate.embedding);
      if (sim >= FreeCacheHierarchy.SEMANTIC_THRESHOLD && sim > bestSim) {
        bestSim = sim;
        bestMatch = candidate;
      }
    }

    if (bestMatch) {
      return {
        hit: true,
        layer: 'semantic',
        similarity: bestSim,
        answer: bestMatch.answer,
        winningRung: bestMatch.winningRung,
        receiptMark: 'cached',
      };
    }

    return { hit: false, layer: null, similarity: 0 };
  }

  public storePromptAnswer(
    conversationState: string,
    prompt: string,
    answer: string,
    winningRung = 0
  ): void {
    const { exactHash, stateHash } = this.computeExactKey(conversationState, prompt);
    const entry: PromptCacheEntry = {
      exactHash,
      conversationStateHash: stateHash,
      prompt: prompt.trim(),
      answer,
      embedding: computeLocalEmbedding(prompt),
      winningRung,
      createdAt: Date.now(),
    };
    this.exactPromptCache.set(exactHash, entry);
    this.semanticEntries.push(entry);
  }

  // Layer 3: Doc-grounding cache (package@version, 7-day TTL)
  public getDoc(packageAtVersion: string): any | null {
    const key = packageAtVersion.trim().toLowerCase();
    const item = this.docCache.get(key);
    if (!item) return null;
    if (Date.now() > item.expiresAt) {
      this.docCache.delete(key);
      return null;
    }
    return item.value;
  }

  public setDoc(packageAtVersion: string, value: any, ttlMs = FreeCacheHierarchy.DOC_TTL_MS): void {
    const key = packageAtVersion.trim().toLowerCase();
    this.docCache.set(key, { value, expiresAt: Date.now() + ttlMs });
  }

  // Layer 4: Search result cache (normalized query, 24-hour TTL)
  public getSearch(query: string): any | null {
    const key = query.trim().toLowerCase().replace(/\s+/g, ' ');
    const item = this.searchCache.get(key);
    if (!item) return null;
    if (Date.now() > item.expiresAt) {
      this.searchCache.delete(key);
      return null;
    }
    return item.value;
  }

  public setSearch(query: string, value: any, ttlMs = FreeCacheHierarchy.SEARCH_TTL_MS): void {
    const key = query.trim().toLowerCase().replace(/\s+/g, ' ');
    this.searchCache.set(key, { value, expiresAt: Date.now() + ttlMs });
  }

  // Layer 5: Fetch cache (URL + content hash, respects Cache-Control max-age, default 6-hour TTL)
  public getFetch(url: string): { value: any; contentHash: string } | null {
    const item = this.fetchCache.get(url);
    if (!item) return null;
    if (Date.now() > item.expiresAt) {
      this.fetchCache.delete(url);
      return null;
    }
    return { value: item.value, contentHash: item.contentHash || '' };
  }

  public setFetch(url: string, value: string | any, cacheControlHeader?: string): string {
    let ttlMs = FreeCacheHierarchy.FETCH_DEFAULT_TTL_MS;
    if (cacheControlHeader) {
      if (/no-store/i.test(cacheControlHeader)) {
        return '';
      }
      const maxAgeMatch = cacheControlHeader.match(/max-age=(\d+)/i);
      if (maxAgeMatch) {
        ttlMs = Number(maxAgeMatch[1]) * 1000;
      }
    }
    const serialized = typeof value === 'string' ? value : JSON.stringify(value);
    const contentHash = crypto.createHash('sha256').update(serialized).digest('hex');
    this.fetchCache.set(url, {
      value,
      contentHash,
      expiresAt: Date.now() + ttlMs,
    });
    return contentHash;
  }

  public getStats() {
    return {
      exactPromptEntries: this.exactPromptCache.size,
      semanticPromptEntries: this.semanticEntries.length,
      docGroundingEntries: this.docCache.size,
      searchResultEntries: this.searchCache.size,
      fetchEntries: this.fetchCache.size,
      totalEntries:
        this.exactPromptCache.size +
        this.docCache.size +
        this.searchCache.size +
        this.fetchCache.size,
    };
  }

  public purgeAll(): void {
    this.exactPromptCache.clear();
    this.semanticEntries = [];
    this.docCache.clear();
    this.searchCache.clear();
    this.fetchCache.clear();
  }
}

// ============================================================================
// 32.5 REQUEST COALESCING
// ============================================================================

/**
 * Identical in-flight requests across concurrent turns attach to the first promise
 * instead of firing a second upstream request.
 */
export class RequestCoalescer {
  private inFlight = new Map<string, Promise<any>>();
  private coalescedHits = 0;

  public async execute<T>(key: string, fn: () => Promise<T>): Promise<{ value: T; coalesced: boolean }> {
    const existing = this.inFlight.get(key);
    if (existing) {
      this.coalescedHits++;
      const value = await existing;
      return { value, coalesced: true };
    }

    const promise = fn().finally(() => {
      this.inFlight.delete(key);
    });
    this.inFlight.set(key, promise);
    const value = await promise;
    return { value, coalesced: false };
  }

  public getCoalescedHits(): number {
    return this.coalescedHits;
  }
}

// ============================================================================
// 32.6 QUEUE & FAIR SCHEDULING
// ============================================================================

export interface ScheduledTaskResult<T> {
  result: T;
  queuePositionObserved: number;
}

/**
 * Single scheduler owning all outbound requests:
 * - Two classes: 'interactive' and 'background'.
 * - Interactive preempts background.
 * - Background drains only into surplus quota (> 20% remaining).
 * - Emits queue position for the glyph row (never a modal).
 */
export class FairRequestScheduler {
  private quotaManager: FreeQuotaManager;
  private activeInteractive = 0;
  private activeBackground = 0;
  private maxConcurrentInteractive = 2;
  private interactiveWaiters: Array<{
    run: () => void;
    onQueuePosition?: (pos: number) => void;
  }> = [];
  private backgroundWaiters: Array<{
    provider?: FreeProviderId;
    run: () => void;
    reject: (err: Error) => void;
  }> = [];

  constructor(quotaManager: FreeQuotaManager, maxConcurrentInteractive = 2) {
    this.quotaManager = quotaManager;
    this.maxConcurrentInteractive = maxConcurrentInteractive;
  }

  public async schedule<T>(
    jobClass: 'interactive' | 'background',
    fn: () => Promise<T>,
    options?: {
      provider?: FreeProviderId;
      onQueuePosition?: (position: number) => void;
    }
  ): Promise<ScheduledTaskResult<T>> {
    if (jobClass === 'background') {
      if (!this.quotaManager.canRunJobClass('background', options?.provider)) {
        throw new Error(
          'BACKGROUND_QUOTA_RESERVE_FLOOR: Background job paused because remaining quota is at or below the 20% interactive reserve.'
        );
      }

      if (this.activeInteractive > 0 || this.activeBackground >= 1) {
        await new Promise<void>((resolve, reject) => {
          this.backgroundWaiters.push({
            provider: options?.provider,
            run: resolve,
            reject,
          });
        });
      }

      // Re-verify surplus quota right before executing background job
      if (!this.quotaManager.canRunJobClass('background', options?.provider)) {
        throw new Error(
          'BACKGROUND_QUOTA_RESERVE_FLOOR: Background job aborted to preserve 20% interactive reserve.'
        );
      }

      this.activeBackground++;
      try {
        const result = await fn();
        return { result, queuePositionObserved: 0 };
      } finally {
        this.activeBackground = Math.max(0, this.activeBackground - 1);
        this.drain();
      }
    }

    // Interactive class: preempts background
    let queuePositionObserved = 0;
    if (this.activeInteractive >= this.maxConcurrentInteractive) {
      queuePositionObserved = this.interactiveWaiters.length + 1;
      options?.onQueuePosition?.(queuePositionObserved);
      await new Promise<void>((resolve) => {
        this.interactiveWaiters.push({
          run: resolve,
          onQueuePosition: options?.onQueuePosition,
        });
      });
    }

    this.activeInteractive++;
    try {
      const result = await fn();
      return { result, queuePositionObserved };
    } finally {
      this.activeInteractive = Math.max(0, this.activeInteractive - 1);
      this.drain();
    }
  }

  private drain(): void {
    while (
      this.interactiveWaiters.length > 0 &&
      this.activeInteractive < this.maxConcurrentInteractive
    ) {
      const next = this.interactiveWaiters.shift()!;
      this.interactiveWaiters.forEach((w, idx) => w.onQueuePosition?.(idx + 1));
      next.run();
    }

    if (
      this.activeInteractive === 0 &&
      this.interactiveWaiters.length === 0 &&
      this.activeBackground === 0 &&
      this.backgroundWaiters.length > 0
    ) {
      const nextBg = this.backgroundWaiters.shift()!;
      if (!this.quotaManager.canRunJobClass('background', nextBg.provider)) {
        nextBg.reject(
          new Error(
            'BACKGROUND_QUOTA_RESERVE_FLOOR: Background job paused because remaining quota dropped to <= 20%.'
          )
        );
      } else {
        nextBg.run();
      }
    }
  }
}

// ============================================================================
// 32.7 ADAPTIVE RACING
// ============================================================================

export interface AdaptiveRaceCheckInput {
  gear: ExtendedGearLevel;
  jobClass: 'interactive' | 'background';
  primaryQuotaPercent: number;
  secondaryQuotaPercent: number;
}

/**
 * 32.7 & PATCH 01 (P2) Adaptive Racing rules:
 * - Race only when BOTH candidate keys are above 50% quota (> 50).
 * - Never race in CHAT gear.
 * - Never race a background job.
 * - Race at most one hop; if the second candidate also breaches SLA, wait rather than firing a third.
 */
export function canAdaptiveRace(input: AdaptiveRaceCheckInput): {
  allowed: boolean;
  reason: string;
} {
  if (input.jobClass === 'background') {
    return { allowed: false, reason: 'Adaptive racing is disabled for background jobs.' };
  }
  if (input.gear === 'CHAT') {
    return { allowed: false, reason: 'Adaptive racing is disabled in CHAT gear.' };
  }
  if (input.primaryQuotaPercent <= 50 || input.secondaryQuotaPercent <= 50) {
    return {
      allowed: false,
      reason: `Adaptive racing requires both candidate keys above 50% quota (got ${input.primaryQuotaPercent}% and ${input.secondaryQuotaPercent}%).`,
    };
  }
  return { allowed: true, reason: 'Both candidates > 50% quota and interactive non-CHAT turn.' };
}

export async function runAdaptiveRace<T>(params: {
  candidates: Array<(signal: AbortSignal) => Promise<T>>;
  gear: ExtendedGearLevel;
  jobClass: 'interactive' | 'background';
  primaryQuotaPercent: number;
  secondaryQuotaPercent: number;
  slaMs?: number;
}): Promise<{
  result: T;
  winnerIndex: number;
  hopsFired: number;
  raced: boolean;
}> {
  if (params.candidates.length === 0) {
    throw new Error('No candidates supplied to runAdaptiveRace');
  }

  const gate = canAdaptiveRace({
    gear: params.gear,
    jobClass: params.jobClass,
    primaryQuotaPercent: params.primaryQuotaPercent,
    secondaryQuotaPercent: params.secondaryQuotaPercent,
  });

  // When racing is not allowed (e.g., < 40% quota, CHAT gear, or background), run only candidate 0 (0 hops)
  if (!gate.allowed || params.candidates.length === 1) {
    const ctrl = new AbortController();
    const result = await params.candidates[0](ctrl.signal);
    return { result, winnerIndex: 0, hopsFired: 0, raced: false };
  }

  // Race at most ONE hop (candidate 0 and candidate 1; never fire candidate 2 on SLA breach)
  const slaMs = params.slaMs ?? 1500;
  const ctrl0 = new AbortController();
  const ctrl1 = new AbortController();
  let hopsFired = 0;

  return new Promise((resolve, reject) => {
    let settled = false;
    let failures = 0;
    let secondLaunched = false;

    const launchSecond = () => {
      if (settled || secondLaunched) return;
      secondLaunched = true;
      hopsFired = 1; // At most 1 hop!
      params.candidates[1](ctrl1.signal)
        .then((res) => {
          if (settled) return;
          settled = true;
          ctrl0.abort();
          resolve({ result: res, winnerIndex: 1, hopsFired: 1, raced: true });
        })
        .catch((err) => {
          failures++;
          if (!settled && failures >= 2) {
            settled = true;
            reject(err);
          }
        });
    };

    const timer = setTimeout(() => {
      launchSecond();
    }, slaMs);

    params.candidates[0](ctrl0.signal)
      .then((res) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        ctrl1.abort();
        resolve({ result: res, winnerIndex: 0, hopsFired, raced: hopsFired > 0 });
      })
      .catch((err) => {
        failures++;
        clearTimeout(timer);
        if (!secondLaunched) {
          launchSecond();
        } else if (!settled && failures >= 2) {
          settled = true;
          reject(err);
        }
      });
  });
}

// ============================================================================
// 32.9 FREE SEARCH BACKENDS (REPLACES PAID DEFAULTS; NO EXA)
// ============================================================================

export interface FreeSearchBackendSpec {
  id: string;
  name: string;
  category:
    | 'primary'
    | 'archival'
    | 'academic'
    | 'legal'
    | 'corporate'
    | 'infrastructure'
    | 'code_advisories'
    | 'indie_news_stats'
    | 'optional_supplement';
  endpointTemplate: string;
  requiresOptionalKey?: string;
  freeTierNote: string;
}

export const FREE_SEARCH_BACKENDS: FreeSearchBackendSpec[] = [
  // Primary
  {
    id: 'searxng',
    name: 'SearXNG (Self-Hosted)',
    category: 'primary',
    endpointTemplate: '{SEARXNG_BASE_URL}/search?q={query}&format=json',
    freeTierNote: 'Self-hosted metasearch, zero quota.',
  },
  // Archival
  {
    id: 'wayback_cdx',
    name: 'Wayback Machine CDX',
    category: 'archival',
    endpointTemplate: 'https://web.archive.org/cdx/search/cdx?url={query}&output=json&limit=5',
    freeTierNote: 'Internet Archive CDX server, free.',
  },
  {
    id: 'common_crawl',
    name: 'Common Crawl Index',
    category: 'archival',
    endpointTemplate: 'https://index.commoncrawl.org/CC-MAIN-2024-10-index?url={query}&output=json',
    freeTierNote: 'Open web corpus index, free.',
  },
  // Academic
  {
    id: 'openalex',
    name: 'OpenAlex',
    category: 'academic',
    endpointTemplate: 'https://api.openalex.org/works?search={query}&per-page=5',
    freeTierNote: '100,000 requests/day free, no key required.',
  },
  {
    id: 'crossref',
    name: 'Crossref',
    category: 'academic',
    endpointTemplate: 'https://api.crossref.org/works?query={query}&rows=5',
    freeTierNote: 'Public scholarly DOI metadata API, free.',
  },
  {
    id: 'semantic_scholar',
    name: 'Semantic Scholar',
    category: 'academic',
    endpointTemplate: 'https://api.semanticscholar.org/graph/v1/paper/search?query={query}&limit=5',
    freeTierNote: 'Free public academic graph API.',
  },
  {
    id: 'pubmed',
    name: 'PubMed E-Utilities',
    category: 'academic',
    endpointTemplate:
      'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&term={query}&retmode=json',
    freeTierNote: 'NCBI public biomedical index, free.',
  },
  {
    id: 'arxiv',
    name: 'arXiv API',
    category: 'academic',
    endpointTemplate: 'https://export.arxiv.org/api/query?search_query=all:{query}&max_results=5',
    freeTierNote: 'Cornell University open preprint index, free.',
  },
  // Legal
  {
    id: 'courtlistener',
    name: 'CourtListener (Free Law Project)',
    category: 'legal',
    endpointTemplate: 'https://www.courtlistener.com/api/rest/v4/search/?q={query}',
    freeTierNote: 'Open federal & state case law archive, free.',
  },
  {
    id: 'eur_lex',
    name: 'EUR-Lex',
    category: 'legal',
    endpointTemplate: 'https://eur-lex.europa.eu/search.html?text={query}',
    freeTierNote: 'European Union legal database, free.',
  },
  {
    id: 'federal_register',
    name: 'Federal Register',
    category: 'legal',
    endpointTemplate: 'https://www.federalregister.gov/api/v1/documents.json?conditions[term]={query}',
    freeTierNote: 'US government regulations & notices API, free.',
  },
  // Corporate
  {
    id: 'sec_edgar',
    name: 'SEC EDGAR Full-Text',
    category: 'corporate',
    endpointTemplate: 'https://efts.sec.gov/LATEST/search-index?q={query}',
    freeTierNote: 'SEC public company filings full-text search, free.',
  },
  {
    id: 'opencorporates',
    name: 'OpenCorporates',
    category: 'corporate',
    endpointTemplate: 'https://api.opencorporates.com/v0.4/companies/search?q={query}',
    freeTierNote: 'Global corporate registry search, free public tier.',
  },
  // Infrastructure
  {
    id: 'crt_sh',
    name: 'crt.sh Certificate Transparency',
    category: 'infrastructure',
    endpointTemplate: 'https://crt.sh/?q={query}&output=json',
    freeTierNote: 'TLS certificate transparency log search, free.',
  },
  {
    id: 'rdap',
    name: 'RDAP (Registration Data Access Protocol)',
    category: 'infrastructure',
    endpointTemplate: 'https://rdap.org/domain/{query}',
    freeTierNote: 'ICANN/IETF standard WHOIS replacement, free.',
  },
  // Code & Advisories
  {
    id: 'github_code',
    name: 'GitHub Code Search',
    category: 'code_advisories',
    endpointTemplate: 'https://api.github.com/search/code?q={query}',
    freeTierNote: 'Public repository code search, free.',
  },
  {
    id: 'osv',
    name: 'OSV (Open Source Vulnerabilities)',
    category: 'code_advisories',
    endpointTemplate: 'https://api.osv.dev/v1/query',
    freeTierNote: 'Google open-source vulnerability database, free.',
  },
  {
    id: 'nvd',
    name: 'NIST NVD',
    category: 'code_advisories',
    endpointTemplate: 'https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch={query}',
    freeTierNote: 'National Vulnerability Database CVE API, free.',
  },
  // Indie, News, Stats
  {
    id: 'marginalia',
    name: 'Marginalia Search',
    category: 'indie_news_stats',
    endpointTemplate: 'https://api.marginalia.nu/public/search/{query}',
    freeTierNote: 'Independent non-commercial web search engine, free.',
  },
  {
    id: 'gdelt',
    name: 'GDELT Project',
    category: 'indie_news_stats',
    endpointTemplate:
      'https://api.gdeltproject.org/api/v2/doc/doc?query={query}&mode=artlist&format=json',
    freeTierNote: 'Global news & event stream database, free.',
  },
  {
    id: 'data_gov',
    name: 'data.gov CKAN API',
    category: 'indie_news_stats',
    endpointTemplate: 'https://catalog.data.gov/api/3/action/package_search?q={query}',
    freeTierNote: 'US open government datasets catalog, free.',
  },
  {
    id: 'world_bank',
    name: 'World Bank Open Data',
    category: 'indie_news_stats',
    endpointTemplate: 'https://api.worldbank.org/v2/indicator?format=json&q={query}',
    freeTierNote: 'Global macroeconomic & development statistics, free.',
  },
  // Optional free supplements (skipped silently if key absent)
  {
    id: 'tavily_free',
    name: 'Tavily Free Tier (Optional)',
    category: 'optional_supplement',
    endpointTemplate: 'https://api.tavily.com/search',
    requiresOptionalKey: 'TAVILY_API_KEY',
    freeTierNote: '1,000 searches/month free tier; skipped silently if key absent.',
  },
  {
    id: 'brave_free',
    name: 'Brave Search Free Tier (Optional)',
    category: 'optional_supplement',
    endpointTemplate: 'https://api.search.brave.com/res/v1/web/search?q={query}',
    requiresOptionalKey: 'BRAVE_SEARCH_API_KEY',
    freeTierNote: 'Free tier optional supplement; skipped silently if key absent.',
  },
];

export function getActiveFreeSearchBackends(
  envVars: Record<string, string | undefined> = process.env
): FreeSearchBackendSpec[] {
  return FREE_SEARCH_BACKENDS.filter((b) => {
    if (!b.requiresOptionalKey) return true;
    const keyVal = envVars[b.requiresOptionalKey];
    // Skip silently if optional supplement key is absent
    return Boolean(keyVal && keyVal.trim().length > 0);
  });
}

// ============================================================================
// 32.10 FREE MEDIA ROUTING (STT, TTS, IMAGE GEN, EMBEDDINGS)
// ============================================================================

export interface FreeMediaRoute {
  stt: {
    inBrowser: 'web-speech-api';
    localFile: 'whisper.cpp';
    paidTranscriptionUsed: false;
  };
  tts: {
    primaryLocal: 'piper';
    browserFallback: 'speechSynthesis';
    paidTtsUsed: false;
  };
  imageGen: {
    selectedBackend: 'local-sdxl-comfyui' | 'huggingface-free' | 'pollinations-free';
    endpointUrl: string;
    requiresKey: boolean;
    paidImageApiUsed: false;
  };
  embeddings: {
    engine: 'local-onnx-deterministic';
    paidEmbeddingApiUsed: false;
  };
}

export function generateFreeImageUrl(prompt: string, width = 1024, height = 1024): string {
  const encoded = encodeURIComponent(prompt.trim() || 'abstract geometric grid');
  return `https://image.pollinations.ai/prompt/${encoded}?width=${width}&height=${height}&nologo=true`;
}

export function routeFreeMedia(options?: {
  hasLocalGpuComfyUi?: boolean;
  comfyUiUrl?: string;
  hfFreeToken?: string;
  imagePrompt?: string;
}): FreeMediaRoute {
  const prompt = options?.imagePrompt || 'high contrast engineering diagram';
  let selectedBackend: 'local-sdxl-comfyui' | 'huggingface-free' | 'pollinations-free' =
    'pollinations-free';
  let endpointUrl = generateFreeImageUrl(prompt);
  let requiresKey = false;

  if (options?.hasLocalGpuComfyUi && options?.comfyUiUrl) {
    selectedBackend = 'local-sdxl-comfyui';
    endpointUrl = `${options.comfyUiUrl.replace(/\/$/, '')}/prompt`;
    requiresKey = false;
  } else if (options?.hfFreeToken && options.hfFreeToken.trim().length > 0) {
    selectedBackend = 'huggingface-free';
    endpointUrl =
      'https://api-inference.huggingface.co/models/black-forest-labs/FLUX.1-schnell';
    requiresKey = true;
  }

  return {
    stt: {
      inBrowser: 'web-speech-api',
      localFile: 'whisper.cpp',
      paidTranscriptionUsed: false,
    },
    tts: {
      primaryLocal: 'piper',
      browserFallback: 'speechSynthesis',
      paidTtsUsed: false,
    },
    imageGen: {
      selectedBackend,
      endpointUrl,
      requiresKey,
      paidImageApiUsed: false,
    },
    embeddings: {
      engine: 'local-onnx-deterministic',
      paidEmbeddingApiUsed: false,
    },
  };
}

// ============================================================================
// SINGLETON INSTANCES & DASHBOARD SNAPSHOT (32.14)
// ============================================================================

export const defaultFreeQuotaManager = new FreeQuotaManager();
export const defaultFreeCacheHierarchy = new FreeCacheHierarchy();
export const defaultRequestCoalescer = new RequestCoalescer();
export const defaultFairScheduler = new FairRequestScheduler(defaultFreeQuotaManager);

export function initializeFreeModeFromEnv(envVars: Record<string, string | undefined> = process.env): void {
  const hasOllama = Boolean(envVars.OLLAMA_BASE_URL && envVars.OLLAMA_BASE_URL.trim().length > 0);
  // Mark localHealthy false initially until initMesh() confirms the local Ollama endpoint responds
  defaultFreeQuotaManager.setLocalStatus(hasOllama, false);

  const registerCommaKeys = (provider: FreeProviderId, raw: string | undefined) => {
    if (!raw) return;
    const parts = raw
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    for (const k of parts) {
      defaultFreeQuotaManager.registerKey(provider, k);
    }
  };

  registerCommaKeys('groq', envVars.GROQ_API_KEYS || envVars.GROQ_API_KEY);
  registerCommaKeys('gemini', envVars.GEMINI_API_KEYS || envVars.GEMINI_API_KEY);
  registerCommaKeys('openrouter', envVars.OPENROUTER_API_KEYS || envVars.OPENROUTER_API_KEY);
}

export function buildFreeQuotaDashboardSnapshot() {
  const providers: ProviderQuotaSummary[] = [
    defaultFreeQuotaManager.getProviderSummary('local'),
    defaultFreeQuotaManager.getProviderSummary('groq'),
    defaultFreeQuotaManager.getProviderSummary('gemini'),
    defaultFreeQuotaManager.getProviderSummary('openrouter'),
  ];
  const degraded = defaultFreeQuotaManager.evaluateDegradedMode();
  const cacheStats = defaultFreeCacheHierarchy.getStats();
  const activeSearchBackends = getActiveFreeSearchBackends();
  const mediaRouting = routeFreeMedia();

  return {
    operatingMode: 'FREE_ONLY',
    localFirstRung0: true,
    degradedMode: degraded.mode,
    settingsStatusLine: degraded.settingsStatusLine,
    backgroundPaused: degraded.backgroundPaused,
    bestOfNAllowed: degraded.bestOfNAllowed,
    downgradeDeepToHeavy: degraded.downgradeDeepToHeavy,
    tightestTier: degraded.tightestTier,
    turnRequestCapsByGear: GEAR_TURN_REQUEST_CAPS,
    interactiveReserveFloorPercent: 20,
    rungSkipThresholdPercent: 15,
    adaptiveRaceThresholdPercent: 40,
    providers,
    skipLogs: defaultFreeQuotaManager.getSkipLogs().slice(-20),
    survivingDraftCount: defaultFreeQuotaManager.getSurvivingDrafts().length,
    cacheStats,
    coalescedHits: defaultRequestCoalescer.getCoalescedHits(),
    searchBackendsCount: activeSearchBackends.length,
    mediaRouting,
  };
}
