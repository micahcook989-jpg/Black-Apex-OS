import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { getEnv } from './env';

export interface DomainCookieSession {
  domain: string;
  encryptedCookie: string;
  iv: string;
  authTag: string;
  expiresAt?: string;
  createdAt: string;
  itemCount: number;
  status: 'valid' | 'expiring_soon' | 'expired';
}

const ENCRYPTION_KEY = crypto.scryptSync(process.env.COOKIE_SECRET || 'black-apex-os-cookie-secret-key-salt', 'salt', 32);

/**
 * Encrypt cookie string using AES-256-GCM
 */
export function encryptCookieString(cookieStr: string): { encrypted: string; iv: string; authTag: string } {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-gcm', ENCRYPTION_KEY, iv);
  let encrypted = cipher.update(cookieStr, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  return { encrypted, iv: iv.toString('hex'), authTag };
}

/**
 * Decrypt cookie string using AES-256-GCM
 */
export function decryptCookieString(encrypted: string, ivHex: string, authTagHex: string): string {
  const decipher = crypto.createDecipheriv('aes-256-gcm', ENCRYPTION_KEY, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(authTagHex, 'hex'));
  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  return decrypted;
}

class CookieSessionStore {
  private filePath: string;
  private sessions: Record<string, DomainCookieSession> = {};

  constructor() {
    const env = getEnv();
    const dataDir = path.resolve(process.cwd(), env.STORAGE_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    this.filePath = path.join(dataDir, 'cookie_sessions.json');
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(this.filePath)) {
        this.sessions = JSON.parse(fs.readFileSync(this.filePath, 'utf-8'));
      }
    } catch {
      this.sessions = {};
    }
  }

  private persist() {
    try {
      fs.writeFileSync(this.filePath, JSON.stringify(this.sessions, null, 2), 'utf-8');
    } catch (err) {
      console.error('Failed to save cookie sessions:', err);
    }
  }

  public importCookies(domain: string, rawHeaderOrJson: string, expiresAt?: string): DomainCookieSession {
    const cleanDomain = domain.toLowerCase().replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0];
    
    // Count cookie pairs
    let cookieCount = 1;
    if (rawHeaderOrJson.trim().startsWith('[') || rawHeaderOrJson.trim().startsWith('{')) {
      try {
        const parsed = JSON.parse(rawHeaderOrJson);
        cookieCount = Array.isArray(parsed) ? parsed.length : Object.keys(parsed).length;
      } catch {}
    } else {
      cookieCount = rawHeaderOrJson.split(';').filter((c) => c.includes('=')).length || 1;
    }

    const { encrypted, iv, authTag } = encryptCookieString(rawHeaderOrJson);
    const session: DomainCookieSession = {
      domain: cleanDomain,
      encryptedCookie: encrypted,
      iv,
      authTag,
      expiresAt: expiresAt || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      itemCount: cookieCount,
      status: 'valid',
    };

    this.sessions[cleanDomain] = session;
    this.persist();
    return session;
  }

  public getCookieForDomain(domain: string): string | null {
    const cleanDomain = domain.toLowerCase().replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0];
    
    // Check exact domain or parent domain match
    let match: DomainCookieSession | undefined;
    for (const d of Object.keys(this.sessions)) {
      if (cleanDomain === d || cleanDomain.endsWith('.' + d)) {
        match = this.sessions[d];
        break;
      }
    }

    if (!match) return null;

    // Check expiry
    if (match.expiresAt && new Date(match.expiresAt).getTime() < Date.now()) {
      match.status = 'expired';
      this.persist();
      return null;
    }

    try {
      return decryptCookieString(match.encryptedCookie, match.iv, match.authTag);
    } catch {
      return null;
    }
  }

  public listSessions(): (Omit<DomainCookieSession, 'encryptedCookie' | 'iv' | 'authTag'> & { hasCredentials: boolean })[] {
    return Object.values(this.sessions).map((s) => {
      const isExpired = s.expiresAt && new Date(s.expiresAt).getTime() < Date.now();
      const isExpiringSoon = s.expiresAt && new Date(s.expiresAt).getTime() < Date.now() + 3 * 24 * 60 * 60 * 1000;
      const status: 'valid' | 'expiring_soon' | 'expired' = isExpired
        ? 'expired'
        : isExpiringSoon
        ? 'expiring_soon'
        : 'valid';

      return {
        domain: s.domain,
        expiresAt: s.expiresAt,
        createdAt: s.createdAt,
        itemCount: s.itemCount,
        status,
        hasCredentials: true,
      };
    });
  }

  public deleteSession(domain: string): boolean {
    const cleanDomain = domain.toLowerCase().replace(/^(https?:\/\/)?(www\.)?/, '').split('/')[0];
    if (this.sessions[cleanDomain]) {
      delete this.sessions[cleanDomain];
      this.persist();
      return true;
    }
    return false;
  }
}

let storeInstance: CookieSessionStore | null = null;

export function getCookieStore(): CookieSessionStore {
  if (!storeInstance) {
    storeInstance = new CookieSessionStore();
  }
  return storeInstance;
}
