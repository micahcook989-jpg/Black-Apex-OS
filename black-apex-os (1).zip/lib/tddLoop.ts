/**
 * Section 24.2 — Test-Driven Loop (TDD)
 *
 * For implementation tasks in a repo or workspace:
 * 1. Write or identify a failing test.
 * 2. Run it, confirm red, show the output.
 * 3. Implement.
 * 4. Run again. On green, done. On red, iterate with the failure in context.
 * 5. Cap at 6 iterations, then hand back with the current failure and a diagnosis.
 *
 * Never claim green without a shown passing run. If the harness can't run,
 * say so in one line and proceed without it.
 */

export interface TestRunResult {
  passed: boolean;
  exitCode: number;
  stdout: string;
  stderr: string;
  durationMs: number;
  harnessUnavailable?: boolean;
}

export interface TDDIterationRecord {
  iteration: number;
  phase: 'confirm_red' | 'implement_and_verify';
  codeSnapshot: string;
  testRun: TestRunResult;
}

export interface TDDLoopSummary {
  status: 'green' | 'capped_red' | 'harness_unavailable' | 'invalid_initial_green';
  claimedGreen: boolean;
  iterationsUsed: number;
  maxIterations: number;
  initialRedConfirmed: boolean;
  shownPassingOutput: string | null;
  diagnosis: string | null;
  oneLineHarnessNote: string | null;
  history: TDDIterationRecord[];
  finalCode: string;
}

export interface TDDLoopOptions {
  testCode: string;
  initialImplementation: string;
  maxIterations?: number;
  runHarness: (testCode: string, implCode: string, iteration: number) => Promise<TestRunResult>;
  iterateImplementation: (params: {
    iteration: number;
    currentCode: string;
    testCode: string;
    lastFailureOutput: string;
  }) => Promise<string>;
}

export const MAX_TDD_ITERATIONS = 6;

/**
 * Validates whether a completion response is allowed to claim green.
 * Never claim green without a shown passing run (exitCode === 0, passed === true, non-empty output).
 */
export function canClaimGreen(run: TestRunResult | null | undefined): boolean {
  if (!run) return false;
  if (run.harnessUnavailable) return false;
  if (!run.passed || run.exitCode !== 0) return false;
  const combinedOutput = `${run.stdout || ''}\n${run.stderr || ''}`.trim();
  return combinedOutput.length > 0;
}

/**
 * Executes the strict Section 24.2 Test-Driven Loop:
 * 1. Runs initial failing test to confirm RED.
 * 2. Iterates up to 6 times (implement -> run test).
 * 3. On green with shown passing output -> returns green.
 * 4. If capped at 6 iterations -> returns current failure + diagnosis without claiming green.
 * 5. If harness unavailable -> returns one-line note and proceeds without claiming green.
 */
export async function executeTDDLoop(options: TDDLoopOptions): Promise<TDDLoopSummary> {
  const maxIterations = Math.min(options.maxIterations ?? MAX_TDD_ITERATIONS, MAX_TDD_ITERATIONS);
  const history: TDDIterationRecord[] = [];
  let currentCode = options.initialImplementation;

  // Step 1 & 2: Run failing test first and confirm RED
  const initialRun = await options.runHarness(options.testCode, currentCode, 0);

  if (initialRun.harnessUnavailable) {
    return {
      status: 'harness_unavailable',
      claimedGreen: false,
      iterationsUsed: 0,
      maxIterations,
      initialRedConfirmed: false,
      shownPassingOutput: null,
      diagnosis: null,
      oneLineHarnessNote: 'Test harness cannot run in this environment; proceeding with implementation without automated test verification.',
      history,
      finalCode: currentCode,
    };
  }

  history.push({
    iteration: 0,
    phase: 'confirm_red',
    codeSnapshot: currentCode,
    testRun: initialRun,
  });

  const initialRedConfirmed = !initialRun.passed || initialRun.exitCode !== 0;

  let lastFailureOutput = `${initialRun.stdout}\n${initialRun.stderr}`.trim();

  // Step 3 & 4: Iterate implementation up to 6 iterations
  for (let iteration = 1; iteration <= maxIterations; iteration++) {
    currentCode = await options.iterateImplementation({
      iteration,
      currentCode,
      testCode: options.testCode,
      lastFailureOutput,
    });

    const runResult = await options.runHarness(options.testCode, currentCode, iteration);
    history.push({
      iteration,
      phase: 'implement_and_verify',
      codeSnapshot: currentCode,
      testRun: runResult,
    });

    if (canClaimGreen(runResult)) {
      return {
        status: 'green',
        claimedGreen: true,
        iterationsUsed: iteration,
        maxIterations,
        initialRedConfirmed,
        shownPassingOutput: `${runResult.stdout}\n${runResult.stderr}`.trim(),
        diagnosis: null,
        oneLineHarnessNote: null,
        history,
        finalCode: currentCode,
      };
    }

    lastFailureOutput = `${runResult.stdout}\n${runResult.stderr}`.trim();
  }

  // Step 5: Cap at 6 iterations, hand back with current failure and diagnosis
  return {
    status: 'capped_red',
    claimedGreen: false,
    iterationsUsed: maxIterations,
    maxIterations,
    initialRedConfirmed,
    shownPassingOutput: null,
    diagnosis: `Capped at ${maxIterations} TDD iterations. Remaining failure: ${lastFailureOutput.slice(0, 300)}`,
    oneLineHarnessNote: null,
    history,
    finalCode: currentCode,
  };
}
