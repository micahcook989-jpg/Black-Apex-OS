import fs from 'fs';
import path from 'path';
import { getEnv } from './env';

export interface MessageReceipt {
  rung: number;
  providerCodename: string;
  latencyMs: number;
  hedged: boolean;
  modelTier: string;
  draftSnippet: string;
  timestamp: string;
  cached?: boolean;
}

export interface Message {
  id: string;
  conversationId: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  rawContent?: string; // before stripping
  winningRung?: number;
  receipts?: MessageReceipt[];
  toolCalls?: any[];
  artifacts?: string[];
  suggestedChips?: string[];
  hideGlyphs?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Conversation {
  id: string;
  title: string;
  folderId?: string | null;
  pinned?: boolean;
  branchOf?: { conversationId: string; fromMessageId: string } | null;
  createdAt: string;
  updatedAt: string;
}

export interface Artifact {
  id: string;
  conversationId: string;
  title: string;
  type: 'html' | 'react' | 'svg' | 'markdown' | 'mermaid' | 'table' | 'userscript' | 'filetree' | 'code';
  content: string;
  version: number;
  history?: { version: number; content: string; timestamp: string }[];
  createdAt: string;
  updatedAt: string;
}

export interface MemoryFact {
  id: string;
  fact: string;
  category: 'preference' | 'profession' | 'constraint' | 'project';
  sourceConversationId?: string;
  pinned: boolean;
  createdAt: string;
}

export interface CustomInstruction {
  id: string;
  scope: 'global' | 'folder' | 'conversation';
  targetId?: string;
  instruction: string;
  pinned?: boolean;
}

interface DBData {
  conversations: Conversation[];
  messages: Message[];
  artifacts: Artifact[];
  memoryFacts: MemoryFact[];
  instructions: CustomInstruction[];
  hedgeStats: {
    totalRequests: number;
    totalHedges: number;
    rungCounts: Record<number, number>;
  };
}

class Database {
  private dbPath: string;
  private data: DBData;

  constructor() {
    const env = getEnv();
    const dataDir = path.resolve(process.cwd(), env.STORAGE_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    this.dbPath = path.join(dataDir, 'apex-db.json');
    this.data = this.load();
  }

  private load(): DBData {
    if (fs.existsSync(this.dbPath)) {
      try {
        const raw = fs.readFileSync(this.dbPath, 'utf-8');
        return JSON.parse(raw);
      } catch {
        // fallback
      }
    }
    return {
      conversations: [],
      messages: [],
      artifacts: [],
      memoryFacts: [],
      instructions: [
        {
          id: 'default-global',
          scope: 'global',
          instruction: 'Execute with technical precision. Answer directly first.',
          pinned: true,
        },
      ],
      hedgeStats: {
        totalRequests: 0,
        totalHedges: 0,
        rungCounts: { 0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0 },
      },
    };
  }

  private persist() {
    try {
      fs.writeFileSync(this.dbPath, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Database write error', err);
    }
  }

  // Conversations
  getConversations(): Conversation[] {
    return [...this.data.conversations].sort(
      (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  }

  getConversation(id: string): Conversation | undefined {
    return this.data.conversations.find((c) => c.id === id);
  }

  saveConversation(conv: Conversation): Conversation {
    const idx = this.data.conversations.findIndex((c) => c.id === conv.id);
    if (idx >= 0) {
      this.data.conversations[idx] = { ...conv, updatedAt: new Date().toISOString() };
    } else {
      this.data.conversations.unshift(conv);
    }
    this.persist();
    return conv;
  }

  deleteConversation(id: string) {
    this.data.conversations = this.data.conversations.filter((c) => c.id !== id);
    this.data.messages = this.data.messages.filter((m) => m.conversationId !== id);
    this.data.artifacts = this.data.artifacts.filter((a) => a.conversationId !== id);
    this.persist();
  }

  // Messages
  getMessages(conversationId: string): Message[] {
    return this.data.messages
      .filter((m) => m.conversationId === conversationId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  getMessage(id: string): Message | undefined {
    return this.data.messages.find((m) => m.id === id);
  }

  saveMessage(msg: Message): Message {
    const idx = this.data.messages.findIndex((m) => m.id === msg.id);
    if (idx >= 0) {
      this.data.messages[idx] = { ...msg, updatedAt: new Date().toISOString() };
    } else {
      this.data.messages.push(msg);
    }
    // Update conversation updatedAt
    const conv = this.data.conversations.find((c) => c.id === msg.conversationId);
    if (conv) {
      conv.updatedAt = new Date().toISOString();
    }
    this.persist();
    return msg;
  }

  deleteMessage(id: string) {
    this.data.messages = this.data.messages.filter((m) => m.id !== id);
    this.persist();
  }

  // Artifacts
  getArtifacts(conversationId: string): Artifact[] {
    return this.data.artifacts.filter((a) => a.conversationId === conversationId);
  }

  getArtifact(id: string): Artifact | undefined {
    return this.data.artifacts.find((a) => a.id === id);
  }

  saveArtifact(art: Artifact): Artifact {
    const idx = this.data.artifacts.findIndex((a) => a.id === art.id);
    if (idx >= 0) {
      const prev = this.data.artifacts[idx];
      const history = prev.history || [];
      history.push({
        version: prev.version,
        content: prev.content,
        timestamp: prev.updatedAt,
      });
      this.data.artifacts[idx] = {
        ...art,
        version: prev.version + 1,
        history,
        updatedAt: new Date().toISOString(),
      };
    } else {
      this.data.artifacts.push(art);
    }
    this.persist();
    return art;
  }

  // Memory
  getMemoryFacts(): MemoryFact[] {
    return this.data.memoryFacts;
  }

  saveMemoryFact(fact: MemoryFact): MemoryFact {
    const idx = this.data.memoryFacts.findIndex((f) => f.id === fact.id);
    if (idx >= 0) {
      this.data.memoryFacts[idx] = fact;
    } else {
      this.data.memoryFacts.unshift(fact);
    }
    this.persist();
    return fact;
  }

  deleteMemoryFact(id: string) {
    this.data.memoryFacts = this.data.memoryFacts.filter((f) => f.id !== id);
    this.persist();
  }

  // Hedge Stats
  recordHedgeEvent(rung: number, hedged: boolean) {
    this.data.hedgeStats.totalRequests += 1;
    if (hedged || rung > 0) {
      this.data.hedgeStats.totalHedges += 1;
    }
    this.data.hedgeStats.rungCounts[rung] = (this.data.hedgeStats.rungCounts[rung] || 0) + 1;
    this.persist();
  }

  getHedgeStats() {
    return this.data.hedgeStats;
  }
}

let dbInstance: Database | null = null;
export function getDb(): Database {
  if (!dbInstance) {
    dbInstance = new Database();
  }
  return dbInstance;
}
