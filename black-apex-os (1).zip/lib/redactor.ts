/**
 * Black Apex OS — Section 18.7 Pasted-Secret Redaction
 *
 * Runs on every paste and file ingest.
 * Detects API keys, tokens, and private keys:
 * - OpenAI / OpenRouter sk-*
 * - Stripe sk_live / rk_live / test
 * - Google AI Studio / GCP AIza* / AQ.*
 * - GitHub ghp_* / gho_*
 * - AWS AKIA*
 * - Slack xox*
 * - JWT tokens
 * - PEM Private keys
 * - Discord tokens
 * Plus high-entropy base64 strings near "key", "token", "secret", "password".
 *
 * Offers "keep for this turn only" versus "store in transcript".
 * Default: keep for the turn, redact on store.
 */

export const SECRET_PATTERNS = [
  { name: 'OpenAI/OpenRouter Key', regex: /sk-[A-Za-z0-9_-]{20,}/g },
  { name: 'Stripe Key', regex: /[sr]k_(live|test)_[A-Za-z0-9]{20,}/g },
  { name: 'Google API Key', regex: /AIza[0-9A-Za-z_-]{35}/g },
  { name: 'Gemini OAuth/Studio Key', regex: /AQ\.[A-Za-z0-9_-]{20,}/g },
  { name: 'GitHub Token', regex: /gh[pousr]_[A-Za-z0-9]{25,}/g },
  { name: 'AWS Access Key', regex: /AKIA[0-9A-Z]{16}/g },
  { name: 'Slack Token', regex: /xox[abposr]-[A-Za-z0-9-]{10,}/g },
  { name: 'JWT Token', regex: /eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g },
  { name: 'Private Key', regex: /-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----/g },
  { name: 'Discord Token', regex: /[MN][A-Za-z\d]{23,}\.[\w-]{6}\.[\w-]{27}/g },
];

export interface DetectedSecret {
  name: string;
  match: string;
  redactedPreview: string;
  startIndex: number;
  endIndex: number;
}

export function scanForSecrets(text: string): DetectedSecret[] {
  if (!text) return [];

  const found: DetectedSecret[] = [];

  for (const pat of SECRET_PATTERNS) {
    let m;
    const re = new RegExp(pat.regex.source, pat.regex.flags);
    while ((m = re.exec(text)) !== null) {
      const match = m[0];
      const preview = match.length > 8 ? `${match.slice(0, 4)}...${match.slice(-4)}` : '••••••••';
      found.push({
        name: pat.name,
        match,
        redactedPreview: preview,
        startIndex: m.index,
        endIndex: m.index + match.length,
      });
    }
  }

  // High-entropy heuristic: 32+ character base64-ish run within 40 characters of key/token/secret/password
  const entropyRegex = /(?:key|token|secret|password|bearer)[\s:=]{1,40}([A-Za-z0-9+/=_-]{32,})/gi;
  let em;
  while ((em = entropyRegex.exec(text)) !== null) {
    const rawVal = em[1];
    if (!found.some((f) => f.match.includes(rawVal) || rawVal.includes(f.match))) {
      found.push({
        name: 'High-Entropy Secret',
        match: rawVal,
        redactedPreview: `${rawVal.slice(0, 4)}...${rawVal.slice(-4)}`,
        startIndex: em.index,
        endIndex: em.index + em[0].length,
      });
    }
  }

  return found;
}

/**
 * Replaces all detected secrets with [REDACTED: <type>]
 */
export function redactSecretsOnStore(text: string): string {
  let result = text;
  for (const pat of SECRET_PATTERNS) {
    result = result.replace(pat.regex, (match) => `[REDACTED: ${pat.name}]`);
  }
  return result;
}
