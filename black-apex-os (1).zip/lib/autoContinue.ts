/**
 * Black Apex OS — Section 17.7 Auto-Continue
 *
 * Detects an answer that ends in a question or a continuation offer:
 * - "want me to go on"
 * - "shall I continue"
 * - "let me know if you'd like the rest"
 * - "would you like me to"
 *
 * Strips the question, triggers a continue call, and stitches at the seam
 * with zero visible break. Capped at 4 consecutive continuations per turn.
 */

const CONTINUATION_PATTERNS = [
  /(\n\s*)?(?:do\s+you\s+want|would\s+you\s+like|shall\s+I|should\s+I)\s+(?:me\s+to\s+)?(?:continue|go\s+on|proceed|finish|write\s+the\s+rest|implement\s+the\s+remaining)[\s\S]*?\??\s*$/i,
  /(\n\s*)?(?:let\s+me\s+know\s+if\s+you(?:'d|\s+would)?\s+like\s+(?:me\s+to\s+)?(?:continue|the\s+rest|more|part\s+two))[\s\S]*?\??\s*$/i,
  /(\n\s*)?want\s+me\s+to\s+go\s+on\??\s*$/i,
  /(\n\s*)?shall\s+I\s+continue\??\s*$/i,
];

export interface AutoContinueResult {
  hasOffer: boolean;
  hasContinuationOffer: boolean;
  cleanedText: string;
  cleanText: string;
}

export function detectAndStripContinuationOffer(text: string): AutoContinueResult {
  if (!text) {
    return {
      hasOffer: false,
      hasContinuationOffer: false,
      cleanedText: text,
      cleanText: text,
    };
  }

  let cleaned = text.trimEnd();

  for (const pattern of CONTINUATION_PATTERNS) {
    if (pattern.test(cleaned)) {
      cleaned = cleaned.replace(pattern, '').trimEnd();
      return {
        hasOffer: true,
        hasContinuationOffer: true,
        cleanedText: cleaned,
        cleanText: cleaned,
      };
    }
  }

  return {
    hasOffer: false,
    hasContinuationOffer: false,
    cleanedText: text,
    cleanText: text,
  };
}
