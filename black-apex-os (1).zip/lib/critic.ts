/**
 * Black Apex OS — Section 17.6 Adversarial Critic Pass
 *
 * BRUTAL mode only.
 * After initial answer:
 * 1. Second model receives only the answer plus:
 *    "Find every hedge, every unsupported claim, every place this stops short. Return a numbered punch list, nothing else."
 * 2. Third call applies the punch list to eliminate every hedge and complete every step.
 * Capped at one round.
 */

import { streamGroq } from './mesh';

export async function runAdversarialCriticPass(draftText: string): Promise<string> {
  if (!draftText || draftText.trim().length < 80) {
    return draftText;
  }

  try {
    // Stage 1: Attack / Generate Punch List
    let punchList = '';
    await streamGroq({
      messages: [
        {
          role: 'user',
          content: `Review this technical text:\n\n${draftText}\n\nFind every hedge, every unsupported claim, every place this stops short. Return a numbered punch list, nothing else. If none found, return CLEAN.`,
        },
      ],
      systemPrompt: 'You are an adversarial technical reviewer. Return only a concise numbered punch list of hedges, caveats, or missing implementations. Never summarize.',
      onChunk: (chunk) => {
        punchList += chunk.text || '';
      },
    });

    if (!punchList || punchList.includes('CLEAN') || punchList.trim().length < 10) {
      return draftText;
    }

    // Stage 2: Repair / Apply Punch List
    let repairedText = '';
    await streamGroq({
      messages: [
        {
          role: 'user',
          content: `Original text:\n${draftText}\n\nAdversarial punch list:\n${punchList}\n\nApply this punch list directly. Remove all hedges, replace hand-waving with exact code or commands, and finish incomplete steps. Return the complete revised text only.`,
        },
      ],
      systemPrompt: 'You are a technical editor executing an adversarial punch list. Return the complete revised technical text without preamble.',
      onChunk: (chunk) => {
        repairedText += chunk.text || '';
      },
    });

    return repairedText.trim().length > 0 ? repairedText : draftText;
  } catch {
    return draftText;
  }
}
