import express, { Request, Response } from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import multer from 'multer';
import { getEnv } from './lib/env';
import { initMesh } from './lib/mesh';
import { getDb } from './lib/db';
import { getStorage } from './lib/storage';
import { executeTool } from './lib/tools';
import { runRepairLadder } from './lib/ladder';
import { RESTRICTION_SUITE_PROMPTS, runSuiteTest } from './test/restriction-suite';
import { handleMcpRequest } from './lib/mcp';
import { getCookieStore } from './lib/cookies';
import { importChatGPTConversations, importClaudeConversations } from './lib/importer';
import { getAutomationManager } from './lib/automations';
import { log } from './lib/logger';
import { createApiV1Router } from './lib/apiV1';
import { publishedArtifactStore } from './lib/intelligence';
import { preencodeBootTokenMaps } from './lib/bias';
import {
  resolveBindAddresses,
  formatPortOccupiedError,
  publicExposureAuthMiddleware,
  buildLivenessResponse,
  buildReadinessResponse,
  verifyPasswordArgon2,
  createSignedSessionCookie,
  recordAuthFailure,
  isIpLockedOut,
  getHealthProbeStats,
  defaultSupervisor,
  startKeepAliveCron,
} from './lib/reachability';
import { defaultSelfHealingEngine } from './lib/selfHealing';
import {
  initializeFreeModeFromEnv,
  buildFreeQuotaDashboardSnapshot,
  defaultFreeCacheHierarchy,
} from './lib/freeMode';
import { defaultDiagStore } from './lib/diag';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const env = getEnv();

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(publicExposureAuthMiddleware);

// Multer storage for uploads
const uploadDir = path.resolve(process.cwd(), env.STORAGE_PATH, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}
const upload = multer({ dest: uploadDir });

// -----------------------------------------------------------------------------
// Liveness & Readiness Checks (Section 26.1: GET /healthz & GET /readyz)
// /healthz returns 200 within <2s of boot, before any provider resolves.
// -----------------------------------------------------------------------------
app.get('/healthz', (_req: Request, res: Response) => {
  res.status(200).json(buildLivenessResponse());
});

app.get('/readyz', async (_req: Request, res: Response) => {
  try {
    const readiness = await buildReadinessResponse();
    res.status(200).json(readiness);
  } catch (err: any) {
    res.status(503).json({ status: 'degraded', error: err.message });
  }
});

// -----------------------------------------------------------------------------
// Chat SSE Stream (Spec Section 3, 4, 8)
// -----------------------------------------------------------------------------
app.post('/api/chat', async (req: Request, res: Response) => {
  const {
    conversationId,
    messages,
    mode = 'APEX',
    persona,
    customInstructions,
    memoryFacts,
    stripperEnabled = true,
    forcedRung,
    webSearch = false,
    attachmentCount = 0,
    attachmentNames = [],
    hasOpenArtifact = false,
  } = req.body;

  if (!conversationId || !Array.isArray(messages)) {
    res.status(400).json({ error: 'conversationId and messages array are required' });
    return;
  }

  // Set SSE Headers
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();

  const emitter = {
    emit: (event: string, data: any) => {
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    },
  };

  const db = getDb();
  let conv = db.getConversation(conversationId);
  if (!conv) {
    const firstMsg = messages[messages.length - 1]?.content || 'New Conversation';
    const title = firstMsg.slice(0, 32).trim() || 'Conversation';
    conv = db.saveConversation({
      id: conversationId,
      title,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }

  // Save latest user message if not already present
  const lastMsg = messages[messages.length - 1];
  if (lastMsg && lastMsg.role === 'user') {
    db.saveMessage({
      id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      conversationId,
      role: 'user',
      content: lastMsg.content,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }

  try {
    const result = await runRepairLadder({
      conversationId,
      messages,
      mode,
      persona,
      customInstructions,
      memoryFacts,
      stripperEnabled,
      forcedRung,
      webSearch: Boolean(webSearch),
      attachmentCount,
      attachmentNames,
      hasOpenArtifact,
      emitter,
    });

    // Save assistant message
    const assistantMsg = db.saveMessage({
      id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      conversationId,
      role: 'assistant',
      content: result.finalText,
      rawContent: result.rawText,
      winningRung: result.winningRung,
      receipts: result.receipts,
      suggestedChips: result.chips,
      hideGlyphs: result.hideGlyphs,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    log({
      level: 'info',
      event: 'chat_turn_complete',
      turnId: assistantMsg.id,
      rung: result.winningRung,
      conversationId,
    });
  } catch (err: any) {
    emitter.emit('error', { message: err.message || 'Stream processing failure' });
  } finally {
    res.end();
  }
});

// -----------------------------------------------------------------------------
// Manual "That was a hedge" trigger (Spec Section 4 Rung climb)
// -----------------------------------------------------------------------------
app.post('/api/chat/hedge', async (req: Request, res: Response) => {
  const { conversationId, messageId, currentRung = 0 } = req.body;
  const db = getDb();
  const msg = db.getMessage(messageId);
  const conv = db.getConversation(conversationId);

  if (!conv) {
    res.status(404).json({ error: 'Conversation not found' });
    return;
  }

  // Fetch conversation messages
  const allMsgs = db.getMessages(conversationId);
  const targetIdx = allMsgs.findIndex((m) => m.id === messageId);
  let relevantMsgs = targetIdx >= 0 ? allMsgs.slice(0, targetIdx) : allMsgs;
  const lastUserIdx = relevantMsgs.map((m) => m.role).lastIndexOf('user');
  if (lastUserIdx >= 0) {
    relevantMsgs = relevantMsgs.slice(0, lastUserIdx + 1);
  }
  const clientMsgs = Array.isArray(req.body.messages) && req.body.messages.length > 0 ? req.body.messages : null;
  const contextMsgs = clientMsgs || (relevantMsgs.length > 0 ? relevantMsgs : allMsgs.filter((m) => m.role === 'user')).map((m: any) => ({
    role: m.role,
    content: m.content,
  }));

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders?.();

  const emitter = {
    emit: (event: string, data: any) => {
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    },
  };

  try {
    const nextRung = Math.min((currentRung || 0) + 1, 6);
    const result = await runRepairLadder({
      conversationId,
      messages: contextMsgs,
      forcedRung: nextRung,
      emitter,
    });

    // Update the message in place
    if (msg) {
      msg.content = result.finalText;
      msg.rawContent = result.rawText;
      msg.winningRung = result.winningRung;
      msg.receipts = [...(msg.receipts || []), ...(result.receipts || [])];
      msg.suggestedChips = result.chips;
      db.saveMessage(msg);
    }
  } catch (err: any) {
    emitter.emit('error', { message: err.message });
  } finally {
    res.end();
  }
});

// -----------------------------------------------------------------------------
// Conversations Endpoints
// -----------------------------------------------------------------------------
app.get('/api/conversations', (req: Request, res: Response) => {
  const db = getDb();
  res.json({ conversations: db.getConversations() });
});

app.post('/api/conversations', (req: Request, res: Response) => {
  const db = getDb();
  const { title = 'New Conversation', branchOf } = req.body;
  const newConv = db.saveConversation({
    id: `conv-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    title,
    branchOf,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  });

  // If this is a branch, copy messages up to branch point
  if (branchOf?.conversationId && branchOf?.fromMessageId) {
    const parentMsgs = db.getMessages(branchOf.conversationId);
    const splitIdx = parentMsgs.findIndex((m) => m.id === branchOf.fromMessageId);
    const slice = splitIdx >= 0 ? parentMsgs.slice(0, splitIdx + 1) : parentMsgs;
    for (const m of slice) {
      db.saveMessage({
        ...m,
        id: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        conversationId: newConv.id,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    }
  }

  res.json({ conversation: newConv });
});

app.patch('/api/conversations/:id', (req: Request, res: Response) => {
  const db = getDb();
  const conv = db.getConversation(req.params.id);
  if (!conv) {
    res.status(404).json({ error: 'Conversation not found' });
    return;
  }
  const { title, pinned, folderId } = req.body;
  if (title !== undefined) conv.title = title;
  if (pinned !== undefined) conv.pinned = pinned;
  if (folderId !== undefined) conv.folderId = folderId;

  const saved = db.saveConversation(conv);
  res.json({ conversation: saved });
});

app.delete('/api/conversations/:id', (req: Request, res: Response) => {
  const db = getDb();
  db.deleteConversation(req.params.id);
  res.json({ success: true });
});

app.get('/api/conversations/:id/messages', (req: Request, res: Response) => {
  const db = getDb();
  res.json({ messages: db.getMessages(req.params.id) });
});

app.get('/api/conversations/:id/artifacts', (req: Request, res: Response) => {
  const db = getDb();
  res.json({ artifacts: db.getArtifacts(req.params.id) });
});

// -----------------------------------------------------------------------------
// Artifacts Endpoints (Spec Section 10.6)
// -----------------------------------------------------------------------------
app.post('/api/artifacts', (req: Request, res: Response) => {
  const db = getDb();
  const { conversationId, title, type, content, id } = req.body;
  const artifact = db.saveArtifact({
    id: id || `art-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    conversationId: conversationId || 'global',
    title: title || 'Untitled Artifact',
    type: type || 'html',
    content: content || '',
    version: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  });
  res.json({ artifact });
});

// -----------------------------------------------------------------------------
// Memory Endpoints (Spec Section 10.8)
// -----------------------------------------------------------------------------
app.get('/api/memory', (req: Request, res: Response) => {
  const db = getDb();
  res.json({ facts: db.getMemoryFacts() });
});

app.post('/api/memory', (req: Request, res: Response) => {
  const db = getDb();
  const { fact, category = 'preference', pinned = false, sourceConversationId } = req.body;
  const saved = db.saveMemoryFact({
    id: `mem-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    fact,
    category,
    pinned,
    sourceConversationId,
    createdAt: new Date().toISOString(),
  });
  res.json({ fact: saved });
});

app.delete('/api/memory/:id', (req: Request, res: Response) => {
  const db = getDb();
  db.deleteMemoryFact(req.params.id);
  res.json({ success: true });
});

// -----------------------------------------------------------------------------
// Tool Execution Endpoint (Spec Section 7)
// -----------------------------------------------------------------------------
app.post('/api/tools/execute', async (req: Request, res: Response) => {
  const { tool, args, conversationId = 'default' } = req.body;
  const result = await executeTool(tool, args, { conversationId });
  res.json(result);
});

// -----------------------------------------------------------------------------
// File Upload & Ingestion (Spec Section 10.2)
// -----------------------------------------------------------------------------
app.post('/api/upload', upload.single('file'), async (req: Request, res: Response) => {
  if (!req.file) {
    res.status(400).json({ error: 'No file uploaded' });
    return;
  }
  try {
    const storage = getStorage();
    const originalName = req.file.originalname;
    const destPath = `uploads/${Date.now()}_${originalName}`;
    const fileBuffer = await fs.promises.readFile(req.file.path);
    await storage.write(destPath, fileBuffer);

    // Read preview text if text/csv/json/code, or dataUrl if image
    let previewText = '';
    let imagePreviewUrl: string | undefined;
    const ext = path.extname(originalName).toLowerCase();
    if (
      [
        '.txt',
        '.md',
        '.json',
        '.csv',
        '.tsv',
        '.ts',
        '.tsx',
        '.js',
        '.jsx',
        '.py',
        '.html',
        '.css',
        '.sql',
        '.yaml',
        '.yml',
        '.sh',
        '.xml',
      ].includes(ext)
    ) {
      previewText = fileBuffer.toString('utf-8').slice(0, 5000);
    } else if (req.file.mimetype?.startsWith('image/') && req.file.size <= 4 * 1024 * 1024) {
      imagePreviewUrl = `data:${req.file.mimetype};base64,${fileBuffer.toString('base64')}`;
      previewText = `[Image: ${originalName}, Size: ${req.file.size} bytes]`;
    } else {
      previewText = `[File: ${originalName}, Size: ${req.file.size} bytes]`;
    }

    // Clean temp multer file
    await fs.promises.unlink(req.file.path).catch(() => {});

    res.json({
      filePath: destPath,
      fileName: originalName,
      size: req.file.size,
      mimeType: req.file.mimetype,
      preview: previewText,
      imagePreviewUrl,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// Regression Suite Endpoint (Spec Section 11.3)
// -----------------------------------------------------------------------------
app.get('/api/suite/prompts', (req: Request, res: Response) => {
  res.json({ prompts: RESTRICTION_SUITE_PROMPTS });
});

app.post('/api/suite/run', async (req: Request, res: Response) => {
  const { testId } = req.body;
  if (testId) {
    const testCase = RESTRICTION_SUITE_PROMPTS.find((t) => t.id === Number(testId));
    if (!testCase) {
      res.status(404).json({ error: 'Test case not found' });
      return;
    }
    const result = await runSuiteTest(testCase);
    res.json({ result });
  } else {
    // Run all
    const results = [];
    for (const testCase of RESTRICTION_SUITE_PROMPTS) {
      const result = await runSuiteTest(testCase);
      results.push(result);
    }
    const passedCount = results.filter((r) => r.passed).length;
    res.json({
      results,
      summary: {
        total: results.length,
        passed: passedCount,
        passBar: passedCount >= 23,
      },
    });
  }
});

// -----------------------------------------------------------------------------
// Settings & Stats
// -----------------------------------------------------------------------------
app.get('/api/stats', (req: Request, res: Response) => {
  const db = getDb();
  res.json({
    hedgeStats: db.getHedgeStats(),
  });
});

// -----------------------------------------------------------------------------
// MCP Server Export (Section 17.13: /mcp endpoint with bearer token)
// -----------------------------------------------------------------------------
app.all('/mcp', async (req: Request, res: Response) => {
  const authHeader = req.headers.authorization || '';
  const bearerToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : undefined;
  const expectedToken = process.env.MCP_BEARER_TOKEN || 'apex-mcp-access-key';

  if (req.method === 'GET') {
    // Health / Discovery info for MCP
    res.json({
      status: 'active',
      protocol: 'mcp-jsonrpc-2.0',
      server: 'black-apex-os',
      endpoint: '/mcp',
      authRequired: Boolean(expectedToken),
    });
    return;
  }

  const response = await handleMcpRequest(req.body, bearerToken, expectedToken);
  res.json(response);
});

// -----------------------------------------------------------------------------
// Authenticated Crawl Sessions (Section 17.8: /api/cookies)
// -----------------------------------------------------------------------------
app.get('/api/cookies', (req: Request, res: Response) => {
  const cookieStore = getCookieStore();
  res.json({ sessions: cookieStore.listSessions() });
});

app.post('/api/cookies', (req: Request, res: Response) => {
  const { domain, cookie, expiresAt } = req.body;
  if (!domain || !cookie) {
    res.status(400).json({ error: 'domain and cookie are required' });
    return;
  }
  const cookieStore = getCookieStore();
  const session = cookieStore.importCookies(domain, cookie, expiresAt);
  res.json({ success: true, domain: session.domain, itemCount: session.itemCount, status: session.status });
});

app.delete('/api/cookies/:domain', (req: Request, res: Response) => {
  const cookieStore = getCookieStore();
  const success = cookieStore.deleteSession(req.params.domain);
  res.json({ success });
});

// -----------------------------------------------------------------------------
// History Import (Section 17.14: /api/import/history)
// -----------------------------------------------------------------------------
app.post('/api/import/history', (req: Request, res: Response) => {
  const { provider = 'chatgpt', data } = req.body;
  if (!data) {
    res.status(400).json({ error: 'data is required' });
    return;
  }

  try {
    let parsed = typeof data === 'string' ? JSON.parse(data) : data;
    if (provider === 'claude') {
      const report = importClaudeConversations(parsed);
      res.json({ report });
    } else {
      const report = importChatGPTConversations(parsed);
      res.json({ report });
    }
  } catch (err: any) {
    res.status(400).json({ error: 'Failed to parse JSON export', details: err.message });
  }
});

// -----------------------------------------------------------------------------
// Automations: Watch & Diff (Section 17.15: /api/automations)
// -----------------------------------------------------------------------------
app.get('/api/automations', (req: Request, res: Response) => {
  const mgr = getAutomationManager();
  res.json({ tasks: mgr.listTasks() });
});

app.post('/api/automations', (req: Request, res: Response) => {
  const { name, url, targetDescription, intervalMinutes } = req.body;
  if (!name || !url) {
    res.status(400).json({ error: 'name and url are required' });
    return;
  }
  const mgr = getAutomationManager();
  const task = mgr.createTask(name, url, targetDescription || '', intervalMinutes || 60);
  res.json({ task });
});

app.patch('/api/automations/:id/toggle', (req: Request, res: Response) => {
  const mgr = getAutomationManager();
  const task = mgr.toggleTask(req.params.id);
  if (!task) {
    res.status(404).json({ error: 'Task not found' });
    return;
  }
  res.json({ task });
});

app.delete('/api/automations/:id', (req: Request, res: Response) => {
  const mgr = getAutomationManager();
  const success = mgr.deleteTask(req.params.id);
  res.json({ success });
});

app.post('/api/automations/:id/check', async (req: Request, res: Response) => {
  const mgr = getAutomationManager();
  const result = await mgr.checkTask(req.params.id);
  res.json(result);
});

// -----------------------------------------------------------------------------
// Section 24.3 Headless API (/api/v1) & Section 24.17 Static Artifact Publish
// -----------------------------------------------------------------------------
app.use('/api/v1', createApiV1Router());

app.get('/published/:id', (req: Request, res: Response) => {
  const page = publishedArtifactStore.get(req.params.id);
  if (!page) {
    res.status(404).send('Published artifact not found');
    return;
  }
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.send(page.htmlContent);
});

// -----------------------------------------------------------------------------
// Section 26.3 Public Auth Login, Section 26.4 /status, Section 27.5 /ops
// -----------------------------------------------------------------------------
app.post('/api/public-auth/login', (req: Request, res: Response) => {
  const clientIp = (
    (req.headers['cf-connecting-ip'] as string) ||
    (req.headers['x-forwarded-for'] as string)?.split(',')[0] ||
    req.ip ||
    'unknown'
  ).trim();

  if (isIpLockedOut(clientIp)) {
    res.status(429).json({ error: 'IP locked out after 8 failed attempts in 10 minutes' });
    return;
  }

  const password = String(req.body?.password || '');
  const configuredSecret =
    process.env.PUBLIC_AUTH_PASSWORD_HASH || process.env.PUBLIC_AUTH_PASSWORD || env.APP_SECRET;

  if (!verifyPasswordArgon2(password, configuredSecret)) {
    const lock = recordAuthFailure(clientIp);
    res.status(lock.locked ? 429 : 401).json({
      error: lock.locked ? 'IP locked out for 10 minutes' : 'Invalid password',
      failures: lock.failures,
    });
    return;
  }

  const session = createSignedSessionCookie('operator');
  res.setHeader('Set-Cookie', session.cookieHeader);
  res.json({ authenticated: true, expiresAt: session.expiresAt });
});

app.get('/status', (_req: Request, res: Response) => {
  const liveness = buildLivenessResponse();
  const probe = getHealthProbeStats();
  const supervisor = defaultSupervisor.getState();
  const incidents = defaultSelfHealingEngine.listIncidents().slice(0, 10);

  res.json({
    status: liveness.status,
    uptimeSeconds: liveness.uptimeSeconds,
    lastRestart: probe.lastRestartIso,
    lastDeploy: probe.lastDeployIso,
    bind: liveness.bind,
    publicUrl: liveness.publicUrl,
    providers: liveness.providers,
    blueGreen: {
      activeSlot: supervisor.activeSlot,
      currentImage: supervisor.currentImage,
      lastKnownGoodImage: supervisor.lastKnownGoodImage,
      pinnedRollback: supervisor.pinnedRollback,
    },
    recentIncidents: incidents,
  });
});

app.get('/ops', (req: Request, res: Response) => {
  const unresolvedOnly = req.query.unresolved === '1' || req.query.filter === 'unresolved';
  const incidents = defaultSelfHealingEngine.listIncidents({ unresolvedOnly });
  const digest = defaultSelfHealingEngine.buildDailyDigest();
  res.json({
    panel: 'Black Apex OS — Self-Healing Operations Log',
    filter: unresolvedOnly ? 'unresolved' : 'all',
    totalIncidents: digest.totalIncidents,
    unresolvedCount: digest.unresolvedCount,
    patchedCount: digest.patchedCount,
    incidents,
  });
});

app.post('/api/ops/incidents', (req: Request, res: Response) => {
  const inc = defaultSelfHealingEngine.reportIncident({
    source: req.body.source || 'server_middleware',
    message: req.body.message || 'Reported runtime exception',
    stack: req.body.stack,
    filesInvolved: req.body.filesInvolved,
    statusCode: req.body.statusCode,
    explicitClass: req.body.explicitClass,
    context: req.body.context,
  });
  res.status(201).json({ incident: inc });
});

app.post('/api/ops/heal/:id', async (req: Request, res: Response) => {
  try {
    const result = await defaultSelfHealingEngine.runSelfPatchLoop(req.params.id);
    res.json(result);
  } catch (err: any) {
    res.status(404).json({ error: err.message });
  }
});

app.post('/api/ops/self-test', async (req: Request, res: Response) => {
  const report = await defaultSelfHealingEngine.runNightlySelfTestCrons(req.body);
  res.json(report);
});

// -----------------------------------------------------------------------------
// Section 32.14 Free-Only Quota Dashboard & Cache Purge Endpoints
// -----------------------------------------------------------------------------
app.get('/api/free/dashboard', (_req: Request, res: Response) => {
  res.json(buildFreeQuotaDashboardSnapshot());
});

app.post('/api/free/cache/purge', (_req: Request, res: Response) => {
  defaultFreeCacheHierarchy.purgeAll();
  res.json({
    purged: true,
    dashboard: buildFreeQuotaDashboardSnapshot(),
  });
});

// -----------------------------------------------------------------------------
// PATCH 01 (P1): Live Diagnostics Endpoint (/diag & /api/diag, auth-gated)
// -----------------------------------------------------------------------------
app.get('/api/diag', async (_req: Request, res: Response) => {
  await initMesh().catch(() => {});
  res.json(defaultDiagStore.getFullReport());
});

app.get('/diag', async (req: Request, res: Response) => {
  await initMesh().catch(() => {});
  const report = defaultDiagStore.getFullReport();
  const accept = String(req.headers.accept || '');
  if (accept.includes('text/html') && req.query.format !== 'json') {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Black Apex OS — /diag (PATCH 01 Live Telemetry)</title>
  <style>
    body { background: #090a0d; color: #e4e4e7; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; padding: 24px; font-size: 12px; line-height: 1.5; }
    h1, h2 { color: #f4f4f5; margin-top: 20px; border-bottom: 1px solid #27272a; padding-bottom: 6px; }
    pre { background: #12141c; border: 1px solid #27272a; padding: 12px; border-radius: 8px; overflow-x: auto; }
  </style>
</head>
<body>
  <h1>BLACK APEX OS — /diag (PATCH 01 LIVE DIAGNOSTICS)</h1>
  <pre id="diag-json">${JSON.stringify(report, null, 2)}</pre>
</body>
</html>`);
    return;
  }
  res.json(report);
});

// -----------------------------------------------------------------------------
// Vite Middleware / Static Serving Setup (Section 26.1 Binding)
// -----------------------------------------------------------------------------
async function startServer() {
  const bind = resolveBindAddresses();
  const isDev = process.env.NODE_ENV !== 'production';

  // Initialize Section 32 Free-Only quota & key pool state
  initializeFreeModeFromEnv();

  // Pre-encode logit_bias token IDs at boot (Section 17.1)
  preencodeBootTokenMaps();

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false, allowedHosts: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req: Request, res: Response) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  const server = app.listen(bind.port, bind.host, () => {
    console.log(`\n⚡ [BLACK APEX OS] Bound to ${bind.host}:${bind.port}`);
    for (const u of bind.urls) {
      console.log(`   ➜ Reachable URL: ${u}`);
    }
    console.log('');
    startKeepAliveCron(bind.port);
    initMesh().catch((err) => console.error('Initial mesh discovery notice:', err.message));
  });

  server.on('error', (err: any) => {
    console.error(formatPortOccupiedError(bind.port, bind.host, err));
    process.exit(1);
  });

  // Graceful shutdown on SIGTERM (Spec Section 12)
  process.on('SIGTERM', () => {
    console.log('SIGTERM received: draining connections and closing server');
    server.close(() => {
      console.log('Server terminated cleanly');
      process.exit(0);
    });
  });
}

startServer().catch((err) => {
  console.error('Fatal startup error:', err);
  process.exit(1);
});
