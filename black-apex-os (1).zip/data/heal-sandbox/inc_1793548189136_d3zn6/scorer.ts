// good original
