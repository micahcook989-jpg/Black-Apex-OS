// patched guard block
